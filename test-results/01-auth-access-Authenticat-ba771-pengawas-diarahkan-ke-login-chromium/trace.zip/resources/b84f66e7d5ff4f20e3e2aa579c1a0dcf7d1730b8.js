(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/contract/ContractDocument.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContractDocument
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/format.ts [app-client] (ecmascript)");
;
;
function ContractTable({ rows }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
        className: "divide-y divide-[#e2e8f0] rounded-xl border border-[#dbe4f2] px-4",
        children: rows.map(([label, value])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-1 py-3 sm:flex-row sm:justify-between sm:gap-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-sm text-[#64748b]",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "text-sm font-semibold text-[#111e3f] sm:text-right",
                        children: value || "Belum tersedia"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this)
                ]
            }, label, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 39,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/contract/ContractDocument.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_c = ContractTable;
function ContractClause({ title, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "mt-8 break-inside-avoid",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-base font-bold text-[#111e3f]",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 space-y-3 text-sm leading-6 text-[#334155]",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/contract/ContractDocument.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_c1 = ContractClause;
function formatPercent(value, total) {
    if (total <= 0) return "—";
    return `${new Intl.NumberFormat("id-ID", {
        maximumFractionDigits: 2
    }).format(value / total * 100)}%`;
}
function displayMetric(value, unit = "") {
    return value && value > 0 ? `${value}${unit}` : "Tidak tercantum";
}
function ContractDocument({ contractNumber, contractDate, customerName, customerNik, customerPhone, customerEmail, projectCode, address, designName, architecturalStyle, landArea, buildingArea, floors, bedrooms, bathrooms, value, duration, startDate, completionDate, scope, specifications = [], supervisor, foremen, paymentStages }) {
    const paymentTotal = paymentStages.reduce((total, stage)=>total + stage.amount, 0);
    const foremanRows = foremen.length > 0 ? foremen.map((name, index)=>[
            `Mandor ${index + 1}`,
            name
        ]) : [
        [
            "Mandor",
            "Belum ditugaskan"
        ]
    ];
    const progressLimits = [
        25,
        50,
        75,
        100
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: "text-[#334155]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-5 text-sm leading-6",
                children: "Para pihak yang bertanda tangan di bawah ini sepakat untuk mengadakan perjanjian kerja sama pembangunan rumah dengan ketentuan sebagai berikut."
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 1 — IDENTITAS PARA PIHAK",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-semibold text-[#111e3f]",
                        children: "Pihak Pertama — Penyedia Jasa"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 128,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractTable, {
                        rows: [
                            [
                                "Nama Perusahaan",
                                "PT Way2Home Konstruksi"
                            ],
                            [
                                "Penanggung Jawab",
                                "KuliPremium"
                            ],
                            [
                                "Kontak",
                                "081384310179"
                            ]
                        ]
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "pt-1 font-semibold text-[#111e3f]",
                        children: "Pihak Kedua — Customer"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractTable, {
                        rows: [
                            [
                                "Nama Lengkap",
                                customerName
                            ],
                            [
                                "NIK",
                                customerNik
                            ],
                            [
                                "Nomor Telepon",
                                customerPhone
                            ],
                            [
                                "Email",
                                customerEmail
                            ]
                        ]
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 141,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "pt-1 font-semibold text-[#111e3f]",
                        children: "Tim Pelaksana Proyek"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 149,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractTable, {
                        rows: [
                            [
                                "Pengawas",
                                supervisor
                            ],
                            ...foremanRows
                        ]
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 127,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 2 — INFORMASI PROYEK",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractTable, {
                    rows: [
                        [
                            "Nomor Kontrak",
                            contractNumber
                        ],
                        [
                            "Kode Proyek",
                            projectCode
                        ],
                        [
                            "Lokasi Pembangunan",
                            address
                        ],
                        [
                            "Desain Rumah",
                            designName
                        ],
                        [
                            "Gaya Arsitektur",
                            architecturalStyle
                        ],
                        [
                            "Luas Tanah",
                            displayMetric(landArea, " m²")
                        ],
                        [
                            "Luas Bangunan",
                            displayMetric(buildingArea, " m²")
                        ],
                        [
                            "Jumlah Lantai",
                            displayMetric(floors)
                        ],
                        [
                            "Jumlah Kamar Tidur",
                            displayMetric(bedrooms)
                        ],
                        [
                            "Jumlah Kamar Mandi",
                            displayMetric(bathrooms)
                        ]
                    ]
                }, void 0, false, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 3 — RUANG LINGKUP PEKERJAAN",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Pihak Pertama bertanggung jawab melaksanakan pembangunan rumah sesuai desain dan spesifikasi yang telah disepakati bersama. Ruang lingkup pekerjaan meliputi:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 173,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Persiapan dan pembersihan lahan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 179,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pekerjaan pondasi dan struktur bangunan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pekerjaan dinding, lantai, dan atap."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 181,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pekerjaan instalasi listrik dan air."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 182,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pekerjaan pintu, jendela, dan bagian interior."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 183,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pekerjaan finishing dan penyelesaian bangunan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 184,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pekerjaan tambahan sesuai kesepakatan tertulis para pihak."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 185,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 178,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Spesifikasi material dan detail teknis mengacu pada dokumen spesifikasi proyek yang menjadi bagian tidak terpisahkan dari perjanjian ini."
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this),
                    scope.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold text-[#111e3f]",
                                children: "Rincian ruang lingkup proyek"
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 194,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "list-disc space-y-1 pl-5",
                                children: scope.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: item
                                    }, item, false, {
                                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                        lineNumber: 199,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 197,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 193,
                        columnNumber: 11
                    }, this),
                    specifications.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "font-semibold text-[#111e3f]",
                                children: "Spesifikasi proyek"
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 206,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "list-disc space-y-1 pl-5",
                                children: specifications.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: item
                                    }, item, false, {
                                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                        lineNumber: 209,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 207,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 205,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 4 — NILAI KONTRAK DAN PEMBAYARAN",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "Total nilai pembangunan rumah yang disepakati adalah",
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                className: "text-[#111e3f]",
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatRupiah"])(value)
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 219,
                                columnNumber: 11
                            }, this),
                            "."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 217,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: "w-full min-w-[32rem] border-collapse text-left text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "border-b border-[#cbd5e1] text-[#111e3f]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "py-2 pr-3 font-semibold",
                                                children: "Tahap"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                lineNumber: 225,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "py-2 pr-3 font-semibold",
                                                children: "Persentase"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                lineNumber: 226,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "py-2 text-right font-semibold",
                                                children: "Nominal"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                lineNumber: 227,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                        lineNumber: 224,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                    lineNumber: 223,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    children: [
                                        paymentStages.map((stage, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "border-b border-[#e2e8f0]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "py-2 pr-3",
                                                        children: stage.label
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                        lineNumber: 236,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "py-2 pr-3",
                                                        children: formatPercent(stage.amount, value)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                        lineNumber: 237,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "py-2 text-right tabular-nums",
                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatRupiah"])(stage.amount)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                        lineNumber: 240,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, `${stage.label}-${index}`, true, {
                                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                lineNumber: 232,
                                                columnNumber: 17
                                            }, this)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            className: "font-bold text-[#111e3f]",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "py-2 pr-3",
                                                    children: "Total"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                    lineNumber: 246,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "py-2 pr-3",
                                                    children: formatPercent(paymentTotal, value)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                    lineNumber: 247,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "py-2 text-right tabular-nums",
                                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatRupiah"])(paymentTotal)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                                    lineNumber: 250,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                            lineNumber: 245,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                    lineNumber: 230,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 222,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 221,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Customer wajib membayar sesuai jadwal dan tahapan yang disepakati."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 258,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pembayaran dilakukan melalui metode pembayaran yang tersedia pada sistem Way2Home."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 261,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pembayaran setiap termin didasarkan pada tahapan pekerjaan yang telah dicapai dan diverifikasi."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 265,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Setiap pembayaran dicatat sebagai bagian dari riwayat transaksi proyek."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 269,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Perubahan nilai kontrak harus disetujui oleh para pihak."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 273,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 257,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 216,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 5 — JADWAL DAN DURASI PEMBANGUNAN",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractTable, {
                        rows: [
                            [
                                "Tanggal Kontrak",
                                contractDate
                            ],
                            [
                                "Tanggal Mulai",
                                startDate
                            ],
                            [
                                "Estimasi Penyelesaian",
                                completionDate
                            ],
                            [
                                "Durasi Pembangunan",
                                duration > 0 ? `${duration} bulan` : "Belum ditentukan"
                            ]
                        ]
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 278,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Pembangunan dilaksanakan berdasarkan tahapan dan jadwal yang telah disepakati. Apabila terjadi perubahan jadwal, Pihak Pertama wajib memberikan informasi dan penjelasan kepada Pihak Kedua melalui sistem Way2Home."
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 289,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 277,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 6 — HAK DAN KEWAJIBAN",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-semibold text-[#111e3f]",
                        children: "A. Pihak Pertama (Penyedia Jasa)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 298,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Melaksanakan pembangunan sesuai desain, spesifikasi, anggaran, dan jadwal yang disepakati."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 302,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Menyediakan tenaga kerja dan material sesuai ketentuan kontrak."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 306,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memastikan pekerjaan sesuai standar kualitas yang disepakati."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 309,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Menyediakan informasi perkembangan pembangunan kepada Customer."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 310,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Menindaklanjuti kendala yang terjadi selama pembangunan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 313,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 301,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-semibold text-[#111e3f]",
                        children: "B. Pihak Kedua (Customer)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 315,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Melakukan pembayaran sesuai ketentuan kontrak."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 319,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Menyediakan dokumen dan informasi yang diperlukan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 320,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memberikan persetujuan terhadap perubahan pekerjaan apabila diperlukan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 321,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memantau perkembangan proyek melalui sistem Way2Home."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 325,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memeriksa hasil pembangunan pada tahap penyelesaian."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 326,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 318,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-semibold text-[#111e3f]",
                        children: "C. Pengawas Proyek"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 328,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memantau dan memeriksa pelaksanaan pembangunan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memastikan pekerjaan sesuai spesifikasi dan jadwal."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memverifikasi laporan perkembangan dari Mandor."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 332,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Mengawasi penggunaan material dan anggaran proyek."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 333,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Melaporkan kendala dan potensi risiko pembangunan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 334,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 329,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-semibold text-[#111e3f]",
                        children: "D. Mandor"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 336,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Mengatur dan mengoordinasikan tenaga kerja di lapangan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 338,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Melaksanakan pekerjaan sesuai arahan dan spesifikasi proyek."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 339,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memastikan pekerjaan berjalan sesuai tahapan pembangunan."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 340,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Memperbarui laporan perkembangan pekerjaan melalui sistem."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 341,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Melaporkan kendala kepada Pengawas."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 342,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 337,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 297,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 7 — PEMBAYARAN DAN BATAS PELAKSANAAN PROGRES PEMBANGUNAN",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Customer melakukan pembayaran secara bertahap sesuai termin dalam Pasal 4. Batas maksimal progres pembangunan mengikuti pembayaran kumulatif yang telah diterima:"
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 347,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: paymentStages.map((stage, index)=>{
                            const progressLimit = progressLimits[index] ?? 100;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Setelah ",
                                    stage.label,
                                    " diterima dan dikonfirmasi, pekerjaan dapat dilaksanakan hingga maksimal ",
                                    progressLimit,
                                    "%."
                                ]
                            }, `${stage.label}-progress-${index}`, true, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 356,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                        className: "list-decimal space-y-1 pl-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Penyedia Jasa tidak diperkenankan melaksanakan pembangunan melebihi batas maksimal progres berdasarkan pembayaran yang telah diterima."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 364,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Jika termin berikutnya belum dibayar, pembangunan dapat dihentikan sementara setelah mencapai batas progres tersebut."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 368,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Pengawas Proyek memantau kesesuaian pembayaran yang diterima dengan progres pembangunan aktual."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 372,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Setelah pembayaran termin berikutnya diterima dan dikonfirmasi, pembangunan dapat dilanjutkan hingga batas progres tahap berikutnya."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 376,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: "Keterlambatan pembayaran yang menyebabkan penghentian sementara dievaluasi bersama, termasuk kemungkinan penyesuaian jadwal proyek."
                            }, void 0, false, {
                                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                lineNumber: 380,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/contract/ContractDocument.tsx",
                        lineNumber: 363,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 346,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 8 — MONITORING DAN PELAPORAN PROYEK",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Perkembangan pembangunan wajib dilaporkan secara berkala melalui sistem Way2Home."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 389,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Mandor bertanggung jawab memperbarui informasi perkembangan pekerjaan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 393,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Pengawas memeriksa dan memverifikasi laporan perkembangan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 397,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Dokumentasi berupa foto atau bukti pekerjaan dapat dilampirkan dalam laporan progres."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 398,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Customer berhak memperoleh informasi perkembangan proyek melalui sistem Way2Home."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 402,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 388,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 387,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 9 — PERUBAHAN PEKERJAAN",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Perubahan yang berdampak pada biaya dan jadwal wajib diinformasikan kepada Customer sebelum dilaksanakan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 411,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Perubahan hanya dapat dilaksanakan setelah memperoleh persetujuan tertulis atau digital dari pihak terkait."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 415,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Perubahan yang telah disetujui menjadi bagian dari perjanjian ini."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 419,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 410,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 409,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 10 — KENDALA DAN KETERLAMBATAN",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Setiap kendala yang memengaruhi pembangunan wajib dilaporkan melalui sistem Way2Home."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 427,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Pengawas bertanggung jawab memeriksa laporan kendala."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 431,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Jika terjadi keterlambatan, Penyedia Jasa wajib menjelaskan penyebab dan rencana penyelesaiannya."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 432,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: [
                                "Dalam keadaan kahar (",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
                                    children: "force majeure"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                                    lineNumber: 437,
                                    columnNumber: 34
                                }, this),
                                "), para pihak membahas penyesuaian jadwal dan ketentuan pelaksanaan pekerjaan."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 436,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 426,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 425,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 11 — PERUBAHAN NILAI KONTRAK DAN PENAMBAHAN BIAYA",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Nilai kontrak disepakati berdasarkan spesifikasi pekerjaan, kebutuhan material, dan ruang lingkup pembangunan yang telah ditentukan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 445,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Jika ditemukan kondisi tidak terduga yang berpotensi menambah biaya, Penyedia Jasa melalui Pengawas wajib menyampaikan penjelasan kendala, penyebab, rincian estimasi biaya tambahan, dan dampaknya terhadap jadwal."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 450,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Penambahan biaya wajib mendapat persetujuan tertulis Customer sebelum pekerjaan tambahan dilaksanakan atau biaya dikeluarkan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 456,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Jika disetujui, perubahan nilai kontrak dan jadwal dituangkan dalam addendum apabila diperlukan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 460,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Jika tidak disetujui, para pihak membahas alternatif penyelesaian tanpa mengurangi standar keselamatan dan kualitas konstruksi."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 464,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Penyedia Jasa tidak diperkenankan membebankan biaya tambahan secara sepihak."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 468,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 444,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 443,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 12 — PENYELESAIAN DAN SERAH TERIMA",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Pembangunan dinyatakan selesai setelah seluruh pekerjaan dalam ruang lingkup kontrak dilaksanakan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 477,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Pengawas memeriksa hasil pembangunan sebelum serah terima."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 481,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Jika ditemukan ketidaksesuaian, Penyedia Jasa menindaklanjuti perbaikan sesuai kesepakatan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 482,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Serah terima dilakukan setelah hasil pekerjaan dinyatakan sesuai ketentuan yang disepakati."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 486,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Serah terima didokumentasikan melalui berita acara yang disetujui para pihak."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 490,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 476,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 475,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 13 — GARANSI DAN PEMELIHARAAN",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Durasi dan cakupan garansi mengikuti dokumen garansi proyek yang disepakati para pihak."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 499,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Garansi mencakup kerusakan atau ketidaksesuaian akibat kesalahan pelaksanaan pekerjaan sesuai cakupan yang disepakati."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 503,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Customer dapat mengajukan klaim garansi melalui sistem Way2Home."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 507,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Pengecualian garansi dan mekanisme perbaikan dijelaskan dalam dokumen garansi terpisah apabila diperlukan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 510,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 498,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 497,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 14 — PENYELESAIAN PERSELISIHAN",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Setiap perselisihan diselesaikan terlebih dahulu melalui musyawarah."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 519,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Jika musyawarah tidak mencapai kesepakatan, para pihak dapat menempuh mekanisme penyelesaian sesuai ketentuan hukum yang berlaku."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 522,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Para pihak tetap melaksanakan kewajiban masing-masing selama tidak ada kesepakatan lain yang sah."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 526,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 518,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 517,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContractClause, {
                title: "PASAL 15 — PENUTUP",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "list-decimal space-y-1 pl-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Perjanjian ini berlaku sejak disetujui oleh para pihak."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 535,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Seluruh perubahan terhadap perjanjian wajib memperoleh persetujuan para pihak."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 536,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Dokumen dan lampiran proyek yang disepakati merupakan bagian tidak terpisahkan dari perjanjian ini."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 540,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: "Perjanjian dibuat secara elektronik melalui sistem Way2Home dan dapat diakses oleh pihak-pihak yang berkepentingan."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/ContractDocument.tsx",
                            lineNumber: 544,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/ContractDocument.tsx",
                    lineNumber: 534,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 533,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-8 border-t border-[#dbe4f2] pt-5 text-center text-sm font-medium leading-6 text-[#111e3f]",
                children: "Dengan menyetujui kontrak ini, para pihak menyatakan telah membaca, memahami, dan menyetujui seluruh ketentuan di dalamnya."
            }, void 0, false, {
                fileName: "[project]/src/components/contract/ContractDocument.tsx",
                lineNumber: 551,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/contract/ContractDocument.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
}
_c2 = ContractDocument;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ContractTable");
__turbopack_context__.k.register(_c1, "ContractClause");
__turbopack_context__.k.register(_c2, "ContractDocument");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/contract/SignaturePadModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SignaturePadModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function SignaturePadModal({ onContinue, onClose, busy = false }) {
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const drawing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const previous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hasInk = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const [ready, setReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [inked, setInked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const resize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SignaturePadModal.useCallback[resize]": ()=>{
            const canvas = canvasRef.current;
            if (!canvas) return;
            const rect = canvas.getBoundingClientRect();
            if (!rect.width || !rect.height) return;
            const ratio = Math.min(window.devicePixelRatio || 1, 2);
            const old = document.createElement("canvas");
            old.width = canvas.width;
            old.height = canvas.height;
            old.getContext("2d")?.drawImage(canvas, 0, 0);
            canvas.width = Math.round(rect.width * ratio);
            canvas.height = Math.round(rect.height * ratio);
            const context = canvas.getContext("2d");
            if (!context) return;
            context.scale(ratio, ratio);
            context.lineWidth = 2.4;
            context.lineCap = "round";
            context.lineJoin = "round";
            context.strokeStyle = "#102b43";
            if (old.width && old.height) context.drawImage(old, 0, 0, rect.width, rect.height);
            setReady(true);
        }
    }["SignaturePadModal.useCallback[resize]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SignaturePadModal.useEffect": ()=>{
            resize();
            window.addEventListener("resize", resize);
            const onKey = {
                "SignaturePadModal.useEffect.onKey": (event)=>{
                    if (event.key === "Escape" && !busy) onClose();
                }
            }["SignaturePadModal.useEffect.onKey"];
            document.addEventListener("keydown", onKey);
            const previousOverflow = document.body.style.overflow;
            document.body.style.overflow = "hidden";
            return ({
                "SignaturePadModal.useEffect": ()=>{
                    window.removeEventListener("resize", resize);
                    document.removeEventListener("keydown", onKey);
                    document.body.style.overflow = previousOverflow;
                }
            })["SignaturePadModal.useEffect"];
        }
    }["SignaturePadModal.useEffect"], [
        busy,
        onClose,
        resize
    ]);
    const point = (event)=>{
        const rect = event.currentTarget.getBoundingClientRect();
        return {
            x: event.clientX - rect.left,
            y: event.clientY - rect.top
        };
    };
    const start = (event)=>{
        if (busy) return;
        event.currentTarget.setPointerCapture(event.pointerId);
        drawing.current = true;
        previous.current = point(event);
    };
    const move = (event)=>{
        if (!drawing.current || !previous.current) return;
        const next = point(event);
        const context = event.currentTarget.getContext("2d");
        if (!context) return;
        context.beginPath();
        context.moveTo(previous.current.x, previous.current.y);
        context.lineTo(next.x, next.y);
        context.stroke();
        previous.current = next;
        hasInk.current = true;
        setInked(true);
    };
    const stop = ()=>{
        drawing.current = false;
        previous.current = null;
    };
    const reset = ()=>{
        const canvas = canvasRef.current;
        const context = canvas?.getContext("2d");
        if (canvas && context) context.clearRect(0, 0, canvas.width, canvas.height);
        hasInk.current = false;
        setInked(false);
    };
    const proceed = async ()=>{
        const canvas = canvasRef.current;
        if (!canvas || !hasInk.current) return;
        await onContinue(canvas.toDataURL("image/png"));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[70] flex items-center justify-center bg-[#0b1b2b]/65 p-4",
        role: "presentation",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "signature-title",
            className: "w-full max-w-xl overflow-hidden rounded-2xl bg-white shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "border-b border-slate-200 px-6 py-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "signature-title",
                            className: "text-lg font-bold text-[#17344e]",
                            children: "Tanda tangan digital"
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 text-sm text-slate-600",
                            children: "Gambar tanda tangan di area berikut. Tanda tangan tersimpan sebagai persetujuan digital pada kontrak ini."
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                            lineNumber: 116,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                    ref: canvasRef,
                    "aria-label": "Area gambar tanda tangan",
                    className: "m-5 h-52 w-[calc(100%-2.5rem)] touch-none rounded-xl border border-dashed border-slate-400 bg-[#fbfcfd]",
                    onPointerDown: start,
                    onPointerMove: move,
                    onPointerUp: stop,
                    onPointerCancel: stop
                }, void 0, false, {
                    fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                    lineNumber: 121,
                    columnNumber: 9
                }, this),
                !ready && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "px-6 text-xs text-slate-500",
                    children: "Menyiapkan area tanda tangan…"
                }, void 0, false, {
                    fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                    lineNumber: 131,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                    className: "flex flex-wrap justify-end gap-3 border-t border-slate-200 bg-slate-50 px-6 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: busy,
                            onClick: reset,
                            className: "min-h-11 rounded-lg border border-slate-300 px-5 text-sm font-semibold text-slate-700 hover:bg-white disabled:opacity-50",
                            children: "Reset"
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                            lineNumber: 136,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: busy || !inked,
                            onClick: proceed,
                            className: "min-h-11 rounded-lg bg-[#183b57] px-6 text-sm font-semibold text-white hover:bg-[#234f70] disabled:cursor-not-allowed disabled:opacity-50",
                            children: busy ? "Menyimpan…" : "Continue"
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                            lineNumber: 144,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: busy,
                            onClick: onClose,
                            className: "min-h-11 rounded-lg px-4 text-sm font-semibold text-slate-600 hover:bg-white disabled:opacity-50",
                            children: "Batal"
                        }, void 0, false, {
                            fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                            lineNumber: 152,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
                    lineNumber: 135,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
            lineNumber: 106,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/contract/SignaturePadModal.tsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
}
_s(SignaturePadModal, "SA/la8jLUj6o8MEzvZaZS/3z5nM=");
_c = SignaturePadModal;
var _c;
__turbopack_context__.k.register(_c, "SignaturePadModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/contract/SignatureSlot.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SignatureSlot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function SignatureSlot({ role, name, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-[88px] w-full items-end justify-center pb-1",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/contract/SignatureSlot.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-sm font-bold text-[#111e3f]",
                children: role
            }, void 0, false, {
                fileName: "[project]/src/components/contract/SignatureSlot.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-0.5 text-xs text-[#64748b]",
                children: name
            }, void 0, false, {
                fileName: "[project]/src/components/contract/SignatureSlot.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/contract/SignatureSlot.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = SignatureSlot;
var _c;
__turbopack_context__.k.register(_c, "SignatureSlot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/pengawas/PengawasDashboard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PengawasDashboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/allocation.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/access.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$progress$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/progress.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$pengawas$2f$SupervisorContractModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/pengawas/SupervisorContractModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
// ─── Status helpers ────────────────────────────────────────────────────────────
const STATUS_LABEL = {
    draft: "Draft",
    verifikasi_dokumen: "Verif. Dokumen",
    revisi_dokumen: "Revisi Dokumen",
    alokasi_mandor_pengawas: "Menunggu Tim",
    finalisasi_kontrak: "Finalisasi Kontrak",
    pembayaran_dp: "Menunggu Pembayaran DP",
    berjalan: "Berjalan",
    selesai: "Selesai",
    batal: "Dibatalkan",
    menunggu_pengawas: "Ditugaskan"
};
const STATUS_CLASS = {
    berjalan: "bg-[#eaf2f8] text-[#416f91]",
    pembayaran_dp: "bg-amber-50 text-amber-700",
    selesai: "bg-[#edf6ef] text-[#4d7d56]",
    alokasi_mandor_pengawas: "bg-amber-50 text-amber-700",
    default: "bg-[#f0f5f8] text-[#416f91]"
};
function getStatusClass(status) {
    return STATUS_CLASS[status] ?? STATUS_CLASS.default;
}
// ─── Mandor Allocation Modal ───────────────────────────────────────────────────
function MandorAllocationModal({ project, allMandors, onClose, onSaved, onFinalized }) {
    _s();
    const [selectedIds, setSelectedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [finalizing, setFinalizing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [removing, setRemoving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [localMandors, setLocalMandors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(project.mandors);
    const canSelectMandor = (mandor)=>{
        if (selectedIds.has(mandor.id)) return true;
        if (localMandors.length + selectedIds.size >= 3) return false;
        if (mandor.keahlian.length === 0) return false;
        const assignedSkills = [
            ...localMandors.flatMap((assigned)=>assigned.keahlian),
            ...allMandors.filter((candidate)=>selectedIds.has(candidate.id)).flatMap((candidate)=>candidate.keahlian)
        ];
        return !mandor.keahlian.some((skill)=>assignedSkills.includes(skill));
    };
    const toggleSelect = (id)=>{
        setSelectedIds((prev)=>{
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };
    const handleAssign = async ()=>{
        if (selectedIds.size === 0) return;
        setSubmitting(true);
        setError(null);
        setSuccess(null);
        try {
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignMandorsToProject"])(supabase, project.id, Array.from(selectedIds));
            // Build new AllocatedMandor entries for optimistic update
            const now = new Date().toISOString();
            const newlyAllocated = allMandors.filter((m)=>selectedIds.has(m.id)).map((m)=>({
                    mandor_id: m.id,
                    full_name: m.full_name,
                    phone: m.phone,
                    keahlian: m.keahlian,
                    area_kerja: m.area_kerja,
                    pengalaman_tahun: m.pengalaman_tahun,
                    assigned_at: now
                }));
            const updatedMandors = [
                ...localMandors,
                ...newlyAllocated
            ];
            setLocalMandors(updatedMandors);
            onSaved(project.id, updatedMandors);
            setSelectedIds(new Set());
            if (result.skipped > 0) {
                setSuccess(`${result.assigned} mandor berhasil dialokasikan, ${result.skipped} sudah ada.`);
            } else {
                setSuccess(`${result.assigned} mandor berhasil dialokasikan.`);
            }
        } catch (err) {
            setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"] ? err.message : "Terjadi kesalahan.");
        } finally{
            setSubmitting(false);
        }
    };
    const handleFinalize = async ()=>{
        setFinalizing(true);
        setError(null);
        setSuccess(null);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeProjectStaffing"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])(), project.id);
            let notificationWarning;
            try {
                const response = await fetch(`/api/projects/${project.id}/team-notifications`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        event: "staffing-finalized"
                    })
                });
                if (!response.ok) {
                    const result = await response.json();
                    notificationWarning = result.message || "Notifikasi customer gagal dikirim.";
                }
            } catch (notificationError) {
                console.error("[PengawasDashboard] team notification failed:", notificationError);
                notificationWarning = "Notifikasi customer gagal dikirim.";
            }
            onFinalized(project.id, notificationWarning);
            onClose();
        } catch (err) {
            setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"] ? err.message : "Gagal memfinalisasi alokasi.");
        } finally{
            setFinalizing(false);
        }
    };
    const handleRemove = async (mandorId)=>{
        setRemoving(mandorId);
        setError(null);
        setSuccess(null);
        try {
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeMandorFromProject"])(supabase, project.id, mandorId);
            const updatedMandors = localMandors.filter((m)=>m.mandor_id !== mandorId);
            setLocalMandors(updatedMandors);
            onSaved(project.id, updatedMandors);
            setSuccess("Mandor berhasil dihapus dari proyek.");
        } catch (err) {
            setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"] ? err.message : "Gagal menghapus mandor.");
        } finally{
            setRemoving(null);
        }
    };
    const currentAllocatedIds = new Set(localMandors.map((m)=>m.mandor_id));
    const currentAvailable = allMandors.filter((m)=>!currentAllocatedIds.has(m.id));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[70] grid place-items-center bg-[#0c1b2b]/60 p-4 backdrop-blur-[3px]",
        onMouseDown: (e)=>{
            if (e.target === e.currentTarget) onClose();
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "mandor-alloc-title",
            className: "flex max-h-[90vh] w-full max-w-[780px] flex-col overflow-hidden rounded-2xl bg-white shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "flex items-center justify-between border-b border-[#e8edf1] px-6 py-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[10px] text-slate-500",
                                    children: "Alokasi Mandor"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "mandor-alloc-title",
                                    className: "mt-1 text-lg font-bold text-[#17344e]",
                                    children: project.design_name
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 228,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-0.5 text-xs text-slate-500",
                                    children: [
                                        "Pelanggan: ",
                                        project.customer_name,
                                        project.alamat_proyek ? ` · ${project.alamat_proyek.slice(0, 50)}` : ""
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 234,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 226,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            "aria-label": "Tutup",
                            className: "grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-xl text-slate-500 hover:bg-slate-50",
                            children: "×"
                        }, void 0, false, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                    lineNumber: 225,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-5 pt-4 space-y-2",
                            children: [
                                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-red-700",
                                    children: error
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 254,
                                    columnNumber: 15
                                }, this),
                                success && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-700",
                                    children: [
                                        "✓ ",
                                        success
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 259,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 252,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-5 pt-4 pb-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "mb-2 text-xs font-bold text-[#263d53]",
                                    children: [
                                        "Mandor Teralokasikan (",
                                        localMandors.length,
                                        ")"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 267,
                                    columnNumber: 13
                                }, this),
                                localMandors.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "rounded-lg border border-dashed border-slate-200 p-4 text-center text-xs text-slate-400",
                                    children: "Belum ada mandor yang dialokasikan ke proyek ini."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 271,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: localMandors.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3 rounded-xl border border-[#e7ebef] bg-[#f8fafc] p-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#eaf1f6] text-[10px] font-bold text-[#355973]",
                                                    children: m.full_name.slice(0, 2).toUpperCase()
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 281,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "min-w-0 flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "truncate text-sm font-semibold text-[#29465e]",
                                                            children: m.full_name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                            lineNumber: 285,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-[10px] text-slate-500",
                                                            children: [
                                                                m.keahlian.length > 0 ? m.keahlian.join(", ") : "Keahlian tidak tersedia",
                                                                m.area_kerja ? ` · ${m.area_kerja}` : "",
                                                                m.pengalaman_tahun ? ` · ${m.pengalaman_tahun} thn pengalaman` : ""
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                            lineNumber: 288,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 284,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleRemove(m.mandor_id),
                                                    disabled: removing === m.mandor_id,
                                                    "aria-label": `Hapus ${m.full_name}`,
                                                    className: "grid h-7 w-7 place-items-center rounded-lg border border-red-200 text-red-500 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50",
                                                    children: removing === m.mandor_id ? "…" : "✕"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 298,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, m.mandor_id, true, {
                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                            lineNumber: 277,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 275,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 266,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-5 pt-3 pb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "mb-2 text-xs font-bold text-[#263d53]",
                                    children: [
                                        "Mandor Terverifikasi Tersedia (",
                                        currentAvailable.length,
                                        ")"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 314,
                                    columnNumber: 13
                                }, this),
                                currentAvailable.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-xl border border-dashed border-[#d9e1e8] p-6 text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm font-semibold text-[#365873]",
                                            children: "Tidak ada mandor tersedia untuk proyek ini"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                            lineNumber: 319,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-1 text-xs text-slate-500",
                                            children: "Mandor yang masih menangani proyek aktif tidak dapat dipilih."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                            lineNumber: 322,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 318,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: currentAvailable.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>toggleSelect(m.id),
                                            disabled: !canSelectMandor(m),
                                            className: `flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-colors ${selectedIds.has(m.id) ? "border-[#7395b1] bg-[#f0f5f8] ring-2 ring-[#7395b1]/15" : canSelectMandor(m) ? "border-[#e7ebef] hover:bg-slate-50" : "cursor-not-allowed border-[#e7ebef] bg-slate-50 opacity-50"}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[#d8e3eb] bg-[#eaf1f6] text-[10px] font-bold text-[#355973]",
                                                    children: m.full_name.slice(0, 2).toUpperCase()
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 340,
                                                    columnNumber: 21
                                                }, this),
                                                !canSelectMandor(m) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block text-[10px] font-semibold text-amber-700",
                                                    children: localMandors.length + selectedIds.size >= 3 ? "Batas 3 mandor per proyek sudah tercapai" : m.keahlian.length === 0 ? "Keahlian mandor belum tercatat" : "Keahlian sudah dimiliki mandor lain"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 344,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "min-w-0 flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                            className: "block truncate text-sm text-[#29465e]",
                                                            children: m.full_name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                            lineNumber: 353,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "block text-[10px] text-slate-500",
                                                            children: [
                                                                m.keahlian.length > 0 ? m.keahlian.join(", ") : "Keahlian tidak tercatat",
                                                                m.area_kerja ? ` · ${m.area_kerja}` : "",
                                                                m.pengalaman_tahun ? ` · ${m.pengalaman_tahun} thn` : ""
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                            lineNumber: 356,
                                                            columnNumber: 23
                                                        }, this),
                                                        m.phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "block text-[10px] text-slate-400",
                                                            children: m.phone
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                            lineNumber: 366,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 352,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: `grid h-5 w-5 shrink-0 place-items-center rounded-full border text-[10px] font-bold ${selectedIds.has(m.id) ? "border-[#477ba6] bg-[#477ba6] text-white" : "border-slate-300"}`,
                                                    children: selectedIds.has(m.id) ? "✓" : ""
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 371,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, m.id, true, {
                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                            lineNumber: 329,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 327,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 313,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                    lineNumber: 250,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                    className: "flex items-center justify-between gap-2 border-t border-[#e8edf1] bg-[#fafbfc] px-5 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-slate-500",
                            children: selectedIds.size > 0 ? `${selectedIds.size} mandor dipilih` : project.status === "alokasi_mandor_pengawas" ? "Alokasikan minimal satu mandor untuk lanjut ke tahap kontrak" : "Pilih satu atau lebih mandor"
                        }, void 0, false, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 387,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: onClose,
                                    className: "h-10 rounded-lg border border-[#dfe6ed] px-4 text-xs font-semibold text-slate-600 hover:bg-white",
                                    children: "Tutup"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 395,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    id: "btn-alokasi-mandor",
                                    onClick: handleAssign,
                                    disabled: selectedIds.size === 0 || submitting || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAllocateStaff"])(project.status),
                                    className: "h-10 rounded-lg bg-[#183b57] px-5 text-xs font-semibold text-white hover:bg-[#234f70] disabled:cursor-not-allowed disabled:opacity-40",
                                    children: submitting ? "Mengalokasikan..." : `Alokasikan ${selectedIds.size > 0 ? `(${selectedIds.size})` : ""}`
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 401,
                                    columnNumber: 13
                                }, this),
                                project.status === "alokasi_mandor_pengawas" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    id: "btn-finalisasi-alokasi",
                                    onClick: handleFinalize,
                                    disabled: localMandors.length === 0 || selectedIds.size > 0 || submitting || finalizing,
                                    className: "h-10 rounded-lg bg-emerald-700 px-4 text-xs font-semibold text-white hover:bg-emerald-800 disabled:cursor-not-allowed disabled:opacity-40",
                                    children: finalizing ? "Memproses..." : "Finalisasi & lanjut ke kontrak"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                    lineNumber: 416,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 394,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                    lineNumber: 386,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
            lineNumber: 219,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
        lineNumber: 213,
        columnNumber: 5
    }, this);
}
_s(MandorAllocationModal, "ImwB4vgRdH2InVLAXQ285KeGuTs=");
_c = MandorAllocationModal;
function PengawasDashboard() {
    _s1();
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [allMandors, setAllMandors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Semua proyek");
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedProject, setSelectedProject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [officialProgress, setOfficialProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [contractProject, setContractProject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [contractLoadingId, setContractLoadingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [contractError, setContractError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PengawasDashboard.useCallback[fetchData]": async ()=>{
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            return Promise.all([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProjectsForPengawas"])(supabase),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVerifiedMandors"])(supabase)
            ]);
        }
    }["PengawasDashboard.useCallback[fetchData]"], []);
    const load = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PengawasDashboard.useCallback[load]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                const [projectsData, mandorsData] = await fetchData();
                setProjects(projectsData);
                setAllMandors(mandorsData);
                const progressProjects = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$progress$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPengawasProgressProjects"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])());
                setOfficialProgress(Object.fromEntries(progressProjects.map({
                    "PengawasDashboard.useCallback[load]": (project)=>[
                            project.id,
                            project.overallProgress
                        ]
                }["PengawasDashboard.useCallback[load]"])));
            } catch (err) {
                if (err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]) {
                    setError(err.message);
                } else {
                    setError("Gagal memuat data. Silakan refresh halaman.");
                }
            } finally{
                setLoading(false);
            }
        }
    }["PengawasDashboard.useCallback[load]"], [
        fetchData
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PengawasDashboard.useEffect": ()=>{
            let active = true;
            fetchData().then({
                "PengawasDashboard.useEffect": async ([projectsData, mandorsData])=>{
                    if (!active) return;
                    setProjects(projectsData);
                    setAllMandors(mandorsData);
                    const progressProjects = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$progress$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPengawasProgressProjects"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])());
                    setOfficialProgress(Object.fromEntries(progressProjects.map({
                        "PengawasDashboard.useEffect": (project)=>[
                                project.id,
                                project.overallProgress
                            ]
                    }["PengawasDashboard.useEffect"])));
                }
            }["PengawasDashboard.useEffect"]).catch({
                "PengawasDashboard.useEffect": (err)=>{
                    if (!active) return;
                    setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"] ? err.message : "Gagal memuat data. Silakan refresh halaman.");
                }
            }["PengawasDashboard.useEffect"]).finally({
                "PengawasDashboard.useEffect": ()=>{
                    if (active) setLoading(false);
                }
            }["PengawasDashboard.useEffect"]);
            return ({
                "PengawasDashboard.useEffect": ()=>{
                    active = false;
                }
            })["PengawasDashboard.useEffect"];
        }
    }["PengawasDashboard.useEffect"], [
        fetchData
    ]);
    const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PengawasDashboard.useMemo[filtered]": ()=>projects.filter({
                "PengawasDashboard.useMemo[filtered]": (p)=>`${p.id} ${p.design_name} ${p.customer_name} ${p.alamat_proyek ?? ""}`.toLowerCase().includes(query.trim().toLowerCase()) && (filter === "Semua proyek" || (filter === "Aktif" ? p.status !== "selesai" && p.status !== "batal" : p.status === "selesai" || p.status === "batal"))
            }["PengawasDashboard.useMemo[filtered]"])
    }["PengawasDashboard.useMemo[filtered]"], [
        projects,
        filter,
        query
    ]);
    const active = projects.filter((p)=>p.status !== "selesai" && p.status !== "batal").length;
    const withoutMandor = projects.filter((p)=>p.mandors.length === 0).length;
    const handleMandorsSaved = (projectId, newMandors)=>{
        setProjects((curr)=>curr.map((p)=>p.id === projectId ? {
                    ...p,
                    mandors: newMandors
                } : p));
        // Also update selectedProject so the modal reflects latest state
        if (selectedProject?.id === projectId) {
            setSelectedProject((prev)=>prev ? {
                    ...prev,
                    mandors: newMandors
                } : prev);
        }
    };
    const handleStaffingFinalized = (projectId, notificationWarning)=>{
        setProjects((current)=>current.map((project)=>project.id === projectId ? {
                    ...project,
                    status: "finalisasi_kontrak"
                } : project));
        const finalized = projects.find((project)=>project.id === projectId);
        if (finalized) void openSupervisorContract({
            ...finalized,
            status: "finalisasi_kontrak"
        });
        if (notificationWarning) setContractError(notificationWarning);
    };
    const openSupervisorContract = async (project)=>{
        setContractLoadingId(project.id);
        setContractError(null);
        try {
            const response = await fetch(`/api/pengawas/projects/${project.id}`, {
                cache: "no-store"
            });
            if (!response.ok) {
                const result = await response.json();
                throw new Error(result.message || "Gagal memuat kontrak proyek.");
            }
            const detail = await response.json();
            setContractProject(detail);
        } catch (err) {
            setContractError(err instanceof Error ? err.message : "Gagal membuka kontrak.");
        } finally{
            setContractLoadingId(null);
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1500px] space-y-7 p-5 md:p-8 xl:p-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-h-[300px] items-center justify-center rounded-2xl border border-[#e2e8ed] bg-white",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[#5e83a0] border-t-transparent"
                        }, void 0, false, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 612,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-3 text-sm text-slate-500",
                            children: "Memuat proyek Anda..."
                        }, void 0, false, {
                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                            lineNumber: 613,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                    lineNumber: 611,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 610,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
            lineNumber: 609,
            columnNumber: 7
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1500px] space-y-7 p-5 md:p-8 xl:p-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-red-200 bg-red-50 p-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm font-semibold text-red-700",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 624,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: load,
                        className: "mt-3 rounded-lg bg-[#183b57] px-4 py-2 text-xs font-semibold text-white hover:bg-[#234f70]",
                        children: "Coba Lagi"
                    }, void 0, false, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 625,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 623,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
            lineNumber: 622,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto max-w-[1500px] space-y-7 p-5 md:p-8 xl:p-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex flex-col justify-between gap-5 border-b border-[#dfe6ec] pb-6 md:flex-row md:items-end",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold text-[#64809a]",
                                children: "Dashboard Pengawas"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 641,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "mt-2 text-[28px] font-bold tracking-tight text-[#17344e] md:text-[34px]",
                                children: "Ringkasan operasional"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 644,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 max-w-xl text-sm leading-6 text-slate-500",
                                children: "Pantau proyek yang dipercayakan kepada Anda, kelola tim mandor, dan pastikan setiap tahap bergerak sesuai rencana."
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 647,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 640,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-[110px] border-l-2 border-[#6b91ae] pl-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] text-slate-500",
                                        children: "Proyek aktif"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 654,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        className: "mt-1 block text-2xl text-[#183b57]",
                                        children: active
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 655,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 653,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-[140px] border-l-2 border-[#d7a348] pl-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] text-slate-500",
                                        children: "Perlu mandor"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 660,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        className: "mt-1 block text-2xl text-[#183b57]",
                                        children: withoutMandor
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 661,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 659,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 652,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 639,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "proyek",
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-lg font-bold text-[#263d53]",
                                        children: "Proyek Anda"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 672,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-xs text-slate-500",
                                        children: "Pilih proyek untuk membuka detail atau mengalokasikan mandor."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 673,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 671,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-2 sm:flex-row",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sr-only",
                                                children: "Cari proyek"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 679,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "search-pengawas-proyek",
                                                value: query,
                                                onChange: (e)=>setQuery(e.target.value),
                                                placeholder: "Cari proyek, customer, alamat...",
                                                className: "h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-xs outline-none focus:border-[#477ba6] focus:ring-2 focus:ring-[#477ba6]/15 sm:w-[250px]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 680,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 678,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sr-only",
                                                children: "Filter daftar proyek"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 689,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                id: "filter-proyek-pengawas",
                                                value: filter,
                                                onChange: (e)=>setFilter(e.target.value),
                                                className: "h-10 rounded-lg border border-[#dfe6ed] bg-white px-3 text-xs text-slate-600 outline-none focus:border-[#477ba6]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Semua proyek"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 696,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Aktif"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 697,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Selesai"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 698,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 690,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 688,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 677,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 670,
                        columnNumber: 9
                    }, this),
                    filtered.length === 0 && projects.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-xl border border-dashed border-[#d8e1e8] bg-white px-5 py-12 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-[#35546d]",
                                children: "Belum ada proyek ditugaskan"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 706,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-xs text-slate-500",
                                children: "Admin akan mengalokasikan proyek kepada Anda."
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 709,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 705,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid gap-4 xl:grid-cols-2",
                        children: filtered.map((project)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                className: "overflow-hidden rounded-2xl border border-[#e2e8ed] bg-white",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col justify-between gap-4 p-5 sm:flex-row sm:items-start sm:px-6 sm:py-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex flex-wrap items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-semibold text-[#365873]",
                                                                children: [
                                                                    "#",
                                                                    project.id.slice(0, 8)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                                lineNumber: 723,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `rounded-full px-2.5 py-1 text-[9px] font-semibold ${getStatusClass(project.status)}`,
                                                                children: STATUS_LABEL[project.status] ?? project.status
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                                lineNumber: 726,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 722,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "mt-2 text-lg font-bold text-[#183b57]",
                                                        children: project.design_name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 732,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 text-xs text-slate-500",
                                                        children: [
                                                            project.customer_name,
                                                            project.alamat_proyek ? ` · ${project.alamat_proyek.slice(0, 60)}` : ""
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 735,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 721,
                                                columnNumber: 19
                                            }, this),
                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAllocateStaff"])(project.status) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                id: `kelola-mandor-${project.id}`,
                                                onClick: ()=>setSelectedProject(project),
                                                className: "inline-flex h-10 shrink-0 items-center justify-center rounded-lg border border-[#183b57] px-4 text-xs font-semibold text-[#183b57] transition-colors hover:bg-[#183b57] hover:text-white",
                                                children: project.mandors.length === 0 ? "Alokasikan Mandor" : "Kelola Mandor"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 743,
                                                columnNumber: 21
                                            }, this) : project.status === "finalisasi_kontrak" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>void openSupervisorContract(project),
                                                disabled: contractLoadingId === project.id,
                                                className: "inline-flex h-10 shrink-0 items-center justify-center rounded-lg bg-[#183b57] px-4 text-xs font-semibold text-white hover:bg-[#234f70] disabled:opacity-50",
                                                children: contractLoadingId === project.id ? "Memuat kontrak…" : project.supervisorSignedAt ? "Lihat kontrak" : "Tanda tangani kontrak"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 753,
                                                columnNumber: 21
                                            }, this) : project.status === "berjalan" || project.status === "selesai" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: `/pengawas/proyek/${project.id}`,
                                                className: "inline-flex h-10 shrink-0 items-center justify-center rounded-lg border border-[#cfdce6] px-4 text-xs font-semibold text-[#355c78] hover:bg-[#f3f7fa] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#477ba6]",
                                                children: "Buka detail"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 767,
                                                columnNumber: 21
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "inline-flex h-10 shrink-0 items-center justify-center rounded-lg border border-[#e8d8ae] bg-[#fffaf0] px-4 text-center text-xs font-semibold text-[#946a27]",
                                                children: "Tracking menunggu pembayaran DP"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 774,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 720,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-2 gap-y-4 border-t border-[#edf0f3] bg-[#fafbfc] px-5 py-4 sm:grid-cols-4 sm:px-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[9px] text-slate-500",
                                                        children: "Customer"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 783,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 truncate text-xs font-semibold text-slate-700",
                                                        children: project.customer_name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 784,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 782,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[9px] text-slate-500",
                                                        children: "Progres resmi"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 789,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 text-xs font-semibold text-slate-700",
                                                        children: `${officialProgress[project.id] ?? 0}%`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 790,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 788,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[9px] text-slate-500",
                                                        children: "Tim Mandor"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 795,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-1 flex flex-wrap items-center gap-1",
                                                        children: project.mandors.length > 0 ? project.mandors.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-block truncate text-xs font-semibold text-slate-700",
                                                                title: m.full_name,
                                                                children: m.full_name
                                                            }, m.mandor_id, false, {
                                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                                lineNumber: 799,
                                                                columnNumber: 27
                                                            }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "truncate text-xs font-semibold text-slate-700",
                                                            children: "Belum ditetapkan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                            lineNumber: 808,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 796,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 794,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[9px] text-slate-500",
                                                        children: "Status proyek"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 815,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 truncate text-xs font-semibold text-slate-700",
                                                        children: STATUS_LABEL[project.status] ?? project.status
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 816,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 814,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 781,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-5 pb-5 sm:px-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between text-[10px] text-slate-500",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Progres keseluruhan"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 825,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: `${officialProgress[project.id] ?? 0}%`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                        lineNumber: 826,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 824,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-2 h-1.5 overflow-hidden rounded-full bg-[#e9edf2]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block h-full rounded-full bg-[#5e83a0]",
                                                    style: {
                                                        width: `${officialProgress[project.id] ?? 0}%`
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                    lineNumber: 831,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                                lineNumber: 830,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                        lineNumber: 823,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, project.id, true, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 716,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 714,
                        columnNumber: 11
                    }, this),
                    filtered.length === 0 && projects.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-xl border border-dashed border-[#d8e1e8] bg-white px-5 py-12 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-[#35546d]",
                                children: "Tidak ada proyek ditemukan"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 844,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-xs text-slate-500",
                                children: "Ubah kata kunci atau filter proyek."
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                                lineNumber: 847,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 843,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 669,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "border-t border-[#dfe6ec] pt-4 text-[10px] text-slate-400",
                children: "Data diambil langsung dari database. Alokasi mandor tersimpan secara permanen dan terlihat setelah refresh."
            }, void 0, false, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 854,
                columnNumber: 7
            }, this),
            contractError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "alert",
                className: "fixed bottom-5 right-5 z-[90] max-w-md rounded-xl border border-red-200 bg-white px-5 py-4 text-sm font-medium text-red-800 shadow-xl",
                children: [
                    contractError,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setContractError(null),
                        className: "ml-3 underline",
                        children: "Tutup"
                    }, void 0, false, {
                        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                        lineNumber: 865,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 860,
                columnNumber: 9
            }, this),
            contractProject && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$pengawas$2f$SupervisorContractModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                project: contractProject,
                onClose: ()=>{
                    setContractProject(null);
                    void load();
                }
            }, void 0, false, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 875,
                columnNumber: 9
            }, this),
            selectedProject && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MandorAllocationModal, {
                project: selectedProject,
                allMandors: allMandors,
                onClose: ()=>setSelectedProject(null),
                onSaved: handleMandorsSaved,
                onFinalized: handleStaffingFinalized
            }, void 0, false, {
                fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
                lineNumber: 886,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/pengawas/PengawasDashboard.tsx",
        lineNumber: 637,
        columnNumber: 5
    }, this);
}
_s1(PengawasDashboard, "4fqebvk9YNWbpAqCsz0TtRkMhoc=");
_c1 = PengawasDashboard;
var _c, _c1;
__turbopack_context__.k.register(_c, "MandorAllocationModal");
__turbopack_context__.k.register(_c1, "PengawasDashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/pengawas/SupervisorContractModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SupervisorContractModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$SignaturePadModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/contract/SignaturePadModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$ContractDocument$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/contract/ContractDocument.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$SignatureSlot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/contract/SignatureSlot.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function SupervisorContractModal({ project, onClose }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [signatureOpen, setSignatureOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [signedImage, setSignedImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SupervisorContractModal.useEffect": ()=>{
            const onKeyDown = {
                "SupervisorContractModal.useEffect.onKeyDown": (event)=>{
                    if (event.key === "Escape") onClose();
                }
            }["SupervisorContractModal.useEffect.onKeyDown"];
            document.addEventListener("keydown", onKeyDown);
            document.body.style.overflow = "hidden";
            return ({
                "SupervisorContractModal.useEffect": ()=>{
                    document.removeEventListener("keydown", onKeyDown);
                    document.body.style.overflow = "";
                }
            })["SupervisorContractModal.useEffect"];
        }
    }["SupervisorContractModal.useEffect"], [
        onClose
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SupervisorContractModal.useEffect": ()=>{
            const path = project.supervisorSignaturePath;
            if (!path) return;
            let active = true;
            const load = {
                "SupervisorContractModal.useEffect.load": async ()=>{
                    const { createClient } = await __turbopack_context__.A("[project]/src/utils/supabase/client.ts [app-client] (ecmascript, async loader)");
                    const { data } = await createClient().storage.from("contract-signatures").createSignedUrl(path, 300);
                    if (active && data?.signedUrl) setSignedImage(data.signedUrl);
                }
            }["SupervisorContractModal.useEffect.load"];
            void load();
            return ({
                "SupervisorContractModal.useEffect": ()=>{
                    active = false;
                }
            })["SupervisorContractModal.useEffect"];
        }
    }["SupervisorContractModal.useEffect"], [
        project.supervisorSignaturePath
    ]);
    const paymentStages = project.payments.length > 0 ? project.payments.map((payment)=>({
            label: payment.stage,
            amount: payment.amount
        })) : [
        {
            label: "Uang Muka (DP)",
            amount: Math.round((project.estimatedCost ?? project.value) * 0.3)
        },
        {
            label: "Termin 1",
            amount: Math.round((project.estimatedCost ?? project.value) * 0.25)
        },
        {
            label: "Termin 2",
            amount: Math.round((project.estimatedCost ?? project.value) * 0.25)
        },
        {
            label: "Termin 3 (Pelunasan)",
            amount: (project.estimatedCost ?? project.value) - Math.round((project.estimatedCost ?? project.value) * 0.3) - Math.round((project.estimatedCost ?? project.value) * 0.25) * 2
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[80] flex items-center justify-center p-4",
        role: "dialog",
        "aria-modal": "true",
        "aria-labelledby": "supervisor-contract-title",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "absolute inset-0 bg-[#0c1b2b]/65 backdrop-blur-sm",
                onClick: onClose,
                "aria-label": "Tutup kontrak"
            }, void 0, false, {
                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "flex items-center justify-between border-b border-[#e7ebef] px-5 py-4 md:px-7",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        id: "supervisor-contract-title",
                                        className: "text-lg font-bold text-[#17344e]",
                                        children: "Kontrak proyek"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 94,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-xs text-slate-500",
                                        children: [
                                            project.contractId,
                                            " � ",
                                            project.title
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 100,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: onClose,
                                "aria-label": "Tutup kontrak",
                                className: "grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-lg text-slate-500 hover:bg-slate-50",
                                children: "�"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-y-auto px-5 py-6 md:px-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/images/aset/logo-w2h.png",
                                        alt: "Way2Home",
                                        width: 52,
                                        height: 52,
                                        className: "mx-auto h-14 w-auto object-contain"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-3 text-sm font-bold text-[#234b69]",
                                        children: "SURAT PERJANJIAN KERJA SAMA PEMBANGUNAN RUMAH"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 122,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-[10px] text-slate-500",
                                        children: [
                                            "Nomor: ",
                                            project.contractId,
                                            " · Hari / Tanggal:",
                                            " ",
                                            project.contractIssuedAt || "Belum tersedia"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 125,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 114,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$ContractDocument$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                contractNumber: project.contractId,
                                contractDate: project.contractIssuedAt || "Belum tersedia",
                                customerName: project.customer,
                                customerNik: project.customerNik || "Belum tersedia",
                                customerPhone: project.customerPhone || "Belum tersedia",
                                customerEmail: project.customerEmail || "Belum tersedia",
                                projectCode: project.id,
                                address: project.address,
                                designName: project.title,
                                architecturalStyle: project.architecturalStyle || "Belum tercantum",
                                landArea: project.landArea ?? 0,
                                buildingArea: project.buildingArea ?? 0,
                                floors: project.floors,
                                bedrooms: project.bedrooms,
                                bathrooms: project.bathrooms,
                                value: project.estimatedCost ?? project.value,
                                duration: project.duration ?? 0,
                                startDate: project.started,
                                completionDate: project.deadline,
                                scope: [],
                                specifications: [
                                    ...project.specifications.filter((spec)=>!spec.startsWith("Kontrak")),
                                    `Kebutuhan customer: ${project.needs}`
                                ],
                                supervisor: project.supervisor,
                                foremen: project.foremen ?? (project.foreman ? [
                                    project.foreman
                                ] : []),
                                paymentStages: paymentStages
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 130,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-10 rounded-xl border border-[#e3e9ee] bg-[#fafbfc] p-5 text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs font-semibold uppercase tracking-wider text-slate-500",
                                        children: "Tanda Tangan Para Pihak"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 164,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mx-auto mt-5 grid max-w-2xl grid-cols-1 gap-6 sm:grid-cols-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$SignatureSlot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                role: "Pihak Pertama",
                                                name: "PT Way2Home Konstruksi",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    src: "/images/signature-w2h.png",
                                                    alt: "Tanda tangan PT Way2Home Konstruksi",
                                                    width: 220,
                                                    height: 90,
                                                    unoptimized: true,
                                                    className: "h-[72px] w-[180px] object-contain object-center"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                    lineNumber: 169,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                lineNumber: 168,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$SignatureSlot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                role: "Pengawas",
                                                name: project.supervisor,
                                                children: signedImage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: signedImage,
                                                    alt: "Tanda tangan pengawas",
                                                    className: "h-[72px] max-w-full object-contain"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                    lineNumber: 180,
                                                    columnNumber: 19
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "pb-6 text-xs text-slate-500",
                                                    children: "Menunggu tanda tangan"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                lineNumber: 178,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "sm:col-span-2 sm:mx-auto sm:w-1/2",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$SignatureSlot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    role: "Customer",
                                                    name: project.customer,
                                                    children: project.customerSignaturePath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "pb-6 text-xs text-slate-500",
                                                        children: "Tanda tangan customer akan tampil setelah kontrak disetujui."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                        lineNumber: 194,
                                                        columnNumber: 21
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "pb-6 text-xs text-slate-500",
                                                        children: "Menunggu tanda tangan customer"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                        lineNumber: 199,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                    lineNumber: 192,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                                lineNumber: 191,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 167,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 163,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                        className: "flex flex-wrap items-center justify-between gap-3 border-t border-[#e7ebef] bg-[#fafbfc] px-5 py-4",
                        children: [
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                role: "alert",
                                className: "w-full text-sm text-red-700",
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 210,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>window.print(),
                                        className: "h-10 rounded-lg border border-slate-300 px-4 text-xs font-semibold text-slate-700",
                                        children: "Unduh PDF"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 215,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: onClose,
                                        className: "h-10 rounded-lg px-4 text-xs font-semibold text-slate-600",
                                        children: "Tutup"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                        lineNumber: 222,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, this),
                            !project.supervisorSignedAt && project.projectStageStatus === "finalisasi_kontrak" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                disabled: project.contractStatus !== "draft" || saving || (project.foremen ?? []).length === 0,
                                onClick: ()=>setSignatureOpen(true),
                                className: "h-10 rounded-lg bg-[#183b57] px-5 text-xs font-semibold text-white hover:bg-[#234f70] disabled:cursor-not-allowed disabled:opacity-50",
                                children: "Tanda tangani sebagai pengawas"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 232,
                                columnNumber: 15
                            }, this),
                            !project.supervisorSignedAt && project.projectStageStatus !== "finalisasi_kontrak" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-amber-800",
                                children: "Tanda tangan tersedia setelah alokasi mandor difinalisasi."
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 247,
                                columnNumber: 15
                            }, this),
                            !project.supervisorSignedAt && project.projectStageStatus === "finalisasi_kontrak" && (project.foremen ?? []).length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-amber-800",
                                children: "Alokasikan minimal satu mandor sebelum menandatangani."
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 254,
                                columnNumber: 15
                            }, this),
                            project.supervisorSignedAt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold text-emerald-800",
                                children: "Kontrak Ditandatangani"
                            }, void 0, false, {
                                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                                lineNumber: 259,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this),
                    signatureOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$contract$2f$SignaturePadModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        busy: saving,
                        onClose: ()=>setSignatureOpen(false),
                        onContinue: async (signature)=>{
                            setSaving(true);
                            setError(null);
                            try {
                                const response = await fetch(`/api/pengawas/projects/${project.id}/contract-signature`, {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        signature
                                    })
                                });
                                const result = await response.json();
                                if (!response.ok) throw new Error(result.message || "Gagal menyimpan tanda tangan.");
                                setSignatureOpen(false);
                                onClose(); // Tutup modal utama
                                router.refresh(); // Refresh data
                            } catch (err) {
                                setError(err instanceof Error ? err.message : "Gagal menyimpan tanda tangan.");
                            } finally{
                                setSaving(false);
                            }
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                        lineNumber: 265,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/pengawas/SupervisorContractModal.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
}
_s(SupervisorContractModal, "pbJQa9na9ZtxFPoSkheNzst7ehg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = SupervisorContractModal;
var _c;
__turbopack_context__.k.register(_c, "SupervisorContractModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/project-tracking.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TRACKING_MILESTONE_TEMPLATE",
    ()=>TRACKING_MILESTONE_TEMPLATE
]);
const TRACKING_MILESTONE_TEMPLATE = [
    {
        id: "persiapan-fondasi",
        title: "Pekerjaan Persiapan & Fondasi",
        description: "Penyiapan area kerja, pembersihan lahan, pengukuran, galian, dan pengecoran fondasi."
    },
    {
        id: "struktur-utama",
        title: "Pekerjaan Struktur Utama",
        description: "Pengerjaan struktur utama seperti kolom tiang, balok, pelat lantai, dan rangka atap."
    },
    {
        id: "dinding-penutup-atap",
        title: "Pekerjaan Dinding & Penutup Atap",
        description: "Pemasangan dinding bata, plesteran awal, pengerjaan kusen, dan pemasangan atap."
    },
    {
        id: "jalur-mep",
        title: "Instalasi Jalur MEP",
        description: "Instalasi jalur mekanikal, elektrikal, perpipaan air bersih/kotor, dan septic tank."
    },
    {
        id: "finishing",
        title: "Pekerjaan Finishing",
        description: "Acian dinding, pemasangan keramik/granit, plafon, pengecatan, dan sanitari."
    },
    {
        id: "lingkungan-serah-terima",
        title: "Lingkungan Luar & Serah Terima",
        description: "Pengerjaan pagar, carport, taman, pembersihan total, dan serah terima kunci."
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/access.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ServiceError",
    ()=>ServiceError,
    "assertProjectOwner",
    ()=>assertProjectOwner,
    "requireRole",
    ()=>requireRole,
    "requireUser",
    ()=>requireUser
]);
class ServiceError extends Error {
    status;
    data;
    constructor(message, status, data){
        super(message);
        this.name = "ServiceError";
        this.status = status;
        this.data = data;
    }
}
async function requireUser(supabase) {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) {
        throw new ServiceError("Anda harus login terlebih dahulu.", 401);
    }
    return user;
}
async function requireRole(supabase, expectedRole) {
    const user = await requireUser(supabase);
    const { data: profile, error } = await supabase.from("profiles").select("role").eq("id", user.id).single();
    if (error || !profile) {
        throw new ServiceError("Profil pengguna tidak ditemukan.", 403);
    }
    if (profile.role !== expectedRole) {
        throw new ServiceError(`Akses ditolak. Peran Anda (${profile.role}) tidak memiliki izin untuk tindakan ini.`, 403);
    }
    return {
        user,
        role: profile.role
    };
}
async function assertProjectOwner(supabase, projectId, userId) {
    const { data: project, error } = await supabase.from("projects").select("*").eq("id", projectId).single();
    if (error || !project) {
        throw new ServiceError("Proyek tidak ditemukan.", 404);
    }
    if (project.customer_id !== userId) {
        throw new ServiceError("Anda tidak memiliki hak akses ke proyek ini.", 403);
    }
    return project;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/allocation.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * allocation.service.ts
 *
 * Service untuk:
 * - Fitur 1: Admin mengalokasikan Pengawas ke proyek (update projects.pengawas_id)
 * - Fitur 2: Pengawas mengalokasikan Mandor ke proyek (insert into project_mandors)
 *
 * Semua validasi otoritas dilakukan di level database (RLS).
 * Tidak ada service-role key yang diekspos ke frontend.
 *
 * Pattern query mengikuti project.service.ts:
 *   data.map((row: Record<string, unknown>) => ...)
 */ __turbopack_context__.s([
    "assignMandorsToProject",
    ()=>assignMandorsToProject,
    "assignPengawasToProject",
    ()=>assignPengawasToProject,
    "canAllocateStaff",
    ()=>canAllocateStaff,
    "finalizeProjectStaffing",
    ()=>finalizeProjectStaffing,
    "getActivePengawas",
    ()=>getActivePengawas,
    "getProjectsForAdmin",
    ()=>getProjectsForAdmin,
    "getProjectsForPengawas",
    ()=>getProjectsForPengawas,
    "getVerifiedMandors",
    ()=>getVerifiedMandors,
    "removeMandorFromProject",
    ()=>removeMandorFromProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/access.service.ts [app-client] (ecmascript)");
;
function canAllocateStaff(status) {
    return status === "alokasi_mandor_pengawas";
}
async function finalizeProjectStaffing(supabase, projectId) {
    const { user } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { data: project, error: projectError } = await supabase.from("projects").select("pengawas_id, status").eq("id", projectId).single();
    if (projectError || !project) {
        console.error("[finalizeProjectStaffing] project lookup error:", projectError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek tidak ditemukan.", 404);
    }
    const projectRow = project;
    if (projectRow.pengawas_id !== user.id) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Anda tidak ditugaskan ke proyek ini.", 403);
    }
    if (projectRow.status !== "alokasi_mandor_pengawas") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek ini tidak sedang berada di tahap alokasi tim.", 409);
    }
    const { count, error: mandorError } = await supabase.from("project_mandors").select("mandor_id", {
        count: "exact",
        head: true
    }).eq("project_id", projectId);
    if (mandorError) {
        console.error("[finalizeProjectStaffing] mandor lookup error:", mandorError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa mandor yang sudah dialokasikan.", 500);
    }
    if (!count) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Alokasikan minimal satu mandor sebelum melanjutkan.", 409);
    }
    if (count > 3) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Satu proyek hanya dapat memiliki maksimal 3 mandor.", 409);
    }
    // Recheck status and roster immediately before changing the project stage.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data, error } = await supabase.from("projects").update({
        status: "finalisasi_kontrak"
    }).eq("id", projectId).eq("pengawas_id", user.id).eq("status", "alokasi_mandor_pengawas").select("id").maybeSingle();
    if (error) {
        console.error("[finalizeProjectStaffing] update error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"](error.code === "23514" ? error.message : "Gagal menyelesaikan alokasi tim.", error.code === "23514" ? 409 : 500);
    }
    if (!data) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Status proyek berubah. Muat ulang halaman lalu coba lagi.", 409);
    }
}
async function getProjectsForAdmin(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "admin");
    const { data, error } = await supabase.from("projects").select(`
      id,
      status,
      created_at,
      alamat_proyek,
      pengawas_id,
      designs ( nama ),
      profiles!projects_customer_id_fkey ( full_name, phone ),
      pengawas_profiles (
        profiles!pengawas_profiles_id_fkey ( full_name )
      )
    `).order("created_at", {
        ascending: false
    });
    if (error) {
        console.error("[getProjectsForAdmin] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat daftar proyek.", 500);
    }
    return (data ?? []).map((row)=>{
        const design = row.designs || {};
        const customer = row.profiles || {};
        const pengawasRow = row.pengawas_profiles || {};
        const pengawasProfile = pengawasRow.profiles || {};
        return {
            id: row.id ?? "",
            status: row.status ?? "draft",
            created_at: row.created_at ?? "",
            alamat_proyek: row.alamat_proyek ?? null,
            pengawas_id: row.pengawas_id ?? null,
            pengawas_name: pengawasProfile.full_name ?? null,
            customer_name: customer.full_name || "-",
            customer_phone: customer.phone ?? null,
            design_name: design.nama || "Desain Tidak Diketahui"
        };
    });
}
async function getActivePengawas(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "admin");
    const [{ data, error }, { data: assignedProjects, error: assignedError }] = await Promise.all([
        supabase.from("pengawas_profiles").select(`
      id,
      spesialisasi,
      aktif,
      profiles!pengawas_profiles_id_fkey ( full_name, phone )
    `).eq("aktif", true),
        supabase.from("projects").select("pengawas_id").not("status", "in", "(selesai,batal)").not("pengawas_id", "is", null)
    ]);
    if (error) {
        console.error("[getActivePengawas] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat daftar pengawas.", 500);
    }
    if (assignedError) {
        console.error("[getActivePengawas] assigned projects error:", assignedError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa ketersediaan pengawas.", 500);
    }
    const busyIds = new Set((assignedProjects ?? []).map((row)=>row.pengawas_id));
    return (data ?? []).map((row)=>{
        const profile = row.profiles || {};
        return {
            id: row.id ?? "",
            full_name: profile.full_name || "-",
            phone: profile.phone ?? null,
            spesialisasi: row.spesialisasi ?? null,
            aktif: row.aktif === true,
            available: !busyIds.has(row.id ?? "")
        };
    });
}
async function assignPengawasToProject(supabase, projectId, pengawasId) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "admin");
    const { data: existing, error: checkErr } = await supabase.from("projects").select("pengawas_id, status").eq("id", projectId).single();
    if (checkErr || !existing) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek tidak ditemukan.", 404);
    }
    const existingRow = existing;
    if (existingRow.pengawas_id !== null && existingRow.pengawas_id !== undefined) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek ini sudah memiliki pengawas dan tidak dapat dialokasikan ulang.", 409);
    }
    if (!canAllocateStaff(existingRow.status)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Pengawas hanya dapat dialokasikan setelah dokumen proyek berhasil diverifikasi.", 409);
    }
    const { data: busyProject, error: busyError } = await supabase.from("projects").select("id").eq("pengawas_id", pengawasId).not("status", "in", "(selesai,batal)").limit(1).maybeSingle();
    if (busyError) {
        console.error("[assignPengawasToProject] availability error:", busyError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa ketersediaan pengawas.", 500);
    }
    if (busyProject) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Pengawas tersebut masih menangani proyek aktif lain.", 409);
    }
    // Cast needed: SupabaseClient<Database> Update type resolves to never when relationships are incomplete
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await supabase.from("projects").update({
        pengawas_id: pengawasId
    }).eq("id", projectId).is("pengawas_id", null);
    if (error) {
        console.error("[assignPengawasToProject] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"](error.code === "23514" || error.code === "23505" ? error.message : "Gagal mengalokasikan pengawas.", error.code === "23514" || error.code === "23505" ? 409 : 500);
    }
}
async function getProjectsForPengawas(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Sesi tidak valid.", 401);
    const { data, error } = await supabase.from("projects").select(`
      id,
      status,
      created_at,
      alamat_proyek,
      designs ( nama ),
      profiles!projects_customer_id_fkey ( full_name ),
      contracts ( signed_pengawas_at ),
      project_mandors (
        mandor_id,
        assigned_at,
        mandor_profiles (
          keahlian,
          area_kerja,
          pengalaman_tahun,
          profiles!mandor_profiles_id_fkey ( full_name, phone )
        )
      )
    `).eq("pengawas_id", user.id).order("created_at", {
        ascending: false
    });
    if (error) {
        console.error("[getProjectsForPengawas] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat proyek Anda.", 500);
    }
    return (data ?? []).map((row)=>{
        const design = row.designs || {};
        const customer = row.profiles || {};
        const contract = Array.isArray(row.contracts) ? row.contracts[0] : row.contracts;
        const rawMandors = Array.isArray(row.project_mandors) ? row.project_mandors : [];
        const mandors = rawMandors.map((pm)=>{
            const mandorProfile = pm.mandor_profiles || {};
            const mandorUser = mandorProfile.profiles || {};
            return {
                mandor_id: pm.mandor_id ?? "",
                full_name: mandorUser.full_name || "-",
                phone: mandorUser.phone ?? null,
                keahlian: Array.isArray(mandorProfile.keahlian) ? mandorProfile.keahlian : [],
                area_kerja: mandorProfile.area_kerja ?? null,
                pengalaman_tahun: typeof mandorProfile.pengalaman_tahun === "number" ? mandorProfile.pengalaman_tahun : null,
                assigned_at: pm.assigned_at ?? ""
            };
        });
        return {
            id: row.id ?? "",
            status: row.status ?? "draft",
            created_at: row.created_at ?? "",
            alamat_proyek: row.alamat_proyek ?? null,
            design_name: design.nama || "-",
            customer_name: customer.full_name || "-",
            mandors,
            supervisorSignedAt: contract?.signed_pengawas_at ?? null
        };
    });
}
async function getVerifiedMandors(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { data: availableIds, error: availabilityError } = await supabase.rpc("get_available_mandor_ids").overrideTypes();
    if (availabilityError) {
        console.error("[getVerifiedMandors] availability error:", availabilityError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa ketersediaan mandor.", 500);
    }
    if (availableIds.length === 0) return [];
    const { data, error } = await supabase.from("mandor_profiles").select(`
      id,
      keahlian,
      area_kerja,
      pengalaman_tahun,
      profiles!mandor_profiles_id_fkey ( full_name, phone )
    `).eq("status", "approved").in("id", availableIds);
    if (error) {
        console.error("[getVerifiedMandors] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat daftar mandor.", 500);
    }
    return (data ?? []).map((row)=>{
        const profile = row.profiles || {};
        return {
            id: row.id ?? "",
            full_name: profile.full_name || "-",
            phone: profile.phone ?? null,
            keahlian: Array.isArray(row.keahlian) ? row.keahlian : [],
            area_kerja: row.area_kerja ?? null,
            pengalaman_tahun: typeof row.pengalaman_tahun === "number" ? row.pengalaman_tahun : null
        };
    });
}
async function assignMandorsToProject(supabase, projectId, mandorIds) {
    const { user } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    if (mandorIds.length === 0) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Pilih minimal satu mandor.", 400);
    }
    const { data: project, error: projectErr } = await supabase.from("projects").select("pengawas_id, status").eq("id", projectId).single();
    if (projectErr || !project) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek tidak ditemukan.", 404);
    }
    const projectRow = project;
    if (projectRow.pengawas_id !== user.id) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Anda tidak ditugaskan ke proyek ini.", 403);
    }
    if (!canAllocateStaff(projectRow.status)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Mandor hanya dapat dialokasikan setelah dokumen proyek berhasil diverifikasi.", 409);
    }
    const { data: existing, error: existingError } = await supabase.from("project_mandors").select("mandor_id").eq("project_id", projectId);
    if (existingError) {
        console.error("[assignMandorsToProject] existing mandors error:", existingError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa mandor yang sudah dialokasikan.", 500);
    }
    const existingIds = new Set((existing ?? []).map((r)=>r.mandor_id));
    const newMandorIds = [
        ...new Set(mandorIds)
    ].filter((id)=>!existingIds.has(id));
    const skipped = mandorIds.length - newMandorIds.length;
    if (newMandorIds.length === 0) {
        return {
            assigned: 0,
            skipped
        };
    }
    if (existingIds.size + newMandorIds.length > 3) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Satu proyek hanya dapat memiliki maksimal 3 mandor.", 409);
    }
    const { data: profiles, error: profilesError } = await supabase.from("mandor_profiles").select("id, keahlian").in("id", [
        ...existingIds,
        ...newMandorIds
    ]);
    if (profilesError) {
        console.error("[assignMandorsToProject] skills error:", profilesError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa keahlian mandor.", 500);
    }
    const skillSets = new Map((profiles ?? []).map((row)=>[
            row.id,
            Array.isArray(row.keahlian) ? row.keahlian : []
        ]));
    const assignedSkills = new Set();
    for (const mandorId of existingIds){
        for (const skill of skillSets.get(mandorId) ?? [])assignedSkills.add(skill);
    }
    for (const mandorId of newMandorIds){
        const skills = skillSets.get(mandorId) ?? [];
        if (skills.length === 0) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Mandor harus memiliki keahlian yang tercatat sebelum dialokasikan.", 409);
        }
        if (skills.some((skill)=>assignedSkills.has(skill))) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Setiap mandor dalam satu proyek harus memiliki keahlian yang berbeda.", 409);
        }
        for (const skill of skills)assignedSkills.add(skill);
    }
    const rows = newMandorIds.map((mandorId)=>({
            project_id: projectId,
            mandor_id: mandorId,
            assigned_by: user.id
        }));
    // Cast needed: project_mandors Insert type resolves to never when relationships are incomplete
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error: insertErr } = await supabase.from("project_mandors").insert(rows);
    if (insertErr) {
        console.error("[assignMandorsToProject] error:", insertErr);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"](insertErr.code === "23514" || insertErr.code === "23505" ? insertErr.message : `Gagal mengalokasikan mandor: ${insertErr.message}`, insertErr.code === "23514" || insertErr.code === "23505" ? 409 : 500);
    }
    return {
        assigned: newMandorIds.length,
        skipped
    };
}
async function removeMandorFromProject(supabase, projectId, mandorId) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { error } = await supabase.from("project_mandors").delete().eq("project_id", projectId).eq("mandor_id", mandorId);
    if (error) {
        console.error("[removeMandorFromProject] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal menghapus mandor dari proyek.", 500);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/progress.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateOverallProgress",
    ()=>calculateOverallProgress,
    "getCustomerProjectTracking",
    ()=>getCustomerProjectTracking,
    "getMandorProgressProjects",
    ()=>getMandorProgressProjects,
    "getPengawasProgressProjects",
    ()=>getPengawasProgressProjects,
    "getProjectIssues",
    ()=>getProjectIssues,
    "getProjectProgress",
    ()=>getProjectProgress,
    "getProjectProgressAccess",
    ()=>getProjectProgressAccess,
    "reviewProgressReport",
    ()=>reviewProgressReport,
    "stagesToMilestones",
    ()=>stagesToMilestones,
    "submitProgressReport",
    ()=>submitProgressReport,
    "submitProjectIssue",
    ()=>submitProjectIssue,
    "updateProjectIssue",
    ()=>updateProjectIssue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$project$2d$tracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/project-tracking.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/format.ts [app-client] (ecmascript)");
;
;
const MILESTONE_DURATION_WEIGHTS = [
    15,
    25,
    25,
    10,
    20,
    5
];
function addCalendarDays(date, days) {
    const [year, month, day] = date.slice(0, 10).split("-").map(Number);
    const result = new Date(Date.UTC(year, month - 1, day + days));
    return result.toISOString().slice(0, 10);
}
function jakartaDate(timestamp) {
    const parts = new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Jakarta",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }).formatToParts(new Date(timestamp));
    const value = Object.fromEntries(parts.map((part)=>[
            part.type,
            part.value
        ]));
    return `${value.year}-${value.month}-${value.day}`;
}
function milestoneSchedule(milestones, startDate, durationDays, delayByStage, stages) {
    let elapsedDays = 0;
    let totalDelayDays = 0;
    const orderedStages = [
        ...stages
    ].sort((a, b)=>a.urutan - b.urutan);
    const scheduled = milestones.map((milestone, index)=>{
        const stage = orderedStages[index];
        const previousBoundary = Math.round(durationDays * MILESTONE_DURATION_WEIGHTS.slice(0, index).reduce((sum, weight)=>sum + weight, 0) / 100);
        const nextBoundary = Math.round(durationDays * MILESTONE_DURATION_WEIGHTS.slice(0, index + 1).reduce((sum, weight)=>sum + weight, 0) / 100);
        const baseDuration = Math.max(0, nextBoundary - previousBoundary);
        const localDelay = stage ? delayByStage.get(stage.id) ?? 0 : 0;
        const targetStart = addCalendarDays(startDate, elapsedDays);
        elapsedDays += baseDuration + localDelay;
        totalDelayDays += localDelay;
        return {
            ...milestone,
            targetStart,
            targetEnd: addCalendarDays(startDate, elapsedDays),
            delayDays: localDelay
        };
    });
    return {
        milestones: scheduled,
        targetDate: addCalendarDays(startDate, elapsedDays),
        totalDelayDays
    };
}
async function getProjectProgressAccess(supabase, projectId) {
    const { data, error } = await supabase.from("projects").select("status").eq("id", projectId).maybeSingle();
    if (error) throw error;
    return data?.status ?? null;
}
const stageStatus = (status)=>{
    if (status === "selesai") return "completed";
    if (status === "berjalan") return "in-progress";
    return "pending";
};
function calculateOverallProgress(stages) {
    if (stages.length !== 6) return null;
    return Number((stages.reduce((total, stage)=>total + stage.progress_percentage, 0) / 6).toFixed(1));
}
function stagesToMilestones(stages, subtasksByStage = new Map()) {
    return [
        ...stages
    ].sort((a, b)=>a.urutan - b.urutan).map((stage)=>{
        const template = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$project$2d$tracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRACKING_MILESTONE_TEMPLATE"][stage.urutan - 1] ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$project$2d$tracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TRACKING_MILESTONE_TEMPLATE"].find((item)=>item.title.toLowerCase() === stage.nama_tahap.toLowerCase());
        const subtasks = subtasksByStage.get(stage.id) ?? [];
        const tasks = subtasks.sort((a, b)=>a.urutan - b.urutan).map((task)=>({
                id: task.id,
                title: task.judul,
                status: task.selesai ? "completed" : "pending",
                weight: Number(task.bobot ?? 0),
                completedAt: task.completed_at ?? undefined
            }));
        // Hitung progres tahap secara dinamis dari bobot subtask
        const totalWeight = subtasks.reduce((sum, item)=>sum + Number(item.bobot ?? 0), 0);
        const doneWeight = subtasks.filter((item)=>item.selesai).reduce((sum, item)=>sum + Number(item.bobot ?? 0), 0);
        const progress = totalWeight > 0 ? Math.min(100, Math.round(doneWeight / totalWeight * 100)) : stage.progress_percentage;
        let status = "pending";
        if (progress >= 100 || stage.status === "selesai") {
            status = "completed";
        } else if (progress > 0 || stage.status === "berjalan") {
            status = "in-progress";
        } else {
            status = stageStatus(stage.status);
        }
        return {
            id: template?.id ?? stage.id,
            title: stage.nama_tahap,
            description: stage.keterangan ?? template?.description ?? "",
            status,
            progress,
            startedAt: stage.tanggal_mulai ?? undefined,
            completedAt: stage.tanggal_selesai ?? undefined,
            updatedAt: stage.updated_at,
            tasks
        };
    });
}
async function getProjectProgress(supabase, projectId, options = {}) {
    const stagesResult = await supabase.from("project_stages").select("*").eq("project_id", projectId).order("urutan", {
        ascending: true
    });
    if (stagesResult.error) throw stagesResult.error;
    const stages = stagesResult.data ?? [];
    if (stages.length === 0) {
        return {
            stages,
            reports: [],
            overallProgress: null
        };
    }
    const stageIds = stages.map((stage)=>stage.id);
    const { data: subtasksData } = await supabase.from("project_subtasks").select("project_stage_id, bobot, selesai").in("project_stage_id", stageIds);
    const subtasks = subtasksData ?? [];
    const subtasksByStage = new Map();
    for (const st of subtasks){
        const list = subtasksByStage.get(st.project_stage_id) ?? [];
        list.push(st);
        subtasksByStage.set(st.project_stage_id, list);
    }
    const updatedStages = stages.map((stage)=>{
        const stageSubtasks = subtasksByStage.get(stage.id) ?? [];
        const totalWeight = stageSubtasks.reduce((sum, item)=>sum + Number(item.bobot ?? 0), 0);
        const doneWeight = stageSubtasks.filter((item)=>item.selesai).reduce((sum, item)=>sum + Number(item.bobot ?? 0), 0);
        const progress = totalWeight > 0 ? Math.min(100, Math.round(doneWeight / totalWeight * 100)) : stage.progress_percentage;
        const status = progress >= 100 ? "selesai" : progress > 0 ? "berjalan" : stage.status === "berjalan" ? "berjalan" : stage.status;
        return {
            ...stage,
            progress_percentage: progress,
            status
        };
    });
    const totalAllWeight = subtasks.reduce((sum, item)=>sum + Number(item.bobot ?? 0), 0);
    const doneAllWeight = subtasks.filter((item)=>item.selesai).reduce((sum, item)=>sum + Number(item.bobot ?? 0), 0);
    const overallProgress = totalAllWeight > 0 ? Number(doneAllWeight.toFixed(1)) : calculateOverallProgress(updatedStages);
    let reportsQuery = supabase.from("progress_reports").select("*").in("project_stage_id", stageIds).order("created_at", {
        ascending: false
    });
    if (options.customerOnly) reportsQuery = reportsQuery.eq("status", "verified");
    const reportsResult = await reportsQuery;
    if (reportsResult.error) throw reportsResult.error;
    return {
        stages: updatedStages,
        reports: reportsResult.data ?? [],
        overallProgress
    };
}
async function getCustomerProjectTracking(supabase, projectId) {
    const { stages, reports, overallProgress: baseOverallProgress } = await getProjectProgress(supabase, projectId, {
        customerOnly: true
    });
    const stageIds = stages.map((stage)=>stage.id);
    const [subtasksResult, updatesResult, documentationResult, contractResult, resolutionsResult, paymentResult, projectResult] = await Promise.all([
        stageIds.length ? supabase.from("project_subtasks").select("id, project_stage_id, judul, bobot, urutan, target_selesai, selesai, completed_at, created_at").in("project_stage_id", stageIds).order("urutan", {
            ascending: true
        }) : Promise.resolve({
            data: [],
            error: null
        }),
        supabase.from("project_updates").select("id, judul, isi, created_at").eq("project_id", projectId).order("created_at", {
            ascending: false
        }),
        supabase.from("progress_documentation").select("id, project_stage_id, url, catatan, created_at").eq("project_id", projectId).order("created_at", {
            ascending: false
        }),
        supabase.from("contracts").select("tanggal_mulai, tanggal_selesai_estimasi, created_at").eq("project_id", projectId).order("created_at", {
            ascending: false
        }).limit(1).maybeSingle(),
        supabase.from("issue_resolutions").select(`
          id,
          kendala_id,
          solusi,
          alasan_persetujuan,
          bukti,
          dampak_type,
          tambahan_biaya,
          tambahan_hari,
          status,
          created_at,
          kendala ( kategori, deskripsi, project_stage_id ),
          resolution_discussions (
            id, penulis, pesan, dampak_type, tambahan_biaya, tambahan_hari, created_at
          )
        `).eq("project_id", projectId).order("created_at", {
            ascending: false
        }),
        supabase.from("payment_stages").select("tanggal_bayar").eq("project_id", projectId).eq("urutan", 0).eq("status", "lunas").maybeSingle(),
        supabase.from("projects").select("design_id").eq("id", projectId).maybeSingle()
    ]);
    if (subtasksResult.error) throw subtasksResult.error;
    if (updatesResult.error) throw updatesResult.error;
    if (documentationResult.error) throw documentationResult.error;
    if (contractResult.error) throw contractResult.error;
    if (resolutionsResult.error) throw resolutionsResult.error;
    if (paymentResult.error) throw paymentResult.error;
    if (projectResult.error) throw projectResult.error;
    const designResult = projectResult.data?.design_id ? await supabase.from("designs").select("estimasi_durasi_hari").eq("id", projectResult.data.design_id).maybeSingle() : null;
    if (designResult?.error) throw designResult.error;
    const allSubtasks = subtasksResult.data ?? [];
    const totalSubtasksWeight = allSubtasks.reduce((sum, s)=>sum + Number(s.bobot ?? 0), 0);
    const doneSubtasksWeight = allSubtasks.filter((s)=>s.selesai).reduce((sum, s)=>sum + Number(s.bobot ?? 0), 0);
    const overallProgress = totalSubtasksWeight > 0 ? Number(doneSubtasksWeight.toFixed(1)) : baseOverallProgress;
    const subtasksByStage = new Map();
    for (const subtask of allSubtasks){
        const current = subtasksByStage.get(subtask.project_stage_id) ?? [];
        current.push(subtask);
        subtasksByStage.set(subtask.project_stage_id, current);
    }
    let milestones = stagesToMilestones(stages, subtasksByStage);
    milestones = milestones.map((milestone, index)=>{
        if (milestone.startedAt || milestone.status !== "in-progress") return milestone;
        const stage = [
            ...stages
        ].sort((a, b)=>a.urutan - b.urutan)[index];
        if (!stage) return milestone;
        const observedStartDates = [
            ...reports.filter((report)=>report.project_stage_id === stage.id).map((report)=>report.verified_at ?? report.created_at),
            ...(subtasksByStage.get(stage.id) ?? []).map((subtask)=>subtask.completed_at).filter((date)=>Boolean(date))
        ].sort((a, b)=>a.localeCompare(b));
        return {
            ...milestone,
            startedAt: observedStartDates[0]?.slice(0, 10) ?? stage.updated_at?.slice(0, 10) ?? undefined
        };
    });
    const milestoneIdByStageId = new Map(stages.map((stage, index)=>[
            stage.id,
            milestones[index]?.id
        ]));
    const updateActivities = (updatesResult.data ?? []).map((update)=>({
            id: update.id,
            title: update.judul,
            description: update.isi,
            createdAt: update.created_at,
            authorName: "Pengawas",
            authorRole: "Pengawas"
        }));
    const documentationGallery = (documentationResult.data ?? []).map((item)=>({
            id: item.id,
            src: item.url,
            alt: "Dokumentasi pembangunan proyek",
            caption: item.catatan ?? undefined,
            createdAt: item.created_at,
            milestoneId: item.project_stage_id ? milestoneIdByStageId.get(item.project_stage_id) : undefined
        }));
    const rawResolutions = resolutionsResult.data ?? [];
    const delayByStage = new Map();
    const countedIssues = new Set();
    for (const resolution of rawResolutions){
        const issueId = String(resolution.kendala_id ?? "");
        if (!issueId || countedIssues.has(issueId)) continue;
        countedIssues.add(issueId);
        const status = String(resolution.status ?? "");
        const days = Number(resolution.tambahan_hari ?? 0);
        const issue = resolution.kendala ?? {};
        const stageId = String(issue.project_stage_id ?? "");
        if (!stageId || ![
            "Ditindaklanjuti",
            "resolved"
        ].includes(status) || ![
            "waktu",
            "biaya_dan_waktu"
        ].includes(String(resolution.dampak_type)) || !Number.isFinite(days) || days <= 0) continue;
        delayByStage.set(stageId, (delayByStage.get(stageId) ?? 0) + days);
    }
    const resolutions = rawResolutions.map((res)=>{
        const k = res.kendala ?? {};
        const rawDisc = Array.isArray(res.resolution_discussions) ? res.resolution_discussions : [];
        const discussion = rawDisc.map((d)=>({
                id: String(d.id),
                author: String(d.penulis ?? "Pengawas"),
                message: String(d.pesan ?? ""),
                date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(String(d.created_at)),
                impactType: d.dampak_type === "biaya" || d.dampak_type === "waktu" || d.dampak_type === "biaya_dan_waktu" ? d.dampak_type : null,
                additionalCost: d.tambahan_biaya == null ? null : Number(d.tambahan_biaya),
                additionalDays: d.tambahan_hari == null ? null : Number(d.tambahan_hari)
            }));
        return {
            id: String(res.id),
            issueId: String(res.kendala_id),
            issueTitle: String(k.kategori ?? "Kendala Lapangan"),
            solution: String(res.solusi ?? ""),
            approvalReason: String(res.alasan_persetujuan ?? ""),
            approvalEvidence: res.bukti ?? null,
            impactType: res.dampak_type === "biaya" || res.dampak_type === "waktu" || res.dampak_type === "biaya_dan_waktu" ? res.dampak_type : null,
            additionalCost: res.tambahan_biaya == null ? null : Number(res.tambahan_biaya),
            additionalDays: res.tambahan_hari == null ? null : Number(res.tambahan_hari),
            status: String(res.status ?? ""),
            submittedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$format$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(String(res.created_at)),
            discussion
        };
    });
    const dpPaidAt = paymentResult.data?.tanggal_bayar ? jakartaDate(paymentResult.data.tanggal_bayar) : undefined;
    const designDuration = Number(designResult?.data?.estimasi_durasi_hari ?? 0);
    const schedule = dpPaidAt && designDuration > 0 ? milestoneSchedule(milestones, dpPaidAt, designDuration, delayByStage, stages) : null;
    if (schedule) milestones = schedule.milestones;
    return {
        startedAt: dpPaidAt ?? contractResult.data?.tanggal_mulai ?? stages.find((stage)=>stage.tanggal_mulai)?.tanggal_mulai ?? undefined,
        targetDate: schedule?.targetDate ?? contractResult.data?.tanggal_selesai_estimasi ?? undefined,
        totalDelayDays: schedule?.totalDelayDays ?? 0,
        overallProgress,
        milestones,
        activities: updateActivities,
        gallery: [
            ...reports.filter((report)=>Boolean(report.foto_url)).map((report)=>({
                    id: report.id,
                    src: report.foto_url,
                    alt: "Dokumentasi progress proyek",
                    caption: report.keterangan ?? undefined,
                    createdAt: report.verified_at ?? report.created_at,
                    milestoneId: milestoneIdByStageId.get(report.project_stage_id)
                })),
            ...documentationGallery
        ],
        resolutions
    };
}
async function getProjectsByIds(supabase, projectIds) {
    if (!projectIds.length) return [];
    const { data: projects, error } = await supabase.from("projects").select("id, customer_id, alamat_proyek, status, design_id").in("id", projectIds);
    if (error) throw error;
    const designIds = [
        ...new Set((projects ?? []).map((project)=>project.design_id))
    ];
    const { data: designs, error: designsError } = await supabase.from("designs").select("id, nama").in("id", designIds);
    if (designsError) throw designsError;
    const customerIds = [
        ...new Set((projects ?? []).map((project)=>project.customer_id))
    ];
    const { data: customers, error: customersError } = await supabase.from("profiles").select("id, full_name").in("id", customerIds);
    if (customersError) throw customersError;
    return Promise.all((projects ?? []).map(async (project)=>{
        const progress = await getProjectProgress(supabase, project.id);
        return {
            id: project.id,
            customerId: project.customer_id,
            customerName: customers?.find((customer)=>customer.id === project.customer_id)?.full_name ?? "Customer",
            designName: designs?.find((design)=>design.id === project.design_id)?.nama ?? "Desain rumah",
            address: project.alamat_proyek,
            status: project.status,
            ...progress
        };
    }));
}
async function getMandorProgressProjects(supabase) {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError) throw userError;
    if (!userData.user) return [];
    const { data: assignments, error } = await supabase.from("project_mandors").select("project_id").eq("mandor_id", userData.user.id);
    if (error) throw error;
    return getProjectsByIds(supabase, (assignments ?? []).map((assignment)=>assignment.project_id));
}
async function getPengawasProgressProjects(supabase) {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError) throw userError;
    if (!userData.user) return [];
    const { data: projects, error } = await supabase.from("projects").select("id").eq("pengawas_id", userData.user.id);
    if (error) throw error;
    return getProjectsByIds(supabase, (projects ?? []).map((project)=>project.id));
}
async function submitProgressReport(supabase, input) {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError) throw userError;
    if (!userData.user) throw new Error("Sesi pengguna tidak ditemukan.");
    const { data, error } = await supabase.from("progress_reports").insert({
        project_stage_id: input.projectStageId,
        mandor_id: userData.user.id,
        persentase: input.persentase,
        keterangan: input.keterangan,
        foto_url: input.fotoUrl ?? null,
        status: "pending",
        keputusan: "menunggu"
    }).select().single();
    if (error) throw error;
    return data;
}
async function reviewProgressReport(supabase, reportId, decision, feedback) {
    if (decision === "approve") {
        const { data, error } = await supabase.rpc("approve_progress_report", {
            report_id: reportId,
            review_note: feedback ?? null
        });
        if (error) throw error;
        return data;
    }
    const { data, error } = await supabase.rpc("reject_progress_report", {
        report_id: reportId,
        review_note: feedback ?? ""
    });
    if (error) throw error;
    return data;
}
async function getProjectIssues(supabase, projectId) {
    const { data, error } = await supabase.from("kendala").select("*").eq("project_id", projectId).order("created_at", {
        ascending: false
    });
    if (error) throw error;
    return data ?? [];
}
async function submitProjectIssue(supabase, input) {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError) throw userError;
    if (!userData.user) throw new Error("Sesi pengguna tidak ditemukan.");
    const { data, error } = await supabase.from("kendala").insert({
        project_id: input.projectId,
        project_stage_id: input.projectStageId ?? null,
        reported_by: userData.user.id,
        deskripsi: input.description,
        status: "reported"
    }).select().single();
    if (error) throw error;
    return data;
}
async function updateProjectIssue(supabase, issueId, values) {
    const { data, error } = await supabase.from("kendala").update(values).eq("id", issueId).select().single();
    if (error) throw error;
    return data;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/format.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatDate",
    ()=>formatDate,
    "formatDateOnly",
    ()=>formatDateOnly,
    "formatDateTimeComma",
    ()=>formatDateTimeComma,
    "formatDateTimeDot",
    ()=>formatDateTimeDot,
    "formatMonthDay",
    ()=>formatMonthDay,
    "formatRupiah",
    ()=>formatRupiah
]);
const formatRupiah = (value)=>`Rp ${new Intl.NumberFormat("id-ID").format(value)}`;
const formatDate = (isoDate)=>new Intl.DateTimeFormat("id-ID", {
        day: "numeric",
        month: "short",
        year: "numeric"
    }).format(new Date(isoDate));
const formatDateTimeComma = (iso)=>new Intl.DateTimeFormat("id-ID", {
        dateStyle: "medium",
        timeStyle: "short"
    }).format(new Date(iso));
const formatDateTimeDot = (iso)=>{
    const date = new Intl.DateTimeFormat("id-ID", {
        dateStyle: "medium"
    }).format(new Date(iso));
    const time = new Intl.DateTimeFormat("id-ID", {
        timeStyle: "short"
    }).format(new Date(iso));
    return `${date} · ${time}`;
};
const formatMonthDay = (iso)=>new Intl.DateTimeFormat("id-ID", {
        day: "numeric",
        month: "short"
    }).format(new Date(iso));
const formatDateOnly = (iso)=>{
    const safe = iso.length === 10 ? `${iso}T00:00:00` : iso;
    return formatDate(safe);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_04v-xb4._.js.map
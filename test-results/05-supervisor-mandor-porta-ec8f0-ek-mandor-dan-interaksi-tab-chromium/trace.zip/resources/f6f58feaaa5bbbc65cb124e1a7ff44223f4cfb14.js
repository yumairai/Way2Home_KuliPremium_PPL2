(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/mandor/MandorProjectDetail.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MandorProjectDetail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mandor$2f$MandorShell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/mandor/MandorShell.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useMandorProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useMandorProjects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/image.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
const reviewClass = {
    Menunggu: "bg-[#fff4e2] text-[#98651e]",
    Disetujui: "bg-[#edf6ef] text-[#4d7d56]",
    "Perlu revisi": "bg-[#fff0f0] text-[#a75252]",
    Ditindaklanjuti: "bg-[#eaf2f8] text-[#416f91]",
    Selesai: "bg-[#edf6ef] text-[#4d7d56]"
};
const isApproved = (task, milestone, approved)=>task.done || approved.some((item)=>item.milestoneId === milestone.id && item.subtaskTitle === task.title);
const milestoneState = (milestone, approved)=>{
    const doneCount = milestone.subtasks.filter((task)=>isApproved(task, milestone, approved)).length;
    if (doneCount === 0) return "Menunggu";
    if (doneCount === milestone.subtasks.length) return "Selesai";
    return "Berjalan";
};
const milestoneProgress = (milestone, approved)=>{
    const doneWeight = milestone.subtasks.filter((task)=>isApproved(task, milestone, approved)).reduce((sum, task)=>sum + task.weight, 0);
    if (!Number.isFinite(milestone.weight) || milestone.weight <= 0) return 0;
    return Math.min(100, Math.max(0, Math.round(doneWeight / milestone.weight * 100)));
};
const formatNow = ()=>new Intl.DateTimeFormat("id-ID", {
        dateStyle: "medium",
        timeStyle: "short"
    }).format(new Date());
function MandorProjectDetail({ id }) {
    _s();
    const { status, loading: statusLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mandor$2f$MandorShell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMandorStatus"])();
    const { project, loading: projectLoading, reload } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useMandorProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMandorProject"])(id);
    const [tab, setTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Ringkasan");
    const [progressOpen, setProgressOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [issueOpen, setIssueOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    if (statusLoading || projectLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mx-auto max-w-4xl px-5 py-10",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "rounded-2xl border border-[#e3e9ef] bg-white p-10 text-center text-sm text-slate-500",
            children: "Memuat halaman..."
        }, void 0, false, {
            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
            lineNumber: 82,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 81,
        columnNumber: 7
    }, this);
    if (!project) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notFound"])();
    if (status !== "Disetujui") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mx-auto max-w-4xl px-5 py-10",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "rounded-2xl border border-[#e3e9ef] bg-white p-8 text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-xl font-bold text-[#203c54]",
                    children: "Detail pekerjaan belum tersedia"
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 92,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-2 text-sm text-slate-500",
                    children: "Akses pekerjaan tersedia setelah pendaftaran disetujui."
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 95,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/mandor",
                    className: "mt-4 inline-block text-sm font-semibold text-[#35658a] underline",
                    children: "Kembali ke ringkasan"
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 98,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
            lineNumber: 91,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 90,
        columnNumber: 7
    }, this);
    if (project.status && project.status !== "berjalan" && project.status !== "selesai") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mx-auto max-w-2xl px-5 py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "rounded-2xl border border-[#e2e8ed] bg-white p-8 text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-xl font-bold text-[#183b57]",
                    children: "Tracking belum tersedia"
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 116,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-2 text-sm text-slate-500",
                    children: project.status === "pembayaran_dp" ? "Tracking proyek tersedia setelah pembayaran DP terverifikasi." : "Tracking proyek belum tersedia pada tahap proyek ini."
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 119,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/mandor/proyek",
                    className: "mt-4 inline-block text-sm font-semibold text-[#35658a] underline",
                    children: "Kembali ke proyek"
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 124,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
            lineNumber: 115,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 114,
        columnNumber: 7
    }, this);
    // Subtask sudah ditandai `done` oleh backend saat pengawas memverifikasi,
    // sehingga daftar persetujuan tambahan tidak diperlukan lagi.
    const approvedSubtasks = [];
    const officialProgress = project.overallProgress;
    const reportDecision = (reportId)=>project.progressReports.find((report)=>report.id === reportId)?.review ?? "Menunggu";
    const showError = (message)=>{
        setToast(message);
        window.setTimeout(()=>setToast(""), 5000);
    };
    const addProgress = async (report, subtaskId)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`/api/mandor/projects/${id}/progress`, {
                project_subtask_id: subtaskId,
                keterangan: report.note,
                foto_url: report.photo
            });
            await reload();
            setProgressOpen(false);
            setToast("Laporan progress terkirim dan menunggu verifikasi pengawas.");
            window.setTimeout(()=>setToast(""), 4000);
        } catch (error) {
            showError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(error, "Gagal mengirim laporan progress."));
        }
    };
    const addIssue = async (report, ids)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`/api/mandor/projects/${id}/kendala`, {
                project_stage_id: ids.stageId,
                project_subtask_id: ids.subtaskId,
                kategori: report.category,
                deskripsi: report.description,
                kondisi_pekerjaan: report.workCondition,
                dampak_waktu_hari: report.estimatedDelayDays,
                informasi_tambahan: report.additionalInfo,
                lampiran: report.attachment,
                lampiran_nama: report.attachmentName
            });
            await reload();
            setIssueOpen(false);
            setToast("Laporan kendala terkirim kepada pengawas.");
            window.setTimeout(()=>setToast(""), 4000);
        } catch (error) {
            showError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(error, "Gagal mengirim laporan kendala."));
        }
    };
    const submitNote = async (note)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])(`/api/mandor/projects/${id}/notes`, {
                catatan: note
            });
            await reload();
            setToast("Catatan untuk pengawas terkirim.");
            window.setTimeout(()=>setToast(""), 4000);
        } catch (error) {
            showError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(error, "Gagal mengirim catatan."));
        }
    };
    const weightedReports = project.progressReports;
    const pendingMilestones = new Set(project.progressReports.filter((report)=>report.review === "Menunggu").map((report)=>report.milestoneTitle));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mx-auto max-w-[1480px] space-y-5 px-4 py-5 sm:px-6 md:py-7",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/mandor/proyek",
                className: "text-xs font-semibold text-[#35658a] hover:underline",
                children: "‹ Kembali ke proyek"
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 211,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "overflow-hidden rounded-2xl border border-[#e3e9ef] bg-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative h-44 sm:h-60",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: project.image,
                                alt: `Desain ${project.title}`,
                                fill: true,
                                sizes: "100vw",
                                className: "object-cover"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 219,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "absolute left-4 top-4 rounded-md bg-white/95 px-3 py-1.5 text-xs font-semibold text-[#365c78]",
                                children: [
                                    "#",
                                    project.id
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 226,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 218,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col justify-between gap-4 p-5 sm:flex-row sm:items-end sm:p-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-[#53738d]",
                                        children: project.design
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 232,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "mt-1 text-2xl font-bold text-[#183b57]",
                                        children: project.title
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 233,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 text-xs text-slate-500",
                                        children: project.location
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 236,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 231,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-left sm:text-right",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] text-slate-500",
                                        children: "Progres resmi proyek"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 239,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-2xl font-bold text-[#315b76]",
                                        children: [
                                            officialProgress,
                                            "%"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 240,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] text-slate-500",
                                        children: [
                                            "Target ",
                                            project.target
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 243,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 238,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 230,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 217,
                columnNumber: 7
            }, this),
            toast && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "status",
                className: "rounded-lg border border-[#cfe3d2] bg-[#edf7ee] px-4 py-3 text-sm text-[#3f7049]",
                children: toast
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 250,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col justify-between gap-3 sm:flex-row sm:items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex max-w-full gap-1 overflow-x-auto rounded-xl border border-[#dfe6ec] bg-white p-1",
                        "aria-label": "Bagian detail pekerjaan",
                        children: [
                            "Ringkasan",
                            "Laporan progress",
                            "Kendala"
                        ].map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setTab(item),
                                className: `min-h-9 shrink-0 rounded-lg px-3 text-xs font-semibold ${tab === item ? "bg-[#2B3361] text-white" : "text-slate-600 hover:bg-slate-50"}`,
                                children: item
                            }, item, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 264,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 258,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setProgressOpen(true),
                                className: "min-h-10 flex-1 rounded-lg bg-[#2B3361] px-4 text-xs font-semibold text-white hover:bg-[#21274b] sm:flex-none",
                                children: "Lapor progress"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 275,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setIssueOpen(true),
                                className: "min-h-10 flex-1 rounded-lg border border-[#d99a9a] bg-[#a94444] px-4 text-xs font-semibold text-white hover:bg-[#913838] sm:flex-none",
                                children: "Laporkan kendala"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 281,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 257,
                columnNumber: 7
            }, this),
            tab === "Ringkasan" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-5 xl:grid-cols-[minmax(0,1.25fr)_minmax(300px,0.75fr)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-base font-bold text-[#263d53]",
                                        children: "Tahapan dan pekerjaan"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 293,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-xs text-slate-500",
                                        children: "Rincian tahap bersifat read-only. Kirim laporan jika ada perkembangan pekerjaan."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 296,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4 space-y-3",
                                        children: project.milestones.map((milestone)=>{
                                            const state = milestoneState(milestone, approvedSubtasks);
                                            const progress = milestoneProgress(milestone, approvedSubtasks);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                                className: "rounded-xl border border-[#e7ecf0] p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex flex-wrap items-start justify-between gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        className: "text-sm font-semibold text-[#29465e]",
                                                                        children: milestone.title
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                        lineNumber: 314,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "mt-1 text-[10px] text-slate-500",
                                                                        children: [
                                                                            "Target ",
                                                                            milestone.target,
                                                                            " · Bobot ",
                                                                            milestone.weight,
                                                                            "%"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                        lineNumber: 317,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                lineNumber: 313,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `rounded-full px-2.5 py-1 text-[10px] font-semibold ${state === "Selesai" ? reviewClass.Disetujui : state === "Berjalan" ? "bg-[#eaf2f8] text-[#416f91]" : "bg-[#f0f2f5] text-[#718096]"}`,
                                                                children: state
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                lineNumber: 322,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 312,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-3 flex items-center justify-between text-[10px] text-slate-500",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Progress tahap"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                lineNumber: 329,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                                children: [
                                                                    progress,
                                                                    "%"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                lineNumber: 330,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 328,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-1.5 h-1.5 overflow-hidden rounded-full bg-[#e9edf2]",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "block h-full rounded-full bg-[#5e83a0]",
                                                            style: {
                                                                width: `${progress}%`
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                            lineNumber: 333,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 332,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "mt-3 space-y-2",
                                                        children: milestone.subtasks.map((task)=>{
                                                            const done = isApproved(task, milestone, approvedSubtasks);
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                className: "flex items-center justify-between gap-2 text-xs text-slate-600",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "flex items-center gap-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: `grid h-4 w-4 place-items-center rounded border text-[9px] ${done ? "border-[#71947b] bg-[#edf6ef] text-[#4d7d56]" : "border-slate-300"}`,
                                                                                children: done ? "✓" : ""
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                                lineNumber: 351,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            task.title
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                        lineNumber: 350,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "shrink-0 text-[10px] font-medium text-slate-400",
                                                                        children: [
                                                                            task.weight,
                                                                            "%"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                        lineNumber: 358,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, task.id, true, {
                                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                                lineNumber: 346,
                                                                columnNumber: 29
                                                            }, this);
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 338,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, milestone.id, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 308,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 300,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 292,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-base font-bold text-[#263d53]",
                                        children: "Lingkup pekerjaan"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 371,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "mt-3 grid gap-2 sm:grid-cols-2",
                                        children: project.scope.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "rounded-lg bg-[#f7f9fb] px-3 py-2.5 text-xs leading-5 text-slate-600",
                                                children: item
                                            }, item, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 376,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 374,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 370,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 291,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                        className: "space-y-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-base font-bold text-[#263d53]",
                                        children: "Arahan pengawas"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 388,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-3 text-sm leading-6 text-slate-600",
                                        children: project.supervisorNote
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 391,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-4 border-t border-[#edf0f3] pt-3 text-xs font-semibold text-[#416f91]",
                                        children: project.supervisor
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 394,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 387,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NotesCard, {
                                notes: project.notes,
                                onSubmit: submitNote
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 398,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-base font-bold text-[#263d53]",
                                        children: "Informasi penugasan"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 400,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                                        className: "mt-4 space-y-3 text-xs",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                        className: "text-slate-500",
                                                        children: "Ditugaskan"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 405,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                        className: "font-medium text-[#29465e]",
                                                        children: project.assignedAt
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 406,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 404,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                        className: "text-slate-500",
                                                        children: "Tahap berjalan"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 411,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                        className: "text-right font-medium text-[#29465e]",
                                                        children: project.currentMilestone
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 412,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 410,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                        className: "text-slate-500",
                                                        children: "Target selesai"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 417,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                        className: "font-medium text-[#29465e]",
                                                        children: project.target
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 418,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 416,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 403,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 399,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 386,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 290,
                columnNumber: 9
            }, this),
            tab === "Laporan progress" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Reports, {
                reports: weightedReports,
                reviewFor: reportDecision,
                pendingMilestones: pendingMilestones
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 428,
                columnNumber: 9
            }, this),
            tab === "Kendala" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Issues, {
                reports: project.issueReports
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 434,
                columnNumber: 29
            }, this),
            progressOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ProgressModal, {
                project: project,
                approvedSubtasks: approvedSubtasks,
                onClose: ()=>setProgressOpen(false),
                onSubmit: addProgress
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 436,
                columnNumber: 9
            }, this),
            issueOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IssueModal, {
                project: project,
                approvedSubtasks: approvedSubtasks,
                onClose: ()=>setIssueOpen(false),
                onSubmit: addIssue
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 444,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
_s(MandorProjectDetail, "O4/jTt4Ttqj3vMdTUyV0onPJ4Q8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mandor$2f$MandorShell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMandorStatus"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useMandorProjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMandorProject"]
    ];
});
_c = MandorProjectDetail;
function NotesCard({ notes, onSubmit }) {
    _s1();
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-base font-bold text-[#263d53]",
                children: "Catatan untuk pengawas"
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 466,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-xs text-slate-500",
                children: "Catatan singkat terpisah dari laporan progress dan kendala."
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 469,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                className: "mt-4",
                onSubmit: (event)=>{
                    event.preventDefault();
                    if (draft.trim().length < 5) {
                        setError("Catatan minimal 5 karakter.");
                        return;
                    }
                    onSubmit(draft.trim());
                    setDraft("");
                    setError("");
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "note-supervisor",
                        className: "block text-xs font-semibold text-[#29465e]",
                        children: [
                            "Tulis catatan",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                id: "note-supervisor",
                                value: draft,
                                onChange: (event)=>setDraft(event.target.value),
                                rows: 3,
                                maxLength: 400,
                                placeholder: "Contoh: tim sudah menyesuaikan metode kerja sesuai arahan terakhir...",
                                className: "mt-1.5 w-full rounded-lg border border-[#dfe6ed] p-3 text-sm font-normal outline-none focus:border-[#5b7c99]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 490,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 485,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        role: "alert",
                        className: "mt-2 text-xs text-red-700",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 501,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "mt-2 min-h-9 rounded-lg bg-[#2B3361] px-4 text-xs font-semibold text-white hover:bg-[#21274b]",
                        children: "Kirim ke pengawas"
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 505,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 472,
                columnNumber: 7
            }, this),
            notes.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 space-y-2 border-t border-[#edf0f3] pt-4",
                children: notes.map((note)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "rounded-lg bg-[#f7f9fb] p-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs leading-5 text-slate-600",
                                children: note.note
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 516,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-[10px] text-slate-400",
                                children: [
                                    note.submitted,
                                    " · untuk pengawas"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 517,
                                columnNumber: 15
                            }, this)
                        ]
                    }, note.id, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 515,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 513,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 465,
        columnNumber: 5
    }, this);
}
_s1(NotesCard, "KdGkDdMzCvVgmmg0oq8BmvST+64=");
_c1 = NotesCard;
function Reports({ reports, reviewFor, pendingMilestones }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-base font-bold text-[#263d53]",
                children: "Riwayat laporan progress"
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 539,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 text-xs text-slate-500",
                children: "Laporan yang sedang ditinjau pengawas ditandai dengan status menunggu."
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 542,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 space-y-3",
                children: reports.map((report)=>{
                    const review = reviewFor(report.id);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "rounded-xl border border-[#e5eaf0] p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap items-start justify-between gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] font-semibold uppercase tracking-wide text-slate-400",
                                                children: report.milestoneTitle
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 555,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "mt-1 text-sm font-semibold text-[#29465e]",
                                                children: report.subtaskTitle
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 558,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-[10px] text-slate-500",
                                                children: [
                                                    report.id,
                                                    " · ",
                                                    report.submitted
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 561,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 554,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col items-end gap-1.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `rounded-full px-2.5 py-1 text-[10px] font-semibold ${reviewClass[review]}`,
                                                children: review === "Menunggu" ? "Menunggu verifikasi" : review
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 566,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full bg-[#f0f3f6] px-2.5 py-1 text-[9px] font-semibold text-slate-500",
                                                children: [
                                                    "Bobot +",
                                                    report.weight,
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 571,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 565,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 553,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-3 text-xs leading-5 text-slate-600",
                                children: report.note
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 576,
                                columnNumber: 15
                            }, this),
                            report.photo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-3 overflow-hidden rounded-lg border border-[#e6ebef]",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: report.photo,
                                    alt: `Dokumentasi ${report.subtaskTitle}`,
                                    className: "h-40 w-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 582,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 580,
                                columnNumber: 17
                            }, this),
                            report.feedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-3 rounded-lg bg-[#f4f7fa] p-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-semibold text-[#416f91]",
                                        children: "Feedback pengawas"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 591,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-xs leading-5 text-slate-600",
                                        children: report.feedback
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 594,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 590,
                                columnNumber: 17
                            }, this),
                            review === "Menunggu" && pendingMilestones.has(report.milestoneTitle) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-3 rounded-lg bg-[#fff8ec] px-3 py-2 text-[10px] leading-4 text-[#8a6a2e]",
                                children: "Subtask menunggu verifikasi pengawas sebelum dihitung ke progres resmi."
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 601,
                                columnNumber: 19
                            }, this)
                        ]
                    }, report.id, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 549,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 545,
                columnNumber: 7
            }, this),
            reports.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "py-8 text-center text-sm text-slate-500",
                children: "Belum ada laporan progress."
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 611,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 538,
        columnNumber: 5
    }, this);
}
_c2 = Reports;
function Issues({ reports }) {
    _s2();
    const [expanded, setExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const formatCurrency = (value)=>new Intl.NumberFormat("id-ID", {
            style: "currency",
            currency: "IDR",
            maximumFractionDigits: 0
        }).format(value);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-[#e3e9ef] bg-white p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setExpanded((value)=>!value),
                "aria-expanded": expanded,
                className: "flex w-full items-center justify-between gap-4 text-left focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#477ba6]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "block text-base font-bold text-[#263d53]",
                                children: "Laporan kendala lapangan"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 636,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "mt-1 block text-xs text-slate-500",
                                children: reports.length ? `${reports.length} laporan kendala` : "Kendala yang dikirim akan diterima pengawas untuk ditinjau."
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 639,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 635,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "shrink-0 text-xs font-semibold text-[#416f91]",
                        children: expanded ? "Sembunyikan ▲" : "Tampilkan ▼"
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 645,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 629,
                columnNumber: 7
            }, this),
            expanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 space-y-3",
                children: reports.map((report)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "rounded-xl border border-[#e5eaf0] bg-white p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                className: "flex cursor-pointer list-none flex-wrap items-center justify-between gap-2 rounded-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#477ba6]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-bold text-[#263d53]",
                                        children: [
                                            report.categoryLabel,
                                            " · ",
                                            report.submitted
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 657,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `rounded-full px-2.5 py-1 text-[10px] font-semibold ${reviewClass[report.status]}`,
                                                children: report.status
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 661,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-semibold text-[#416f91]",
                                                children: "Buka / tutup detail"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 666,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 660,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 656,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-3 border-t border-[#e5eaf0] pt-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap justify-between gap-2",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[10px] text-slate-500",
                                            children: [
                                                "ID laporan: ",
                                                report.id
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 673,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 672,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-3 flex flex-wrap gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full bg-[#eaf2f8] px-2.5 py-1 text-[10px] font-semibold text-[#416f91]",
                                                children: report.categoryLabel
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 678,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full bg-[#f0f3f6] px-2.5 py-1 text-[10px] font-medium text-slate-600",
                                                children: report.workCondition === "BERJALAN" ? "Pekerjaan berjalan" : report.workCondition === "TERHAMBAT_SEBAGIAN" ? "Terhambat sebagian" : "Pekerjaan berhenti"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 681,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 677,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-3 text-sm leading-6 text-slate-700",
                                        children: report.description
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 689,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-3 rounded-lg bg-[#f7f9fb] p-3 text-xs text-slate-600",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold text-[#40596f]",
                                                        children: "Pekerjaan terdampak:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 694,
                                                        columnNumber: 21
                                                    }, this),
                                                    " ",
                                                    report.affectedMilestoneTitle,
                                                    " /",
                                                    " ",
                                                    report.affectedSubtaskTitle
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 693,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold text-[#40596f]",
                                                        children: "Perkiraan tambahan waktu:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 701,
                                                        columnNumber: 21
                                                    }, this),
                                                    " ",
                                                    report.estimatedDelayDays,
                                                    " hari"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 700,
                                                columnNumber: 19
                                            }, this),
                                            report.additionalInfo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-semibold text-[#40596f]",
                                                        children: "Informasi tambahan:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 708,
                                                        columnNumber: 23
                                                    }, this),
                                                    " ",
                                                    report.additionalInfo
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 707,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 692,
                                        columnNumber: 17
                                    }, this),
                                    report.attachment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-3 overflow-hidden rounded-lg border border-[#e6ebef]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: report.attachment,
                                            alt: `Bukti kendala: ${report.attachmentName}`,
                                            className: "h-40 w-full object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 718,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 716,
                                        columnNumber: 19
                                    }, this),
                                    report.followUp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-3 rounded-lg bg-[#f4f7fa] p-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] font-semibold text-[#416f91]",
                                                children: "Tindak lanjut pengawas"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 727,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs leading-5 text-slate-600",
                                                children: report.followUp
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 730,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 726,
                                        columnNumber: 19
                                    }, this),
                                    report.approvedResolution && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-3 rounded-lg border border-[#b8d9bf] bg-[#edf6ef] p-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-wrap items-center justify-between gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-bold text-[#27643a]",
                                                        children: "Solusi yang disetujui"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 738,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "rounded-full bg-white px-2.5 py-1 text-[10px] font-semibold text-[#477c50]",
                                                        children: report.approvedResolution.decisionLabel
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 741,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 737,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-2 text-xs leading-5 text-[#40596f]",
                                                children: report.approvedResolution.solution
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 745,
                                                columnNumber: 21
                                            }, this),
                                            report.approvedResolution.impactType && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-2 flex flex-wrap gap-2",
                                                children: [
                                                    report.approvedResolution.impactType !== "waktu" && report.approvedResolution.additionalCost !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "rounded-md bg-white px-2.5 py-1.5 text-[10px] font-semibold text-[#27643a]",
                                                        children: [
                                                            "Tambahan biaya:",
                                                            " ",
                                                            formatCurrency(report.approvedResolution.additionalCost)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 752,
                                                        columnNumber: 29
                                                    }, this),
                                                    report.approvedResolution.impactType !== "biaya" && report.approvedResolution.additionalDays !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "rounded-md bg-white px-2.5 py-1.5 text-[10px] font-semibold text-[#27643a]",
                                                        children: [
                                                            "Tambahan waktu:",
                                                            " ",
                                                            report.approvedResolution.additionalDays,
                                                            " hari"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                        lineNumber: 761,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                                lineNumber: 749,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 736,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 671,
                                columnNumber: 15
                            }, this)
                        ]
                    }, report.id, true, {
                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                        lineNumber: 652,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 650,
                columnNumber: 9
            }, this),
            reports.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "py-8 text-center text-sm text-slate-500",
                children: "Belum ada kendala dilaporkan."
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 776,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 628,
        columnNumber: 5
    }, this);
}
_s2(Issues, "NZEs4N34I2vU569ODzuIjdsqMlo=");
_c3 = Issues;
function ProgressModal({ project, approvedSubtasks, onClose, onSubmit }) {
    _s3();
    const defaultStage = project.milestones.find((item)=>item.title === project.currentMilestone) ?? project.milestones.find((milestone)=>milestone.subtasks.some((task)=>!isApproved(task, milestone, approvedSubtasks))) ?? project.milestones[0];
    const [selectedStageId, setSelectedStageId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultStage?.id ?? "");
    const currentStage = project.milestones.find((m)=>m.id === selectedStageId) ?? defaultStage ?? project.milestones[0];
    const availableSubtasks = currentStage?.subtasks ?? [];
    const firstPendingSubtask = availableSubtasks.find((task)=>!isApproved(task, currentStage, approvedSubtasks));
    const [subtaskId, setSubtaskId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(firstPendingSubtask?.id ?? availableSubtasks[0]?.id ?? "");
    const [note, setNote] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [photo, setPhoto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [photoName, setPhotoName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [sending, setSending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const idCounter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const handleStageChange = (newStageId)=>{
        setSelectedStageId(newStageId);
        const targetStage = project.milestones.find((m)=>m.id === newStageId);
        if (targetStage && targetStage.subtasks.length > 0) {
            const pendingInTarget = targetStage.subtasks.find((t)=>!isApproved(t, targetStage, approvedSubtasks));
            setSubtaskId(pendingInTarget?.id ?? targetStage.subtasks[0]?.id ?? "");
        } else {
            setSubtaskId("");
        }
        setError("");
    };
    const selectedSubtask = availableSubtasks.find((item)=>item.id === subtaskId);
    const isSelectedSubtaskDone = selectedSubtask ? isApproved(selectedSubtask, currentStage, approvedSubtasks) : false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Dialog, {
        title: "Laporkan progress",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: async (event)=>{
                event.preventDefault();
                if (note.trim().length < 10) {
                    setError("Tulis catatan pekerjaan minimal 10 karakter.");
                    return;
                }
                const subtask = availableSubtasks.find((item)=>item.id === subtaskId);
                if (!subtask || !currentStage) {
                    setError("Pilih subtask yang valid.");
                    return;
                }
                if (isApproved(subtask, currentStage, approvedSubtasks)) {
                    setError("Subtask ini sudah selesai dan tidak dapat dilaporkan lagi. Silakan pilih subtask yang masih berjalan.");
                    return;
                }
                setSending(true);
                idCounter.current += 1;
                try {
                    await onSubmit({
                        id: `PR-${project.id}-${idCounter.current}`,
                        milestoneId: currentStage.id,
                        milestoneTitle: currentStage.title,
                        subtaskTitle: subtask.title,
                        note: note.trim(),
                        photo,
                        submitted: formatNow(),
                        review: "Menunggu",
                        feedback: "",
                        weight: subtask.weight
                    }, subtask.id);
                } finally{
                    setSending(false);
                }
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mb-4 rounded-xl bg-[#f5f8fb] p-4 text-xs leading-5 text-slate-600",
                    children: "Progress yang Anda kirim menjadi usulan dan belum mengubah progress resmi sebelum diverifikasi pengawas."
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 899,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "block text-xs font-semibold text-[#29465e]",
                    children: [
                        "Tahapan pekerjaan ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[#a75252]",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 904,
                            columnNumber: 29
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: selectedStageId,
                            onChange: (e)=>handleStageChange(e.target.value),
                            disabled: project.milestones.length === 0,
                            className: "mt-1.5 h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-sm font-normal outline-none focus:border-[#5b7c99]",
                            children: project.milestones.map((stage, idx)=>{
                                const isStageDone = stage.subtasks.length > 0 && stage.subtasks.every((t)=>isApproved(t, stage, approvedSubtasks));
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: stage.id,
                                    children: [
                                        "Tahap ",
                                        idx + 1,
                                        ": ",
                                        stage.title,
                                        " ",
                                        isStageDone ? "· (Selesai)" : ""
                                    ]
                                }, stage.id, true, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 918,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 905,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 903,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "mt-4 block text-xs font-semibold text-[#29465e]",
                    children: [
                        "Subtask yang dilaporkan ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[#a75252]",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 927,
                            columnNumber: 35
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: subtaskId,
                            onChange: (event)=>{
                                setSubtaskId(event.target.value);
                                setError("");
                            },
                            disabled: availableSubtasks.length === 0,
                            className: "mt-1.5 h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-sm font-normal outline-none focus:border-[#5b7c99] disabled:cursor-not-allowed disabled:bg-slate-100",
                            children: availableSubtasks.length > 0 ? availableSubtasks.map((task)=>{
                                const completed = isApproved(task, currentStage, approvedSubtasks);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: task.id,
                                    children: [
                                        task.title,
                                        " (",
                                        task.weight,
                                        "%)",
                                        completed ? " · (Selesai)" : ""
                                    ]
                                }, task.id, true, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 945,
                                    columnNumber: 19
                                }, this);
                            }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Tidak ada subtask pada tahap ini"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 952,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 928,
                            columnNumber: 11
                        }, this),
                        isSelectedSubtaskDone ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mt-1.5 block text-[11px] font-medium text-amber-600",
                            children: "⚠️ Subtask ini sudah diverifikasi selesai oleh pengawas. Silakan pilih subtask lain yang masih berlangsung."
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 956,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mt-1.5 block text-[10px] text-slate-400",
                            children: "Pilih subtask yang ingin Anda laporkan kemajuan pekerjaannya."
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 961,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 926,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "mt-4 block text-xs font-semibold text-[#29465e]",
                    children: [
                        "Catatan pekerjaan",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            value: note,
                            onChange: (event)=>setNote(event.target.value),
                            rows: 4,
                            maxLength: 1000,
                            placeholder: "Jelaskan pekerjaan yang sudah dilakukan dan hasilnya...",
                            className: "mt-1.5 w-full rounded-lg border border-[#dfe6ed] p-3 text-sm font-normal outline-none focus:border-[#5b7c99]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 968,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 966,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "block text-xs font-semibold text-[#29465e]",
                            children: "Upload foto (opsional)"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 978,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mt-1 block text-[10px] text-slate-400",
                            children: "Foto akan muncul di dokumentasi pengawas setelah laporan diverifikasi."
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 981,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "progress-photo",
                            className: "mt-2 flex h-24 cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-[#c6d3de] bg-[#f8fafc] text-xs font-medium text-slate-500 transition-colors hover:border-[#8fa9bf] hover:bg-[#f2f6f9]",
                            children: photo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "flex h-full w-full items-center justify-center overflow-hidden rounded-[11px]",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: photo,
                                    alt: "Pratinjau foto laporan",
                                    className: "h-full w-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 992,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 990,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                        className: "block text-xs text-[#41698a]",
                                        children: "Pilih foto"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 1000,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "mt-0.5 block text-[10px]",
                                        children: photoName || "JPG atau PNG, maks 10 MB"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 1001,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 999,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 985,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            id: "progress-photo",
                            type: "file",
                            accept: "image/jpeg,image/png,image/webp",
                            className: "sr-only",
                            onChange: async (event)=>{
                                const file = event.target.files?.[0];
                                if (!file) return;
                                if (file.size > 10 * 1024 * 1024) {
                                    setError("Ukuran foto maksimal 10 MB.");
                                    return;
                                }
                                setError("");
                                const compressed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compressImage"])(file);
                                setPhoto(compressed);
                                setPhotoName(file.name);
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1007,
                            columnNumber: 11
                        }, this),
                        photo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>{
                                setPhoto(null);
                                setPhotoName("");
                            },
                            className: "mt-2 text-[10px] font-semibold text-[#a75252] hover:underline",
                            children: "Hapus foto"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1026,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 977,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "mt-3 text-xs text-red-700",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1039,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogFooter, {
                    onClose: onClose,
                    submitLabel: sending ? "Mengirim…" : "Kirim laporan",
                    disabled: sending || isSelectedSubtaskDone || !subtaskId
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1043,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
            lineNumber: 856,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 855,
        columnNumber: 5
    }, this);
}
_s3(ProgressModal, "yGJqpaAqtrJGXSyj0U90rfwZL9o=");
_c4 = ProgressModal;
const ISSUE_CATEGORIES = [
    {
        value: "CUACA_LINGKUNGAN",
        label: "Cuaca dan lingkungan"
    },
    {
        value: "MATERIAL_PERALATAN",
        label: "Material dan peralatan"
    },
    {
        value: "TENAGA_KERJA",
        label: "Tenaga kerja"
    },
    {
        value: "TEKNIS_KONSTRUKSI",
        label: "Teknis konstruksi"
    },
    {
        value: "DESAIN_SPESIFIKASI",
        label: "Desain dan spesifikasi"
    },
    {
        value: "ANGGARAN_PENGADAAN",
        label: "Anggaran dan pengadaan"
    },
    {
        value: "PERIZINAN_EKSTERNAL",
        label: "Perizinan dan pihak eksternal"
    },
    {
        value: "LAINNYA",
        label: "Lainnya"
    }
];
function IssueModal({ project, approvedSubtasks, onClose, onSubmit }) {
    _s4();
    const defaultStage = project.milestones.find((item)=>item.title === project.currentMilestone) ?? project.milestones.find((item)=>item.subtasks.some((task)=>!isApproved(task, item, approvedSubtasks))) ?? project.milestones[0];
    const [selectedStageId, setSelectedStageId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(defaultStage?.id ?? "");
    const currentStage = project.milestones.find((m)=>m.id === selectedStageId) ?? defaultStage ?? project.milestones[0];
    const availableSubtasks = currentStage?.subtasks ?? [];
    const [subtaskId, setSubtaskId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(availableSubtasks[0]?.id ?? "");
    const handleStageChange = (newStageId)=>{
        setSelectedStageId(newStageId);
        const targetStage = project.milestones.find((m)=>m.id === newStageId);
        setSubtaskId(targetStage?.subtasks[0]?.id ?? "");
        setError("");
    };
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [workCondition, setWorkCondition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [estimatedDelayDays, setEstimatedDelayDays] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [additionalInfo, setAdditionalInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [attachment, setAttachment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [attachmentName, setAttachmentName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [sending, setSending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const idCounter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const selectedCategory = ISSUE_CATEGORIES.find((item)=>item.value === category);
    const selectedSubtask = availableSubtasks.find((task)=>task.id === subtaskId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Dialog, {
        title: "Laporkan kendala",
        onClose: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: async (event)=>{
                event.preventDefault();
                if (!category || !selectedCategory) {
                    setError("Pilih kategori kendala.");
                    return;
                }
                if (description.trim().length < 10) {
                    setError("Jelaskan kendala minimal 10 karakter.");
                    return;
                }
                if (!currentStage || !selectedSubtask) {
                    setError("Pilih subtask yang terdampak kendala.");
                    return;
                }
                if (!workCondition) {
                    setError("Pilih kondisi pekerjaan saat ini.");
                    return;
                }
                setSending(true);
                idCounter.current += 1;
                try {
                    await onSubmit({
                        id: `KN-${project.id}-${idCounter.current}`,
                        projectId: project.id,
                        category,
                        categoryLabel: selectedCategory.label,
                        description: description.trim(),
                        affectedMilestoneId: currentStage.id,
                        affectedMilestoneTitle: currentStage.title,
                        affectedSubtaskId: selectedSubtask.id,
                        affectedSubtaskTitle: selectedSubtask.title,
                        workCondition,
                        estimatedDelayDays,
                        additionalInfo: additionalInfo.trim(),
                        attachment,
                        attachmentName,
                        submitted: formatNow(),
                        status: "Menunggu",
                        followUp: ""
                    }, {
                        stageId: currentStage.id,
                        subtaskId: selectedSubtask.id
                    });
                } finally{
                    setSending(false);
                }
            },
            className: "space-y-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "rounded-xl border border-[#dce7ef] bg-[#f5f8fb] p-3 text-xs leading-5 text-slate-600",
                    children: "Sampaikan kondisi lapangan dengan jelas. Informasi ini membantu pengawas menilai dampak dan menentukan penanganan."
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1180,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-xs font-semibold text-[#29465e]",
                    children: [
                        "Kategori kendala ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[#a75252]",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1185,
                            columnNumber: 28
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: category,
                            onChange: (event)=>setCategory(event.target.value),
                            className: "mt-1.5 h-11 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-sm font-normal outline-none focus:border-[#5b7c99] focus:ring-2 focus:ring-[#5b7c99]/15",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "",
                                    children: "Pilih kategori kendala"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1195,
                                    columnNumber: 13
                                }, this),
                                ISSUE_CATEGORIES.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: item.value,
                                        children: item.label
                                    }, item.value, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 1197,
                                        columnNumber: 15
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1186,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1184,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-xs font-semibold text-[#29465e]",
                    children: [
                        "Detail kendala ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[#a75252]",
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1204,
                            columnNumber: 26
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            value: description,
                            onChange: (event)=>setDescription(event.target.value),
                            rows: 4,
                            minLength: 10,
                            maxLength: 1000,
                            placeholder: "Jelaskan apa yang terjadi, sejak kapan, dan dampaknya pada pekerjaan.",
                            className: "mt-1.5 w-full rounded-lg border border-[#dfe6ed] p-3 text-sm font-normal outline-none focus:border-[#5b7c99] focus:ring-2 focus:ring-[#5b7c99]/15"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1205,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "mt-1 block text-right text-[10px] font-normal text-slate-400",
                            children: [
                                description.length,
                                "/1000"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1214,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1203,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-xl border border-[#e4eaf0] p-3 space-y-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs font-semibold text-[#29465e]",
                            children: [
                                "Pekerjaan yang terdampak ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[#a75252]",
                                    children: "*"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1220,
                                    columnNumber: 38
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1219,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-[11px] font-medium text-slate-600",
                                    children: "Tahap pekerjaan"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1223,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: selectedStageId,
                                    onChange: (e)=>handleStageChange(e.target.value),
                                    disabled: project.milestones.length === 0,
                                    className: "mt-1 h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-sm outline-none focus:border-[#5b7c99]",
                                    children: project.milestones.map((stage, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: stage.id,
                                            children: [
                                                "Tahap ",
                                                idx + 1,
                                                ": ",
                                                stage.title
                                            ]
                                        }, stage.id, true, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 1233,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1226,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1222,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-[11px] font-medium text-slate-600",
                                    children: "Subtask yang terdampak"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1240,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: subtaskId,
                                    onChange: (e)=>{
                                        setSubtaskId(e.target.value);
                                        setError("");
                                    },
                                    disabled: !availableSubtasks.length,
                                    className: "mt-1 h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-sm outline-none focus:border-[#5b7c99] disabled:bg-slate-100",
                                    children: availableSubtasks.length ? availableSubtasks.map((task)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: task.id,
                                            children: [
                                                task.title,
                                                " (",
                                                task.weight,
                                                "%)"
                                            ]
                                        }, task.id, true, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 1254,
                                            columnNumber: 19
                                        }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: "Tidak ada subtask"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 1259,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1243,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1239,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1218,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                            className: "text-xs font-semibold text-[#29465e]",
                            children: [
                                "Kondisi pekerjaan saat ini ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[#a75252]",
                                    children: "*"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1266,
                                    columnNumber: 40
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1265,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-2 grid gap-2 sm:grid-cols-3",
                            children: [
                                [
                                    "BERJALAN",
                                    "Tetap berjalan",
                                    "Pekerjaan berlanjut dengan penyesuaian."
                                ],
                                [
                                    "TERHAMBAT_SEBAGIAN",
                                    "Terhambat sebagian",
                                    "Produktivitas menurun."
                                ],
                                [
                                    "BERHENTI",
                                    "Berhenti total",
                                    "Pekerjaan tidak dapat dilanjutkan."
                                ]
                            ].map(([value, label, detail])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: `cursor-pointer rounded-lg border p-3 transition-colors ${workCondition === value ? "border-[#5b7c99] bg-[#f1f6fa] ring-1 ring-[#5b7c99]/20" : "border-[#e1e7ec] hover:bg-[#f8fafb]"}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "radio",
                                            name: "issue-work-condition",
                                            value: value,
                                            checked: workCondition === value,
                                            onChange: ()=>setWorkCondition(value),
                                            className: "sr-only"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 1292,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "block text-[11px] font-semibold text-[#29465e]",
                                            children: label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 1300,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mt-1 block text-[10px] leading-4 text-slate-500",
                                            children: detail
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                            lineNumber: 1303,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, value, true, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1288,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1268,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1264,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "issue-delay",
                                    className: "text-xs font-semibold text-[#29465e]",
                                    children: "Perkiraan tambahan waktu"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1312,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "rounded-md bg-[#f0f3f6] px-2.5 py-1 text-xs font-semibold text-[#40596f]",
                                    children: [
                                        estimatedDelayDays,
                                        " hari"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1318,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1311,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            id: "issue-delay",
                            type: "range",
                            min: 0,
                            max: 30,
                            value: estimatedDelayDays,
                            onChange: (event)=>setEstimatedDelayDays(Number(event.target.value)),
                            className: "mt-2 w-full accent-[#315b76]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1322,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between text-[10px] text-slate-400",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "0 hari"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1334,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "30 hari"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1335,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1333,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1.5 text-[10px] leading-4 text-slate-500",
                            children: "Perkiraan awal dari mandor, bukan hasil final analisis."
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1337,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1310,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "block text-xs font-semibold text-[#29465e]",
                    children: [
                        "Informasi tambahan",
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-normal text-slate-400",
                            children: "(opsional)"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1343,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            value: additionalInfo,
                            onChange: (event)=>setAdditionalInfo(event.target.value),
                            rows: 2,
                            maxLength: 500,
                            placeholder: "Contoh: pemasok menjanjikan pengiriman ulang hari Jumat.",
                            className: "mt-1.5 w-full rounded-lg border border-[#dfe6ed] p-3 text-sm font-normal outline-none focus:border-[#5b7c99]"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1344,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1341,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs font-semibold text-[#29465e]",
                            children: [
                                "Bukti pendukung",
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-normal text-slate-400",
                                    children: "(opsional)"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1356,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1354,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 text-[10px] text-slate-500",
                            children: "Unggah foto kondisi lapangan atau material terkait."
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1358,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "issue-attachment",
                            className: "mt-2 flex min-h-24 cursor-pointer items-center justify-center overflow-hidden rounded-xl border border-dashed border-[#c6d3de] bg-[#f8fafc] text-xs text-slate-500 transition-colors hover:border-[#8fa9bf] hover:bg-[#f2f6f9]",
                            children: attachment ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "relative block h-40 w-full overflow-hidden rounded-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: attachment,
                                    alt: "Pratinjau bukti kendala",
                                    fill: true,
                                    unoptimized: true,
                                    sizes: "(max-width: 640px) 100vw, 448px",
                                    className: "object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                    lineNumber: 1367,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 1366,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-3 py-5 text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                        className: "block text-xs text-[#41698a]",
                                        children: "Pilih foto"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 1378,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "mt-1 block text-[10px]",
                                        children: "JPG, PNG, atau WebP · maks. 10 MB"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                        lineNumber: 1379,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                                lineNumber: 1377,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1361,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            id: "issue-attachment",
                            type: "file",
                            accept: "image/jpeg,image/png,image/webp",
                            className: "sr-only",
                            onChange: async (event)=>{
                                const file = event.target.files?.[0];
                                if (!file) return;
                                if (file.size > 10 * 1024 * 1024) {
                                    setError("Ukuran foto maksimal 10 MB.");
                                    event.target.value = "";
                                    return;
                                }
                                setError("");
                                const compressed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compressImage"])(file);
                                setAttachment(compressed);
                                setAttachmentName(file.name);
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1385,
                            columnNumber: 11
                        }, this),
                        attachment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>{
                                setAttachment(null);
                                setAttachmentName("");
                            },
                            className: "mt-2 text-[10px] font-semibold text-[#a75252] hover:underline",
                            children: "Hapus foto"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1405,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1353,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "rounded-lg bg-[#fff3f2] px-3 py-2 text-xs text-[#a75252]",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1418,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogFooter, {
                    onClose: onClose,
                    submitLabel: sending ? "Mengirim…" : "Kirim laporan kendala",
                    disabled: sending
                }, void 0, false, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1425,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
            lineNumber: 1130,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 1129,
        columnNumber: 5
    }, this);
}
_s4(IssueModal, "DQAlsnpOJZ/FaH9/rzR/LA/6cy0=");
_c5 = IssueModal;
function Dialog({ title, onClose, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[70] grid place-items-center bg-[#0c1b2b]/60 p-4",
        onMouseDown: (event)=>{
            if (event.target === event.currentTarget) onClose();
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "report-dialog-title",
            className: "max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5 shadow-2xl sm:p-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "report-dialog-title",
                            className: "text-lg font-bold text-[#203c54]",
                            children: title
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1457,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: onClose,
                            "aria-label": "Tutup",
                            className: "grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-slate-500",
                            children: "×"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                            lineNumber: 1463,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                    lineNumber: 1456,
                    columnNumber: 9
                }, this),
                children
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
            lineNumber: 1450,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 1444,
        columnNumber: 5
    }, this);
}
_c6 = Dialog;
function DialogFooter({ onClose, submitLabel, disabled }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "mt-5 flex justify-end gap-2 border-t border-[#edf0f3] pt-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onClose,
                className: "min-h-10 rounded-lg border border-slate-200 px-4 text-xs font-semibold text-slate-600",
                children: "Batal"
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 1488,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                disabled: disabled,
                className: "min-h-10 rounded-lg bg-[#2B3361] px-4 text-xs font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50",
                children: submitLabel
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
                lineNumber: 1495,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorProjectDetail.tsx",
        lineNumber: 1487,
        columnNumber: 5
    }, this);
}
_c7 = DialogFooter;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7;
__turbopack_context__.k.register(_c, "MandorProjectDetail");
__turbopack_context__.k.register(_c1, "NotesCard");
__turbopack_context__.k.register(_c2, "Reports");
__turbopack_context__.k.register(_c3, "Issues");
__turbopack_context__.k.register(_c4, "ProgressModal");
__turbopack_context__.k.register(_c5, "IssueModal");
__turbopack_context__.k.register(_c6, "Dialog");
__turbopack_context__.k.register(_c7, "DialogFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useMandorProjects.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMandorProject",
    ()=>useMandorProject,
    "useMandorProjects",
    ()=>useMandorProjects
]);
/**
 * useMandorProjects / useMandorProject
 *
 * Membaca data backend alur Mandor -> Pengawas melalui /api/mandor/*.
 * Seluruh pembacaan dijalankan server dengan RLS milik mandor.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
function useMandorProjects() {
    _s();
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    /** Muat ulang tanpa menyalakan status loading agar tampilan tidak berkedip. */ const reload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMandorProjects.useCallback[reload]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiGet"])("/api/mandor/projects").then({
                "useMandorProjects.useCallback[reload]": (data)=>{
                    setProjects(data);
                    setError("");
                }
            }["useMandorProjects.useCallback[reload]"]).catch({
                "useMandorProjects.useCallback[reload]": (caught)=>{
                    console.error("[useMandorProjects]", caught);
                    setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(caught, "Gagal memuat proyek Anda."));
                }
            }["useMandorProjects.useCallback[reload]"])
    }["useMandorProjects.useCallback[reload]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMandorProjects.useEffect": ()=>{
            let active = true;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiGet"])("/api/mandor/projects").then({
                "useMandorProjects.useEffect": (data)=>{
                    if (!active) return;
                    setProjects(data);
                    setError("");
                }
            }["useMandorProjects.useEffect"]).catch({
                "useMandorProjects.useEffect": (caught)=>{
                    if (!active) return;
                    console.error("[useMandorProjects]", caught);
                    setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(caught, "Gagal memuat proyek Anda."));
                }
            }["useMandorProjects.useEffect"]).finally({
                "useMandorProjects.useEffect": ()=>{
                    if (active) setLoading(false);
                }
            }["useMandorProjects.useEffect"]);
            return ({
                "useMandorProjects.useEffect": ()=>{
                    active = false;
                }
            })["useMandorProjects.useEffect"];
        }
    }["useMandorProjects.useEffect"], []);
    return {
        projects,
        loading,
        error,
        reload
    };
}
_s(useMandorProjects, "MiZnZkpbdYKgI4N59pYk+BO2wCU=");
function useMandorProject(id) {
    _s1();
    const [project, setProject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const reload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMandorProject.useCallback[reload]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiGet"])(`/api/mandor/projects/${id}`).then({
                "useMandorProject.useCallback[reload]": (data)=>{
                    setProject(data);
                    setError("");
                }
            }["useMandorProject.useCallback[reload]"]).catch({
                "useMandorProject.useCallback[reload]": (caught)=>{
                    console.error("[useMandorProject]", caught);
                    setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(caught, "Gagal memuat detail proyek."));
                }
            }["useMandorProject.useCallback[reload]"])
    }["useMandorProject.useCallback[reload]"], [
        id
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMandorProject.useEffect": ()=>{
            let active = true;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiGet"])(`/api/mandor/projects/${id}`).then({
                "useMandorProject.useEffect": (data)=>{
                    if (!active) return;
                    setProject(data);
                    setError("");
                }
            }["useMandorProject.useEffect"]).catch({
                "useMandorProject.useEffect": (caught)=>{
                    if (!active) return;
                    console.error("[useMandorProject]", caught);
                    setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorMessage"])(caught, "Gagal memuat detail proyek."));
                }
            }["useMandorProject.useEffect"]).finally({
                "useMandorProject.useEffect": ()=>{
                    if (active) setLoading(false);
                }
            }["useMandorProject.useEffect"]);
            return ({
                "useMandorProject.useEffect": ()=>{
                    active = false;
                }
            })["useMandorProject.useEffect"];
        }
    }["useMandorProject.useEffect"], [
        id
    ]);
    return {
        project,
        loading,
        error,
        reload
    };
}
_s1(useMandorProject, "t6wzDITQhHyFLBc9vFRRJ1Ol+Hk=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/image.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * image.ts
 *
 * Utilitas gambar untuk dokumentasi lapangan.
 *
 * Foto dari kamera HP dikompres di sisi browser menjadi data-URL JPEG
 * (maksimum 900px sisi terpanjang, kualitas 0.72) sehingga ukuran teks yang
 * tersimpan di kolom text tetap wajar.
 */ __turbopack_context__.s([
    "compressImage",
    ()=>compressImage
]);
function compressImage(file) {
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = ()=>{
            const img = new Image();
            img.onload = ()=>{
                const max = 900;
                const scale = Math.min(1, max / Math.max(img.width, img.height));
                const canvas = document.createElement("canvas");
                canvas.width = Math.round(img.width * scale);
                canvas.height = Math.round(img.height * scale);
                const context = canvas.getContext("2d");
                if (!context) {
                    resolve(reader.result);
                    return;
                }
                context.drawImage(img, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL("image/jpeg", 0.72));
            };
            img.onerror = ()=>resolve(reader.result);
            img.src = reader.result;
        };
        reader.onerror = ()=>reject(new Error("Foto tidak dapat dibaca."));
        reader.readAsDataURL(file);
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_03fuimr._.js.map
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/(auth)/register/customer/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CustomerRegisterPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/auth.service.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const legalContent = {
    terms: [
        [
            "1. Ketentuan Umum",
            "Dengan menggunakan Way2Home, pengguna menyatakan bahwa informasi yang diberikan adalah benar, lengkap, dan dapat dipertanggungjawabkan."
        ],
        [
            "2. Akun Pengguna",
            "Pengguna bertanggung jawab menjaga keamanan akun, termasuk email, kata sandi, dan informasi lain yang digunakan untuk mengakses Way2Home."
        ],
        [
            "3. Data Pengguna",
            "Data yang diberikan pengguna digunakan untuk menyediakan layanan Way2Home, termasuk pengelolaan proyek pembangunan dan fitur yang tersedia dalam sistem."
        ],
        [
            "4. Rekomendasi dan Informasi Sistem",
            "Informasi, rekomendasi desain, estimasi, atau analisis yang diberikan oleh sistem merupakan informasi pendukung dan tidak menggantikan keputusan profesional dalam pelaksanaan pembangunan."
        ],
        [
            "5. Penggunaan Sistem",
            "Pengguna tidak diperkenankan menggunakan Way2Home untuk tujuan yang melanggar hukum, memberikan informasi palsu, atau melakukan tindakan yang dapat mengganggu keamanan dan operasional sistem."
        ],
        [
            "6. Perubahan Layanan",
            "Way2Home dapat melakukan perubahan, pengembangan, atau pembaruan terhadap fitur dan layanan untuk meningkatkan kualitas sistem."
        ],
        [
            "7. Persetujuan",
            "Dengan mencentang checkbox pada saat registrasi, pengguna menyatakan telah membaca, memahami, dan menyetujui Syarat & Ketentuan serta Kebijakan Privasi Way2Home."
        ]
    ],
    privacy: [
        [
            "1. Data yang Dikumpulkan",
            "Way2Home dapat mengumpulkan data akun, informasi profil, data preferensi desain, serta data yang berkaitan dengan proyek pembangunan."
        ],
        [
            "2. Penggunaan Data",
            "Data digunakan untuk menyediakan layanan, mengelola proyek, memberikan rekomendasi, dan meningkatkan kualitas sistem Way2Home."
        ],
        [
            "3. Keamanan Data",
            "Way2Home berupaya menjaga keamanan data pengguna dan membatasi akses terhadap data sesuai kebutuhan sistem."
        ],
        [
            "4. Penggunaan Fitur AI",
            "Data tertentu dapat digunakan sebagai input untuk fitur analisis atau rekomendasi berbasis AI yang tersedia dalam Way2Home."
        ],
        [
            "5. Persetujuan Pengguna",
            "Dengan menggunakan Way2Home, pengguna menyetujui pengumpulan dan penggunaan data sesuai dengan Kebijakan Privasi ini."
        ]
    ]
};
function CustomerRegisterPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPasswordConfirmation, setShowPasswordConfirmation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [name, setName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [phoneNumber, setPhoneNumber] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [nik, setNik] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [passwordConfirmation, setPasswordConfirmation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [terms, setTerms] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeModal, setActiveModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [submitError, setSubmitError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [errors, setErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: "",
        email: "",
        phoneNumber: "",
        nik: "",
        password: "",
        passwordConfirmation: "",
        terms: ""
    });
    const getInputClassName = (hasError)=>"w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 " + (hasError ? "border-red-300 bg-red-50 focus:border-red-500" : "border-gray-200 focus:border-[#045ec2]");
    const validateForm = ()=>{
        const newErrors = {
            name: "",
            email: "",
            phoneNumber: "",
            nik: "",
            password: "",
            passwordConfirmation: "",
            terms: ""
        };
        // Nama
        if (name.trim().length < 2) {
            newErrors.name = "Nama lengkap wajib diisi.";
        }
        // Email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            newErrors.email = "Format alamat email tidak valid.";
        }
        // Password
        if (password.length < 8) {
            newErrors.password = "Kata sandi minimal harus terdiri dari 8 karakter.";
        }
        // Password confirmation
        if (passwordConfirmation !== password) {
            newErrors.passwordConfirmation = "Konfirmasi kata sandi tidak sesuai.";
        }
        // Phone number
        const phoneRegex = /^[0-9]{10,14}$/;
        if (!phoneRegex.test(phoneNumber)) {
            newErrors.phoneNumber = "Format nomor HP tidak valid.";
        }
        // NIK
        if (!/^\d{16}$/.test(nik)) {
            newErrors.nik = "NIK harus terdiri dari tepat 16 digit angka.";
        }
        // Terms
        if (!terms) {
            newErrors.terms = "Anda harus menyetujui Syarat & Ketentuan.";
        }
        setErrors(newErrors);
        return !Object.values(newErrors).some((error)=>error !== "");
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        const isValid = validateForm();
        if (!isValid) {
            return;
        }
        setIsLoading(true);
        setSubmitError("");
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["register"])({
            name: name.trim(),
            email: email.trim(),
            phone: phoneNumber,
            nik,
            password
        });
        if (!result.ok) {
            setSubmitError(result.message);
            setIsLoading(false);
            return;
        }
        router.push("/login?registered=1");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "flex min-h-screen flex-col-reverse lg:flex-row",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "\r\n\n          relative flex w-full items-center justify-center\r\n\n          overflow-hidden px-4 py-6\r\n\n          lg:w-[65%] lg:px-8\r\n\n        ",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: "/images/aset/construction2.jpg",
                                alt: "Construction background",
                                fill: true,
                                priority: true,
                                className: "object-cover"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 bg-[#045ec2]/25"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 208,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "\r\n\n            relative z-10 w-full max-w-md\r\n\n            rounded-[18px]\r\n\n            border border-gray-400/90\r\n\n            bg-[#ebfaff]\r\n\n            px-6 py-7\r\n\n            shadow-[0_8px_32px_rgba(0,0,0,0.1)]\r\n\n            sm:px-10\r\n\n          ",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-2xl font-bold text-[#2B3361]",
                                        children: "Buat Akun Baru"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 225,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-sm text-[#647ca9]",
                                        children: "Silakan isi data di bawah ini untuk mendaftar"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 229,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 224,
                                columnNumber: 11
                            }, this),
                            submitError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-4 text-center text-sm text-red-500",
                                children: submitError
                            }, void 0, false, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 236,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                onSubmit: handleSubmit,
                                noValidate: true,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "name",
                                                className: "mb-1.5 block text-sm text-[#2B3361]",
                                                children: "Nama Lengkap"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 246,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "name",
                                                type: "text",
                                                value: name,
                                                onChange: (e)=>{
                                                    setName(e.target.value);
                                                    if (errors.name) {
                                                        setErrors((prev)=>({
                                                                ...prev,
                                                                name: ""
                                                            }));
                                                    }
                                                },
                                                placeholder: "Masukkan nama lengkap",
                                                "aria-invalid": !!errors.name,
                                                className: getInputClassName(!!errors.name)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 253,
                                                columnNumber: 15
                                            }, this),
                                            errors.name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 269,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 245,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "email",
                                                className: "mb-1.5 block text-sm text-[#2B3361]",
                                                children: "Email"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 279,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "email",
                                                type: "text",
                                                value: email,
                                                onChange: (e)=>{
                                                    setEmail(e.target.value);
                                                    if (errors.email) {
                                                        setErrors((prev)=>({
                                                                ...prev,
                                                                email: ""
                                                            }));
                                                    }
                                                },
                                                placeholder: "Masukkan email aktif",
                                                "aria-invalid": !!errors.email,
                                                className: getInputClassName(!!errors.email)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 286,
                                                columnNumber: 15
                                            }, this),
                                            errors.email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.email
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 302,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 278,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "phone_number",
                                                className: "mb-1.5 block text-sm text-[#2B3361]",
                                                children: "Nomor HP"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 312,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "phone_number",
                                                type: "tel",
                                                value: phoneNumber,
                                                onChange: (e)=>{
                                                    setPhoneNumber(e.target.value);
                                                    if (errors.phoneNumber) {
                                                        setErrors((prev)=>({
                                                                ...prev,
                                                                phoneNumber: ""
                                                            }));
                                                    }
                                                },
                                                placeholder: "Contoh: 081234567xxx",
                                                inputMode: "numeric",
                                                "aria-invalid": !!errors.phoneNumber,
                                                className: getInputClassName(!!errors.phoneNumber)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 319,
                                                columnNumber: 15
                                            }, this),
                                            errors.phoneNumber && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.phoneNumber
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 336,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 311,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "nik",
                                                className: "mb-1.5 block text-sm text-[#2B3361]",
                                                children: "NIK"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 346,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "nik",
                                                type: "text",
                                                value: nik,
                                                onChange: (e)=>{
                                                    const digitsOnly = e.target.value.replace(/\D/g, "").slice(0, 16);
                                                    setNik(digitsOnly);
                                                    if (errors.nik) {
                                                        setErrors((prev)=>({
                                                                ...prev,
                                                                nik: ""
                                                            }));
                                                    }
                                                },
                                                placeholder: "Masukkan 16 digit NIK",
                                                inputMode: "numeric",
                                                maxLength: 16,
                                                autoComplete: "off",
                                                "aria-invalid": !!errors.nik,
                                                "aria-describedby": errors.nik ? "nik-error" : undefined,
                                                className: getInputClassName(!!errors.nik)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 353,
                                                columnNumber: 15
                                            }, this),
                                            errors.nik && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                id: "nik-error",
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.nik
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 376,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 345,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "password",
                                                className: "mb-1.5 block text-sm text-[#2B3361]",
                                                children: "Password"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 389,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "password",
                                                        type: showPassword ? "text" : "password",
                                                        value: password,
                                                        onChange: (e)=>{
                                                            setPassword(e.target.value);
                                                            if (errors.password) {
                                                                setErrors((prev)=>({
                                                                        ...prev,
                                                                        password: ""
                                                                    }));
                                                            }
                                                            if (passwordConfirmation && e.target.value !== passwordConfirmation) {
                                                                setErrors((prev)=>({
                                                                        ...prev,
                                                                        passwordConfirmation: "Konfirmasi kata sandi tidak sesuai."
                                                                    }));
                                                            } else if (passwordConfirmation) {
                                                                setErrors((prev)=>({
                                                                        ...prev,
                                                                        passwordConfirmation: ""
                                                                    }));
                                                            }
                                                        },
                                                        placeholder: "Buat password",
                                                        "aria-invalid": !!errors.password,
                                                        className: "w-full rounded-lg border bg-white px-3 py-2.5 pr-11 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 " + (errors.password ? "border-red-300 bg-red-50 focus:border-red-500" : "border-gray-200 focus:border-[#045ec2]")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                        lineNumber: 397,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>setShowPassword((prev)=>!prev),
                                                        "aria-label": showPassword ? "Sembunyikan password" : "Tampilkan password",
                                                        className: "\r\n\n                    absolute right-2.5 top-1/2\r\n\n                    -translate-y-1/2\r\n\n                    cursor-pointer p-1\r\n\n                  ",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            src: showPassword ? "/images/icon/buka.png" : "/images/icon/tutup.png",
                                                            alt: "",
                                                            width: 20,
                                                            height: 20
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                            lineNumber: 444,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                        lineNumber: 432,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 396,
                                                columnNumber: 15
                                            }, this),
                                            errors.password && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.password
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 458,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 388,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "password_confirmation",
                                                className: "mb-1.5 block text-sm text-[#2B3361]",
                                                children: "Konfirmasi Password"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 468,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "password_confirmation",
                                                        type: showPasswordConfirmation ? "text" : "password",
                                                        value: passwordConfirmation,
                                                        onChange: (e)=>{
                                                            setPasswordConfirmation(e.target.value);
                                                            if (errors.passwordConfirmation) {
                                                                setErrors((prev)=>({
                                                                        ...prev,
                                                                        passwordConfirmation: ""
                                                                    }));
                                                            }
                                                            if (password && e.target.value !== password) {
                                                                setErrors((prev)=>({
                                                                        ...prev,
                                                                        passwordConfirmation: "Konfirmasi kata sandi tidak sesuai."
                                                                    }));
                                                            }
                                                        },
                                                        placeholder: "Ulangi password",
                                                        "aria-invalid": !!errors.passwordConfirmation,
                                                        className: "w-full rounded-lg border bg-white px-3 py-2.5 pr-11 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 " + (errors.passwordConfirmation ? "border-red-300 bg-red-50 focus:border-red-500" : "border-gray-200 focus:border-[#045ec2]")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                        lineNumber: 476,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>setShowPasswordConfirmation((prev)=>!prev),
                                                        "aria-label": showPasswordConfirmation ? "Sembunyikan password" : "Tampilkan password",
                                                        className: "\r\n\n                    absolute right-2.5 top-1/2\r\n\n                    -translate-y-1/2\r\n\n                    cursor-pointer p-1\r\n\n                  ",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            src: showPasswordConfirmation ? "/images/icon/buka.png" : "/images/icon/tutup.png",
                                                            alt: "",
                                                            width: 20,
                                                            height: 20
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                            lineNumber: 520,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                        lineNumber: 506,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 475,
                                                columnNumber: 15
                                            }, this),
                                            errors.passwordConfirmation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.passwordConfirmation
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 534,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 467,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-start gap-2 text-sm text-[#2B3361]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "legal-consent",
                                                        type: "checkbox",
                                                        checked: terms,
                                                        onChange: (e)=>{
                                                            setTerms(e.target.checked);
                                                            if (errors.terms) {
                                                                setErrors((prev)=>({
                                                                        ...prev,
                                                                        terms: ""
                                                                    }));
                                                            }
                                                        },
                                                        className: "mt-0.5 h-4 w-4 shrink-0 cursor-pointer accent-[#004796] " + (errors.terms ? "ring-1 ring-red-300" : "")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                        lineNumber: 542,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "legal-consent",
                                                        className: "cursor-pointer leading-5",
                                                        children: [
                                                            "Dengan mendaftar, saya menyetujui",
                                                            " ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>setActiveModal("terms"),
                                                                className: " font-semibold text-[#004796] cursor-pointer",
                                                                children: "Syarat & Ketentuan"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                                lineNumber: 562,
                                                                columnNumber: 19
                                                            }, this),
                                                            " ",
                                                            "dan",
                                                            " ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>setActiveModal("privacy"),
                                                                className: "font-semibold text-[#004796] cursor-pointer",
                                                                children: "Kebijakan Privasi"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                                lineNumber: 570,
                                                                columnNumber: 19
                                                            }, this),
                                                            " ",
                                                            "Way2Home."
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                        lineNumber: 557,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 541,
                                                columnNumber: 15
                                            }, this),
                                            errors.terms && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-xs font-medium text-red-500",
                                                children: errors.terms
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 582,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 540,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        disabled: isLoading || !terms,
                                        className: "\r\n\n                flex w-full items-center\r\n\n                justify-center gap-2\r\n\n                rounded-[10px]\r\n\n                bg-[#2B3361]\r\n\n                px-4 py-3\r\n\n                font-bold text-white\r\n\n                transition\r\n\n                hover:bg-[#21274b]\r\n\n                disabled:cursor-not-allowed\r\n\n                disabled:opacity-60\r\n\n              ",
                                        children: [
                                            isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "\r\n\n                    h-4 w-4\r\n\n                    animate-spin\r\n\n                    rounded-full\r\n\n                    border-2\r\n\n                    border-white/35\r\n\n                    border-t-white\r\n\n                  "
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 608,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: isLoading ? "Memproses..." : "Daftar Sekarang"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 620,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 591,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-4 text-center text-sm text-[#2B3361]",
                                        children: [
                                            "Sudah punya akun?",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/login",
                                                className: "text-[#045ec2] hover:underline",
                                                children: "Login di sini"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 628,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 626,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 241,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                        lineNumber: 212,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                lineNumber: 190,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "\r\n\n          flex w-full items-center justify-center\r\n\n          bg-[#2B3361]\r\n\n          px-4 py-8\r\n\n          text-center text-white\r\n\n          lg:w-[35%]\r\n\n        ",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/images/aset/logo-w2h.png",
                            alt: "Logo Way2Home",
                            width: 120,
                            height: 120,
                            style: {
                                width: "auto",
                                height: "auto"
                            },
                            priority: true,
                            className: "mx-auto mb-3 brightness-0 invert"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                            lineNumber: 649,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl font-bold",
                            children: "Way2Home"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                            lineNumber: 659,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 text-base text-[#fcd47c]",
                            children: "Membuat rumahmu lebih berwarna"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                            lineNumber: 661,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                    lineNumber: 648,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                lineNumber: 639,
                columnNumber: 7
            }, this),
            activeModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4",
                onClick: ()=>setActiveModal(null),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-labelledby": "legal-modal-title",
                    className: "flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl",
                    onClick: (event)=>event.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                            className: "flex items-center justify-between border-b border-gray-100 px-5 py-4 sm:px-7",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "legal-modal-title",
                                    className: "text-lg font-bold text-[#2B3361] sm:text-xl",
                                    children: activeModal === "terms" ? "Syarat & Ketentuan" : "Kebijakan Privasi"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                    lineNumber: 680,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    "aria-label": "Tutup dialog",
                                    onClick: ()=>setActiveModal(null),
                                    className: "flex h-9 w-9 items-center justify-center rounded-full text-2xl leading-none text-gray-500 transition hover:bg-gray-100 hover:text-gray-800",
                                    children: "Ã—"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                    lineNumber: 688,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                            lineNumber: 679,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "overflow-y-auto px-5 py-5 sm:px-7",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-5 text-sm leading-6 text-gray-600",
                                children: legalContent[activeModal].map(([title, description])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "mb-1 font-semibold text-[#2B3361]",
                                                children: title
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 701,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: description
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                                lineNumber: 704,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, title, true, {
                                        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                        lineNumber: 700,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 698,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                            lineNumber: 697,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                            className: "border-t border-gray-100 px-5 py-4 text-right sm:px-7",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setActiveModal(null),
                                className: "rounded-lg bg-[#004796] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#045ec2]",
                                children: "Tutup"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                                lineNumber: 710,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                            lineNumber: 709,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                    lineNumber: 672,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
                lineNumber: 668,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(auth)/register/customer/page.tsx",
        lineNumber: 186,
        columnNumber: 5
    }, this);
}
_s(CustomerRegisterPage, "s9LVA5FLLyevseFd+mxI1qF19K8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = CustomerRegisterPage;
var _c;
__turbopack_context__.k.register(_c, "CustomerRegisterPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/auth.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "login",
    ()=>login,
    "logout",
    ()=>logout,
    "register",
    ()=>register
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/supabase/client.ts [app-client] (ecmascript)");
;
async function login(email, password) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const { error } = await supabase.auth.signInWithPassword({
        email,
        password
    });
    if (!error) {
        const { data: { user } } = await supabase.auth.getUser();
        const { data: profile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user?.id || "").maybeSingle();
        if (profileError || !profile) {
            await supabase.auth.signOut();
            return {
                ok: false,
                message: "Profil akun belum memiliki role. Hubungi administrator."
            };
        }
        // Blokir login mandor yang belum diverifikasi admin
        if (profile.role === "mandor") {
            const { data: mandorProfile } = await supabase.from("mandor_profiles").select("status").eq("id", user?.id || "").maybeSingle();
            if (!mandorProfile || mandorProfile.status !== "approved") {
                await supabase.auth.signOut();
                return {
                    ok: false,
                    message: "MANDOR_PENDING"
                };
            }
        }
        return {
            ok: true,
            role: profile.role
        };
    }
    const message = error.message === "Invalid login credentials" ? "Email atau password salah." : error.message === "Email not confirmed" ? "Email belum dikonfirmasi. Cek inbox kamu." : error.message;
    return {
        ok: false,
        message
    };
}
async function register(input) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const { data, error } = await supabase.auth.signUp({
        email: input.email,
        password: input.password,
        options: {
            data: {
                full_name: input.name,
                phone: input.phone,
                nik: input.nik,
                role: "customer"
            },
            emailRedirectTo: `${window.location.origin}/callback`
        }
    });
    if (error) {
        return {
            ok: false,
            message: error.message.includes("already registered") ? "Email sudah terdaftar." : error.message
        };
    }
    // Kalau "Confirm email" OFF, signUp langsung bikin session.
    // Logout dulu supaya alurnya sesuai desain FE: daftar → halaman login.
    if (data.session) await supabase.auth.signOut();
    return {
        ok: true
    };
}
async function logout() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])().auth.signOut();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
let client = null;
function createClient() {
    if (!client) {
        client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://oiqbpbheyrsekrlyenyv.supabase.co"), ("TURBOPACK compile-time value", "sb_publishable_LFSFjIJuIkEia9y0GMjBJQ_ATtbUzpj"));
    }
    return client;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0_0w377._.js.map
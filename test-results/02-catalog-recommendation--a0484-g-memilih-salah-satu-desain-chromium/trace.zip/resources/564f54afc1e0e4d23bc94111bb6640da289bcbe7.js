(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/catalog/CatalogGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CatalogGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalog$2f$DesignCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/catalog/DesignCard.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const PAGE_SIZE = 6;
const priceRanges = [
    {
        label: "Semua harga",
        min: 0,
        max: Infinity
    },
    {
        label: "Di bawah Rp700 juta",
        min: 0,
        max: 700000000
    },
    {
        label: "Rp700 juta–Rp1 miliar",
        min: 700000000,
        max: 1000000000
    },
    {
        label: "Rp1–1,5 miliar",
        min: 1000000000,
        max: 1500000000
    },
    {
        label: "Di atas Rp1,5 miliar",
        min: 1500000000,
        max: Infinity
    }
];
const landRanges = [
    {
        label: "Semua luas tanah",
        min: 0,
        max: Infinity
    },
    {
        label: "Di bawah 100 m²",
        min: 0,
        max: 100
    },
    {
        label: "100–150 m²",
        min: 100,
        max: 150
    },
    {
        label: "151–200 m²",
        min: 151,
        max: 200
    },
    {
        label: "Di atas 200 m²",
        min: 201,
        max: Infinity
    }
];
const buildingRanges = [
    {
        label: "Semua luas bangunan",
        min: 0,
        max: Infinity
    },
    {
        label: "Di bawah 70 m²",
        min: 0,
        max: 70
    },
    {
        label: "70–100 m²",
        min: 70,
        max: 100
    },
    {
        label: "101–150 m²",
        min: 101,
        max: 150
    },
    {
        label: "Di atas 150 m²",
        min: 151,
        max: Infinity
    }
];
function CustomSelect({ id, label, value, options, onChange, open, onOpenChange }) {
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CustomSelect.useEffect": ()=>{
            if (!open) return;
            const closeOnOutsideClick = {
                "CustomSelect.useEffect.closeOnOutsideClick": (event)=>{
                    if (containerRef.current && !containerRef.current.contains(event.target)) {
                        onOpenChange(false);
                    }
                }
            }["CustomSelect.useEffect.closeOnOutsideClick"];
            const closeOnEscape = {
                "CustomSelect.useEffect.closeOnEscape": (event)=>{
                    if (event.key === "Escape") onOpenChange(false);
                }
            }["CustomSelect.useEffect.closeOnEscape"];
            document.addEventListener("mousedown", closeOnOutsideClick);
            document.addEventListener("keydown", closeOnEscape);
            return ({
                "CustomSelect.useEffect": ()=>{
                    document.removeEventListener("mousedown", closeOnOutsideClick);
                    document.removeEventListener("keydown", closeOnEscape);
                }
            })["CustomSelect.useEffect"];
        }
    }["CustomSelect.useEffect"], [
        open,
        onOpenChange
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "relative",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "mb-2 block text-sm font-semibold text-[#111e3f]",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                id: id,
                type: "button",
                "aria-haspopup": "listbox",
                "aria-expanded": open,
                onClick: ()=>onOpenChange(!open),
                className: "flex min-h-11 w-full cursor-pointer items-center justify-between rounded-xl border border-[#dbe4f2] bg-white px-3 text-left text-sm text-[#475569] transition hover:border-[#8fb9ed] focus:outline-none focus:ring-2 focus:ring-[#045ec2]/20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: value
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `transition duration-150 ${open ? "scale-110 opacity-100" : "scale-100 opacity-50"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/images/icon/down.png",
                            alt: "",
                            className: "h-5 w-5 object-contain"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                            lineNumber: 90,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "listbox",
                "aria-labelledby": id,
                className: "absolute left-0 right-0 top-full z-20 mt-2 max-h-60 overflow-y-auto rounded-xl border border-[#dbe4f2] bg-white p-1 shadow-[0_18px_35px_rgba(17,30,63,0.14)]",
                children: options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        role: "option",
                        "aria-selected": option === value,
                        onClick: ()=>{
                            onChange(option);
                            onOpenChange(false);
                        },
                        className: `block w-full cursor-pointer rounded-lg px-3 py-2.5 text-left text-sm transition hover:bg-[#eef5ff] ${option === value ? "bg-[#eef5ff] font-bold text-[#004796]" : "text-[#475569]"}`,
                        children: option
                    }, option, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 104,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 98,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
_s(CustomSelect, "8puyVO4ts1RhCfXUmci3vLI3Njw=");
_c = CustomSelect;
function CatalogGrid() {
    _s1();
    const [designs, setDesigns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [style, setStyle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Semua gaya");
    const [price, setPrice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(priceRanges[0].label);
    const [land, setLand] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(landRanges[0].label);
    const [building, setBuilding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(buildingRanges[0].label);
    const [bedrooms, setBedrooms] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Semua kamar");
    const [sort, setSort] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Rekomendasi");
    const [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [filterOpen, setFilterOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openSelect, setOpenSelect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const setSelectOpen = (id, open)=>setOpenSelect(open ? id : null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CatalogGrid.useEffect": ()=>{
            async function fetchCatalog() {
                try {
                    setLoading(true);
                    const res = await fetch("/api/designs");
                    if (!res.ok) throw new Error("Gagal memuat katalog");
                    const data = await res.json();
                    setDesigns(data);
                } catch (err) {
                    const message = err instanceof Error ? err.message : "Terjadi kesalahan saat mengambil katalog.";
                    setError(message);
                } finally{
                    setLoading(false);
                }
            }
            fetchCatalog();
        }
    }["CatalogGrid.useEffect"], []);
    const styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CatalogGrid.useMemo[styles]": ()=>{
            const uniqueStyles = Array.from(new Set(designs.map({
                "CatalogGrid.useMemo[styles].uniqueStyles": (design)=>design.style
            }["CatalogGrid.useMemo[styles].uniqueStyles"])));
            return [
                "Semua gaya",
                ...uniqueStyles
            ];
        }
    }["CatalogGrid.useMemo[styles]"], [
        designs
    ]);
    const priceRange = priceRanges.find((item)=>item.label === price) ?? priceRanges[0];
    const landRange = landRanges.find((item)=>item.label === land) ?? landRanges[0];
    const buildingRange = buildingRanges.find((item)=>item.label === building) ?? buildingRanges[0];
    const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CatalogGrid.useMemo[filtered]": ()=>{
            const result = designs.filter({
                "CatalogGrid.useMemo[filtered].result": (design)=>`${design.name} ${design.style} ${design.location}`.toLowerCase().includes(query.toLowerCase()) && (style === "Semua gaya" || design.style === style) && design.estimatedCost >= priceRange.min && design.estimatedCost <= priceRange.max && design.landArea >= landRange.min && design.landArea <= landRange.max && design.buildingArea >= buildingRange.min && design.buildingArea <= buildingRange.max && (bedrooms === "Semua kamar" || (bedrooms === "4 kamar atau lebih" ? design.bedrooms >= 4 : design.bedrooms === Number(bedrooms[0])))
            }["CatalogGrid.useMemo[filtered].result"]);
            return [
                ...result
            ].sort({
                "CatalogGrid.useMemo[filtered]": (a, b)=>sort === "Harga terendah" ? a.estimatedCost - b.estimatedCost : sort === "Harga tertinggi" ? b.estimatedCost - a.estimatedCost : 0
            }["CatalogGrid.useMemo[filtered]"]);
        }
    }["CatalogGrid.useMemo[filtered]"], [
        buildingRange,
        bedrooms,
        landRange,
        priceRange,
        query,
        sort,
        style,
        designs
    ]);
    const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
    const currentPage = Math.min(page, pageCount);
    const visible = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
    const update = (setter, value)=>{
        setter(value);
        setPage(1);
    };
    const reset = ()=>{
        setQuery("");
        setStyle("Semua gaya");
        setPrice(priceRanges[0].label);
        setLand(landRanges[0].label);
        setBuilding(buildingRanges[0].label);
        setBedrooms("Semua kamar");
        setSort("Rekomendasi");
        setPage(1);
    };
    const filters = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomSelect, {
                id: "filter-style",
                label: "Gaya arsitektur",
                open: openSelect === "filter-style",
                onOpenChange: (open)=>setSelectOpen("filter-style", open),
                value: style,
                options: styles,
                onChange: (value)=>update(setStyle, value)
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 239,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomSelect, {
                id: "filter-price",
                label: "Estimasi biaya",
                open: openSelect === "filter-price",
                onOpenChange: (open)=>setSelectOpen("filter-price", open),
                value: price,
                options: priceRanges.map((item)=>item.label),
                onChange: (value)=>update(setPrice, value)
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 248,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomSelect, {
                id: "filter-land",
                label: "Luas tanah",
                open: openSelect === "filter-land",
                onOpenChange: (open)=>setSelectOpen("filter-land", open),
                value: land,
                options: landRanges.map((item)=>item.label),
                onChange: (value)=>update(setLand, value)
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 257,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomSelect, {
                id: "filter-building",
                label: "Luas bangunan",
                open: openSelect === "filter-building",
                onOpenChange: (open)=>setSelectOpen("filter-building", open),
                value: building,
                options: buildingRanges.map((item)=>item.label),
                onChange: (value)=>update(setBuilding, value)
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 266,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomSelect, {
                id: "filter-bedrooms",
                label: "Jumlah kamar",
                open: openSelect === "filter-bedrooms",
                onOpenChange: (open)=>setSelectOpen("filter-bedrooms", open),
                value: bedrooms,
                options: [
                    "Semua kamar",
                    "2 kamar",
                    "3 kamar",
                    "4 kamar atau lebih"
                ],
                onChange: (value)=>update(setBedrooms, value)
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 275,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: reset,
                className: "w-full cursor-pointer rounded-full border border-[#dbe4f2] px-4 py-2.5 text-sm font-bold text-[#045ec2] transition hover:border-[#8fb9ed] hover:bg-[#eef5ff]",
                children: "Reset filter"
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 284,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
        lineNumber: 238,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-[#f7f9fc] pb-24 text-[#111e3f]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "relative isolate overflow-visible bg-[#111e3f] text-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 -z-20 bg-[url('/images/aset/construction.jpg')] bg-cover bg-center"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 297,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 -z-10 bg-[#111e3f]/75"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 298,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 -z-10 bg-gradient-to-r from-[#08152f]/95 via-[#111e3f]/75 to-[#111e3f]/35"
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 299,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto flex min-h-[520px] max-w-screen-2xl flex-col justify-end px-6 pb-16 pt-32 lg:px-8 lg:pb-20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-w-3xl",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mb-5 text-sm font-semibold tracking-wide text-[#b9d8ff]",
                                        children: "Katalog Way2Home"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 303,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-4xl font-bold leading-[1.08] tracking-[-0.04em] md:text-6xl",
                                        children: "Temukan rumah yang terasa seperti rumah."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 306,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-6 max-w-2xl text-base leading-7 text-white/75 md:text-lg",
                                        children: "Jelajahi koleksi desain rumah dengan spesifikasi dasar, estimasi biaya, dan durasi pembangunan yang mudah dipahami."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 309,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                lineNumber: 302,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mx-auto mt-10 flex w-full max-w-screen-2xl flex-col gap-3 rounded-2xl border border-white/60 bg-white p-3 shadow-[0_20px_45px_rgba(17,30,63,0.2)] sm:flex-row sm:items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "sr-only",
                                        htmlFor: "catalog-search",
                                        children: "Cari desain rumah"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 316,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "catalog-search",
                                        value: query,
                                        onChange: (event)=>update(setQuery, event.target.value),
                                        placeholder: "Cari nama, gaya, atau lokasi...",
                                        className: "h-12 min-w-0 flex-1 rounded-xl bg-[#f7f9fc] px-4 text-sm text-[#111e3f] outline-none transition focus:ring-2 focus:ring-[#045ec2]/25"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 319,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full shrink-0 sm:w-56 [&_button]:h-12 [&_button]:min-h-12 [&_button]:w-full [&_button]:rounded-xl",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CustomSelect, {
                                            id: "catalog-sort",
                                            label: "",
                                            open: openSelect === "catalog-sort",
                                            onOpenChange: (open)=>setSelectOpen("catalog-sort", open),
                                            value: sort,
                                            options: [
                                                "Rekomendasi",
                                                "Harga terendah",
                                                "Harga tertinggi"
                                            ],
                                            onChange: (value)=>update(setSort, value)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                            lineNumber: 327,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 326,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                lineNumber: 315,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 301,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 296,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "mx-auto max-w-screen-2xl px-6 pt-20 lg:px-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-8 lg:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>setFilterOpen(true),
                            className: "min-h-11 w-full cursor-pointer rounded-full bg-[#004796] px-6 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:shadow-lg",
                            children: "Filter desain"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                            lineNumber: 343,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 342,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid items-start gap-8 lg:grid-cols-[250px_1fr]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                                className: "hidden rounded-2xl border border-[#dbe4f2] bg-white p-5 shadow-sm lg:block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-5 flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "font-bold",
                                                children: "Filter desain"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 355,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs text-[#64748b]",
                                                children: [
                                                    filtered.length,
                                                    " hasil"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 356,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 354,
                                        columnNumber: 13
                                    }, this),
                                    filters
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mb-5 text-sm text-[#64748b]",
                                        children: [
                                            "Menampilkan",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                className: "text-[#111e3f]",
                                                children: filtered.length
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 366,
                                                columnNumber: 15
                                            }, this),
                                            " ",
                                            "desain rumah"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 364,
                                        columnNumber: 13
                                    }, this),
                                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid gap-6 md:grid-cols-2 xl:grid-cols-3",
                                        children: [
                                            1,
                                            2,
                                            3,
                                            4,
                                            5,
                                            6
                                        ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-80 animate-pulse rounded-[1.75rem] bg-gray-200"
                                            }, i, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 373,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 371,
                                        columnNumber: 15
                                    }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-3xl border border-red-200 bg-red-50 p-6 text-center text-red-700",
                                        children: error
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 380,
                                        columnNumber: 15
                                    }, this) : filtered.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid gap-6 md:grid-cols-2 xl:grid-cols-3",
                                                children: visible.map((design)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$catalog$2f$DesignCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        design: design
                                                    }, design.slug, false, {
                                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                        lineNumber: 387,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 385,
                                                columnNumber: 17
                                            }, this),
                                            pageCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                                "aria-label": "Pagination katalog",
                                                className: "mt-10 flex flex-wrap items-center justify-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        "aria-label": "Halaman sebelumnya",
                                                        disabled: currentPage === 1,
                                                        onClick: ()=>setPage((value)=>value - 1),
                                                        className: "cursor-pointer rounded-full border border-[#dbe4f2] px-4 py-2 text-lg text-[#475569] transition hover:border-[#8fb9ed] hover:bg-[#eef5ff] disabled:cursor-not-allowed disabled:opacity-40",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: "/images/icon/chevron-left.png",
                                                            alt: "",
                                                            className: "h-6 w-6"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                            lineNumber: 403,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                        lineNumber: 395,
                                                        columnNumber: 21
                                                    }, this),
                                                    Array.from({
                                                        length: pageCount
                                                    }, (_, index)=>index + 1).map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            "aria-current": item === currentPage ? "page" : undefined,
                                                            onClick: ()=>setPage(item),
                                                            className: `h-10 w-10 cursor-pointer rounded-full text-sm font-bold transition hover:-translate-y-0.5 ${item === currentPage ? "bg-[#004796] text-white shadow-lg" : "border border-[#dbe4f2] text-[#475569] hover:bg-[#eef5ff]"}`,
                                                            children: item
                                                        }, item, false, {
                                                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                            lineNumber: 413,
                                                            columnNumber: 23
                                                        }, this)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        "aria-label": "Halaman berikutnya",
                                                        disabled: currentPage === pageCount,
                                                        onClick: ()=>setPage((value)=>value + 1),
                                                        className: "cursor-pointer rounded-full border border-[#dbe4f2] px-4 py-2 text-lg text-[#475569] transition hover:border-[#8fb9ed] hover:bg-[#eef5ff] disabled:cursor-not-allowed disabled:opacity-40",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: "/images/icon/chevron-right.png",
                                                            alt: "",
                                                            className: "h-6 w-6"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                            lineNumber: 431,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                        lineNumber: 423,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 391,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 384,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "rounded-3xl border border-dashed border-[#b8c7dc] bg-white px-6 py-16 text-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-xl font-bold text-[#111e3f]",
                                                children: "Rumah yang Anda cari belum tersedia"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 442,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-2 text-[#64748b]",
                                                children: "Coba ubah kata kunci atau pilihan filter untuk melihat desain rumah lainnya."
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 445,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: reset,
                                                className: "mt-6 cursor-pointer rounded-full bg-[#004796] px-5 py-3 text-sm font-bold text-white transition hover:shadow-lg",
                                                children: "Reset pencarian dan filter"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                                lineNumber: 449,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                        lineNumber: 441,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                lineNumber: 363,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 341,
                columnNumber: 7
            }, this),
            filterOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[70] bg-[#111e3f]/45 p-4 lg:hidden",
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "mobile-filter-title",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto mt-16 max-h-[calc(100vh-5rem)] max-w-md overflow-y-auto rounded-3xl bg-white p-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-5 flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "mobile-filter-title",
                                    className: "text-lg font-bold",
                                    children: "Filter desain"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                    lineNumber: 471,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>setFilterOpen(false),
                                    "aria-label": "Tutup filter",
                                    className: "cursor-pointer rounded-full bg-[#f1f5f9] px-3 py-1",
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                                    lineNumber: 474,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                            lineNumber: 470,
                            columnNumber: 13
                        }, this),
                        filters,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>setFilterOpen(false),
                            className: "mt-5 w-full cursor-pointer rounded-full bg-[#004796] py-3 font-bold text-white transition hover:shadow-lg",
                            children: "Terapkan filter"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                            lineNumber: 484,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                    lineNumber: 469,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
                lineNumber: 463,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/catalog/CatalogGrid.tsx",
        lineNumber: 295,
        columnNumber: 5
    }, this);
}
_s1(CatalogGrid, "duqxIHbpQagtri8X1Vm7pPLr1HY=");
_c1 = CatalogGrid;
var _c, _c1;
__turbopack_context__.k.register(_c, "CustomSelect");
__turbopack_context__.k.register(_c1, "CatalogGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/catalog/DesignCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DesignCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
const formatCost = (value)=>`Rp ${(value / 1000000).toLocaleString("id-ID")} jt`;
function DesignCard({ design }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: "group overflow-hidden rounded-[1.75rem] border border-[#dbe4f2] bg-white shadow-[0_12px_30px_rgba(17,30,63,0.06)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_22px_45px_rgba(17,30,63,0.13)]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: `/katalog/${design.slug}`,
            className: "block focus:outline-none focus-visible:ring-4 focus-visible:ring-[#045ec2]/25",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative aspect-[4/3] overflow-hidden bg-[#e8f4fe]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: design.image,
                            alt: `Desain rumah ${design.name}`,
                            fill: true,
                            sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
                            className: "object-cover transition duration-500 group-hover:scale-105"
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1.5 text-xs font-bold text-[#004796] backdrop-blur",
                            children: design.style
                        }, void 0, false, {
                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start justify-between gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-xl font-bold text-[#111e3f]",
                                            children: design.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 30,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-1 text-sm text-[#64748b]",
                                            children: design.location
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 33,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "rounded-full bg-[#eef5ff] px-2.5 py-1 text-xs font-semibold text-[#045ec2]",
                                    children: [
                                        design.floors,
                                        " lantai"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-5 grid grid-cols-3 gap-2 border-y border-[#edf1f6] py-4 text-sm text-[#475569]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            className: "block text-[#111e3f]",
                                            children: [
                                                design.buildingArea,
                                                " m²"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 41,
                                            columnNumber: 15
                                        }, this),
                                        "Bangunan"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 40,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            className: "block text-[#111e3f]",
                                            children: [
                                                design.landArea,
                                                " m²"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 47,
                                            columnNumber: 15
                                        }, this),
                                        "Tanah"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 46,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            className: "block text-[#111e3f]",
                                            children: design.bedrooms
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 53,
                                            columnNumber: 15
                                        }, this),
                                        "Kamar"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 52,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4 flex items-end justify-between gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-[#64748b]",
                                            children: "Mulai dari"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 61,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "font-bold text-[#004796]",
                                            children: formatCost(design.estimatedCost)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                            lineNumber: 62,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 60,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs font-semibold text-[#64748b]",
                                    children: [
                                        design.estimatedDuration,
                                        " bulan"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                                    lineNumber: 66,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/catalog/DesignCard.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/catalog/DesignCard.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/catalog/DesignCard.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/catalog/DesignCard.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_c = DesignCard;
var _c;
__turbopack_context__.k.register(_c, "DesignCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_catalog_1zqk3p5._.js.map
(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__05llv1c._.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/node_modules_next_1fcsbq3._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkg._.js","static/chunks/node_modules_0amn3zf._.js","static/chunks/src_0on-xg5._.js"],
    source: "entry"
});

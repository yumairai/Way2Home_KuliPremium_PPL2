(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/mandor/MandorShell.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MandorShell,
    "useMandorStatus",
    ()=>useMandorStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/auth.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuthUser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAuthUser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$demo$2d$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/demo-auth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$mandor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/mandor.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function useMandorStatus() {
    _s();
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Menunggu");
    const [reason, setReason] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$mandor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialMandorRegistration"].rejectionReason);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const resubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useMandorStatus.useCallback[resubmit]": async ()=>{
            try {
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiPost"])("/api/mandor/registration");
                setStatus(result.status);
                setReason(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$mandor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialMandorRegistration"].rejectionReason);
            } catch (error) {
                console.error("[useMandorStatus] resubmit:", error);
            }
        }
    }["useMandorStatus.useCallback[resubmit]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMandorStatus.useEffect": ()=>{
            let active = true;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiGet"])("/api/mandor/registration").then({
                "useMandorStatus.useEffect": (result)=>{
                    if (!active) return;
                    setStatus(result.status);
                    setReason(result.reason ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$mandor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initialMandorRegistration"].rejectionReason);
                }
            }["useMandorStatus.useEffect"]).catch({
                "useMandorStatus.useEffect": (error)=>{
                    if (!active) return;
                    console.error("[useMandorStatus]", error);
                }
            }["useMandorStatus.useEffect"]).finally({
                "useMandorStatus.useEffect": ()=>{
                    if (active) setLoading(false);
                }
            }["useMandorStatus.useEffect"]);
            return ({
                "useMandorStatus.useEffect": ()=>{
                    active = false;
                }
            })["useMandorStatus.useEffect"];
        }
    }["useMandorStatus.useEffect"], []);
    return {
        status,
        reason,
        loading,
        resubmit
    };
}
_s(useMandorStatus, "utkpmx0oE/b0DJZ0AyDc1O718lA=");
function MandorShell({ children }) {
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { user, loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuthUser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthUser"])();
    const demoRole = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$demo$2d$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDemoRole"])();
    const { status } = useMandorStatus();
    const [drawer, setDrawer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [leaving, setLeaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MandorShell.useEffect": ()=>{
            if (demoRole) {
                if (demoRole !== "mandor") router.replace(demoRole === "admin" ? "/admin" : "/pengawas");
                return;
            }
            if (!loading && !user) router.replace("/login");
            else if (!loading && user && user.role !== "mandor") router.replace("/dashboard");
        }
    }["MandorShell.useEffect"], [
        demoRole,
        loading,
        user,
        router
    ]);
    const logout = async ()=>{
        setLeaving(true);
        if (demoRole) (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$demo$2d$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearDemoRole"])();
        else await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logout"])();
        router.replace("/login");
        router.refresh();
    };
    if (!demoRole && (loading || !user || user.role !== "mandor")) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "grid min-h-screen place-items-center bg-[#f3f6fa] text-sm text-slate-600",
        children: "Memuat halaman..."
    }, void 0, false, {
        fileName: "[project]/src/components/mandor/MandorShell.tsx",
        lineNumber: 102,
        columnNumber: 7
    }, this);
    const navigation = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: "flex h-full flex-col bg-[#10283d] text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: "/mandor",
                onClick: ()=>setDrawer(false),
                className: "flex h-[76px] items-center gap-3 border-b border-white/10 px-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white p-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/images/logo-w2h.png",
                            alt: "Logo Way2Home",
                            width: 40,
                            height: 40,
                            className: "h-full w-full object-contain",
                            priority: true
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorShell.tsx",
                            lineNumber: 114,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                className: "block text-[17px] tracking-tight",
                                children: "Way2Home"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                className: "text-[10px] font-semibold tracking-[.14em] text-slate-400",
                                children: "PANEL MANDOR"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                lineNumber: 125,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 pt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "px-3 text-[10px] font-bold uppercase tracking-[.16em] text-slate-500",
                        children: "Navigasi"
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "mt-3 space-y-1",
                        "aria-label": "Navigasi mandor",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/mandor",
                                onClick: ()=>setDrawer(false),
                                "aria-current": pathname === "/mandor" ? "page" : undefined,
                                className: `flex h-11 items-center gap-3 rounded-xl px-3 text-sm ${pathname === "/mandor" ? "border border-white/10 bg-white/10 font-semibold text-white" : "text-slate-300 hover:bg-white/[.06]"}`,
                                children: "Ringkasan"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                lineNumber: 135,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/mandor/proyek",
                                onClick: ()=>setDrawer(false),
                                "aria-current": pathname.startsWith("/mandor/proyek") ? "page" : undefined,
                                className: `flex h-11 items-center gap-3 rounded-xl px-3 text-sm ${pathname.startsWith("/mandor/proyek") ? "border border-white/10 bg-white/10 font-semibold text-white" : "text-slate-300 hover:bg-white/[.06]"}`,
                                children: "Proyek"
                            }, void 0, false, {
                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                lineNumber: 143,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 134,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                lineNumber: 130,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-auto border-t border-white/10 p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 rounded-xl bg-white/[.06] p-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "grid h-9 w-9 place-items-center rounded-full bg-[#d6e5f2] text-xs font-bold text-[#17344e]",
                            children: demoRole ? "BS" : user?.fullName ? user.fullName.trim().split(/\s+/).map((part)=>part[0]).slice(0, 2).join("").toUpperCase() : "MD"
                        }, void 0, false, {
                            fileName: "[project]/src/components/mandor/MandorShell.tsx",
                            lineNumber: 157,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "min-w-0 flex-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                    className: "block truncate text-xs",
                                    children: demoRole ? "Bima Saputra" : user?.fullName || "Mandor"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                    lineNumber: 171,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                    className: "text-[10px] text-slate-400",
                                    children: "Mandor"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                    lineNumber: 174,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/mandor/MandorShell.tsx",
                            lineNumber: 170,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/mandor/MandorShell.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorShell.tsx",
        lineNumber: 107,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mandor-interactions min-h-screen bg-[#f3f6fa] text-[#183047]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-y-0 left-0 z-30 hidden w-[252px] lg:block",
                children: navigation
            }, void 0, false, {
                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                lineNumber: 182,
                columnNumber: 7
            }, this),
            drawer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 lg:hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "absolute inset-0 bg-[#091827]/55",
                        "aria-label": "Tutup menu",
                        onClick: ()=>setDrawer(false)
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 187,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative h-full w-[280px] max-w-[85vw]",
                        children: navigation
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 192,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                lineNumber: 186,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "lg:pl-[252px]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-[#e6ebf1] bg-white/95 px-4 backdrop-blur sm:px-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        "aria-label": "Buka menu",
                                        onClick: ()=>setDrawer(true),
                                        className: "grid h-10 w-10 place-items-center rounded-xl border border-slate-200 lg:hidden",
                                        children: "☰"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                        lineNumber: 200,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] text-slate-500",
                                                children: "Way2Home / Mandor"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                                lineNumber: 209,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm font-semibold",
                                                children: pathname.startsWith("/mandor/proyek") ? "Detail pekerjaan" : "Ruang kerja"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                                lineNumber: 210,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                        lineNumber: 208,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `rounded-full px-2.5 py-1 text-[10px] font-semibold ${status === "Disetujui" ? "bg-[#edf6ef] text-[#4d7d56]" : status === "Ditolak" ? "bg-[#fff0f0] text-[#a75252]" : "bg-[#fff4e2] text-[#98651e]"}`,
                                        children: status === "Disetujui" ? "Terverifikasi" : status === "Ditolak" ? "Perlu perbaikan" : "Menunggu verifikasi"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                        lineNumber: 218,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: logout,
                                        disabled: leaving,
                                        className: "rounded-lg border border-[#d99a9a] bg-[#a94444] px-3 py-2 text-xs font-semibold text-white hover:bg-[#913838] disabled:cursor-not-allowed disabled:opacity-50",
                                        "aria-label": "Logout",
                                        children: leaving ? "Logout..." : "Logout"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                        lineNumber: 227,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                                lineNumber: 217,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                        id: "main-content",
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/src/components/mandor/MandorShell.tsx",
                        lineNumber: 238,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/mandor/MandorShell.tsx",
                lineNumber: 197,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/mandor/MandorShell.tsx",
        lineNumber: 181,
        columnNumber: 5
    }, this);
}
_s1(MandorShell, "VSElROL1BaBLw9bXPoR2/+f0sFU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuthUser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthUser"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$demo$2d$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDemoRole"],
        useMandorStatus
    ];
});
_c = MandorShell;
var _c;
__turbopack_context__.k.register(_c, "MandorShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data/mandor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * data/mandor.ts
 *
 * Kontrak tampilan (shape) untuk area Mandor. Seluruh nilai di bawah ini
 * sekarang diisi oleh backend (`mandor.service.ts` -> /api/mandor/*),
 * sehingga tidak ada lagi data proyek contoh yang disimpan di client.
 */ __turbopack_context__.s([
    "initialMandorRegistration",
    ()=>initialMandorRegistration
]);
const initialMandorRegistration = {
    status: "Disetujui",
    rejectionReason: "CV belum mencantumkan proyek dan pengalaman kerja secara rinci.",
    name: "Bima Saputra",
    email: "bima.saputra@mail.id",
    phone: "0812 6677 2041",
    expertise: "Pembangunan rumah",
    experience: "7",
    area: "Jakarta Selatan",
    experienceSummary: "Berpengalaman mengelola pekerjaan pembangunan rumah tinggal, mengatur tim lapangan, serta memastikan pekerjaan sesuai gambar dan target mutu.",
    previousProjects: "Pembangunan rumah tinggal dua lantai di Cilandak; pekerjaan struktur dan finishing rumah di Jagakarsa.",
    cv: "/documents/cv-mandor-rizky.pdf"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useAuthUser.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ROLE_LABEL",
    ()=>ROLE_LABEL,
    "useAuthUser",
    ()=>useAuthUser
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/supabase/client.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ROLE_LABEL = {
    customer: "Customer",
    admin: "Admin",
    pengawas: "Pengawas",
    mandor: "Mandor"
};
const VALID_ROLES = [
    "customer",
    "admin",
    "pengawas",
    "mandor"
];
function toRole(v) {
    return VALID_ROLES.includes(v) ? v : "customer";
}
function useAuthUser() {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAuthUser.useEffect": ()=>{
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            let active = true;
            const load = {
                "useAuthUser.useEffect.load": async (sessionUser)=>{
                    if (!sessionUser) {
                        if (active) {
                            setUser(null);
                            setLoading(false);
                        }
                        return;
                    }
                    const { id, user_metadata } = sessionUser;
                    // Coba ambil dari tabel profiles dulu
                    const { data: profile } = await supabase.from("profiles").select("full_name, role, avatar_url").eq("id", id).single();
                    if (!active) return;
                    if (profile) {
                        const { data: avatar } = profile.avatar_url ? await supabase.storage.from("avatars").createSignedUrl(profile.avatar_url, 3600) : {
                            data: null
                        };
                        if (!active) return;
                        // Profil ditemukan di tabel profiles
                        setUser({
                            id,
                            fullName: profile.full_name ?? "User",
                            role: toRole(profile.role),
                            avatarUrl: avatar?.signedUrl ?? null
                        });
                    } else {
                        // Fallback: gunakan user_metadata dari JWT Supabase
                        const fallbackName = user_metadata?.full_name || user_metadata?.name || sessionUser.email?.split("@")[0] || "User";
                        const fallbackRole = toRole(user_metadata?.role);
                        setUser({
                            id,
                            fullName: fallbackName,
                            role: fallbackRole,
                            avatarUrl: null
                        });
                    }
                    setLoading(false);
                }
            }["useAuthUser.useEffect.load"];
            const handleProfileUpdated = {
                "useAuthUser.useEffect.handleProfileUpdated": (event)=>{
                    const { fullName, avatarUrl } = event.detail;
                    setUser({
                        "useAuthUser.useEffect.handleProfileUpdated": (current)=>current ? {
                                ...current,
                                fullName,
                                avatarUrl
                            } : current
                    }["useAuthUser.useEffect.handleProfileUpdated"]);
                }
            }["useAuthUser.useEffect.handleProfileUpdated"];
            window.addEventListener("w2h:profile-updated", handleProfileUpdated);
            supabase.auth.getSession().then({
                "useAuthUser.useEffect": ({ data: { session } })=>{
                    if (active) load(session?.user);
                }
            }["useAuthUser.useEffect"]);
            const { data: sub } = supabase.auth.onAuthStateChange({
                "useAuthUser.useEffect": (_event, session)=>{
                    if (active) load(session?.user);
                }
            }["useAuthUser.useEffect"]);
            return ({
                "useAuthUser.useEffect": ()=>{
                    active = false;
                    window.removeEventListener("w2h:profile-updated", handleProfileUpdated);
                    sub.subscription.unsubscribe();
                }
            })["useAuthUser.useEffect"];
        }
    }["useAuthUser.useEffect"], []);
    return {
        user,
        loading
    };
}
_s(useAuthUser, "NiO5z6JIqzX62LS5UWDgIqbZYyY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * api.ts — pembungkus fetch untuk Route Handler internal.
 *
 * Komponen client tidak memanggil service Supabase secara langsung;
 * seluruh aksi melewati /api/* sehingga validasi, RLS, dan pesan galat
 * berpusat di sisi server.
 */ __turbopack_context__.s([
    "apiGet",
    ()=>apiGet,
    "apiPatch",
    ()=>apiPatch,
    "apiPost",
    ()=>apiPost,
    "apiPut",
    ()=>apiPut,
    "errorMessage",
    ()=>errorMessage
]);
async function request(path, init) {
    const response = await fetch(path, {
        ...init,
        headers: init?.body ? {
            "Content-Type": "application/json",
            ...init.headers ?? {}
        } : init?.headers
    });
    const payload = await response.json().catch(()=>null);
    if (!response.ok) {
        throw new Error(payload?.message ?? "Permintaan gagal diproses.");
    }
    return payload;
}
function apiGet(path) {
    return request(path);
}
function send(path, method, body) {
    return request(path, {
        method,
        body: body === undefined ? undefined : JSON.stringify(body)
    });
}
function apiPost(path, body) {
    return send(path, "POST", body);
}
function apiPatch(path, body) {
    return send(path, "PATCH", body);
}
function apiPut(path, body) {
    return send(path, "PUT", body);
}
function errorMessage(error, fallback) {
    return error instanceof Error && error.message ? error.message : fallback;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/auth.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "login",
    ()=>login,
    "logout",
    ()=>logout,
    "register",
    ()=>register
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/supabase/client.ts [app-client] (ecmascript)");
;
async function login(email, password) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const { error } = await supabase.auth.signInWithPassword({
        email,
        password
    });
    if (!error) {
        const { data: { user } } = await supabase.auth.getUser();
        const { data: profile, error: profileError } = await supabase.from("profiles").select("role").eq("id", user?.id || "").maybeSingle();
        if (profileError || !profile) {
            await supabase.auth.signOut();
            return {
                ok: false,
                message: "Profil akun belum memiliki role. Hubungi administrator."
            };
        }
        // Blokir login mandor yang belum diverifikasi admin
        if (profile.role === "mandor") {
            const { data: mandorProfile } = await supabase.from("mandor_profiles").select("status").eq("id", user?.id || "").maybeSingle();
            if (!mandorProfile || mandorProfile.status !== "approved") {
                await supabase.auth.signOut();
                return {
                    ok: false,
                    message: "MANDOR_PENDING"
                };
            }
        }
        return {
            ok: true,
            role: profile.role
        };
    }
    const message = error.message === "Invalid login credentials" ? "Email atau password salah." : error.message === "Email not confirmed" ? "Email belum dikonfirmasi. Cek inbox kamu." : error.message;
    return {
        ok: false,
        message
    };
}
async function register(input) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const { data, error } = await supabase.auth.signUp({
        email: input.email,
        password: input.password,
        options: {
            data: {
                full_name: input.name,
                phone: input.phone,
                nik: input.nik,
                role: "customer"
            },
            emailRedirectTo: `${window.location.origin}/callback`
        }
    });
    if (error) {
        return {
            ok: false,
            message: error.message.includes("already registered") ? "Email sudah terdaftar." : error.message
        };
    }
    // Kalau "Confirm email" OFF, signUp langsung bikin session.
    // Logout dulu supaya alurnya sesuai desain FE: daftar → halaman login.
    if (data.session) await supabase.auth.signOut();
    return {
        ok: true
    };
}
async function logout() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])().auth.signOut();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/demo-auth.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authenticateDemoAccount",
    ()=>authenticateDemoAccount,
    "clearDemoRole",
    ()=>clearDemoRole,
    "setDemoRole",
    ()=>setDemoRole,
    "useDemoRole",
    ()=>useDemoRole
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const DEMO_ACCOUNTS = {
    admin: {
        email: "admin@way2home.test",
        password: "admin123"
    },
    mandor: {
        email: "mandor@way2home.test",
        password: "mandor123"
    },
    pengawas: {
        email: "pengawas@way2home.test",
        password: "pengawas123"
    }
};
const EVENT_NAME = "way2home-demo-role-change";
function subscribe(callback) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.addEventListener(EVENT_NAME, callback);
    window.addEventListener("storage", callback);
    return ()=>{
        window.removeEventListener(EVENT_NAME, callback);
        window.removeEventListener("storage", callback);
    };
}
function snapshot() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const value = window.sessionStorage.getItem("way2home-demo-role");
    return value === "admin" || value === "mandor" || value === "pengawas" ? value : null;
}
function useDemoRole() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribe, snapshot, {
        "useDemoRole.useSyncExternalStore": ()=>null
    }["useDemoRole.useSyncExternalStore"]);
}
_s(useDemoRole, "FpwL93IKMLJZuQQXefVtWynbBPQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
function authenticateDemoAccount(email, password) {
    const normalizedEmail = email.trim().toLowerCase();
    const entry = Object.entries(DEMO_ACCOUNTS).find(([, account])=>account.email === normalizedEmail && account.password === password);
    return entry?.[0] ?? null;
}
function setDemoRole(role) {
    window.sessionStorage.setItem("way2home-demo-role", role);
    window.dispatchEvent(new Event(EVENT_NAME));
}
function clearDemoRole() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    window.sessionStorage.removeItem("way2home-demo-role");
    window.dispatchEvent(new Event(EVENT_NAME));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
let client = null;
function createClient() {
    if (!client) {
        client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://oiqbpbheyrsekrlyenyv.supabase.co"), ("TURBOPACK compile-time value", "sb_publishable_LFSFjIJuIkEia9y0GMjBJQ_ATtbUzpj"));
    }
    return client;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0ie0pos._.js.map
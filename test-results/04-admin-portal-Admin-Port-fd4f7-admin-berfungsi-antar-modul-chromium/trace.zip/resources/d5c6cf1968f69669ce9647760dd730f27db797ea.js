(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/admin/SupervisorManagement.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SupervisorManagement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/allocation.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/access.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$admin$2d$badge$2d$counts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/admin-badge-counts.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
// ─── Status helpers ────────────────────────────────────────────────────────────
const STATUS_LABEL = {
    draft: "Draft",
    verifikasi_dokumen: "Verif. Dokumen",
    revisi_dokumen: "Revisi Dokumen",
    alokasi_mandor_pengawas: "Menunggu Tim",
    finalisasi_kontrak: "Finalisasi Kontrak",
    pembayaran_dp: "Pembayaran DP",
    berjalan: "Berjalan",
    selesai: "Selesai",
    batal: "Dibatalkan",
    menunggu_pengawas: "Menunggu Pengawas"
};
const STATUS_CLASS = {
    draft: "bg-slate-100 text-slate-600",
    verifikasi_dokumen: "bg-amber-50 text-amber-700",
    revisi_dokumen: "bg-red-50 text-red-700",
    alokasi_mandor_pengawas: "bg-sky-50 text-sky-700",
    finalisasi_kontrak: "bg-purple-50 text-purple-700",
    pembayaran_dp: "bg-orange-50 text-orange-700",
    berjalan: "bg-emerald-50 text-emerald-700",
    selesai: "bg-green-50 text-green-700",
    batal: "bg-red-100 text-red-700",
    menunggu_pengawas: "bg-amber-50 text-amber-700"
};
// ─── Modal: Pilih Pengawas ─────────────────────────────────────────────────────
function AssignPengawasModal({ project, pengawasList, onClose, onAssigned }) {
    _s();
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleAssign = async ()=>{
        if (!selected) return;
        setSubmitting(true);
        setError(null);
        try {
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignPengawasToProject"])(supabase, project.id, selected);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$admin$2d$badge$2d$counts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["refreshAdminBadgeCounts"])();
            const chosenPengawas = pengawasList.find((p)=>p.id === selected);
            let notificationWarning;
            try {
                const response = await fetch(`/api/projects/${project.id}/team-notifications`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        event: "admin-assignment"
                    })
                });
                if (!response.ok) {
                    const result = await response.json();
                    notificationWarning = result.message || "Notifikasi customer gagal dikirim.";
                }
            } catch (notificationError) {
                console.error("[SupervisorManagement] team notification failed:", notificationError);
                notificationWarning = "Notifikasi customer gagal dikirim.";
            }
            onAssigned(project.id, selected, chosenPengawas?.full_name ?? selected, notificationWarning);
            onClose();
        } catch (err) {
            if (err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]) {
                setError(err.message);
            } else {
                setError("Terjadi kesalahan. Coba lagi.");
            }
        } finally{
            setSubmitting(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[70] grid place-items-center bg-[#0c1b2b]/60 p-4 backdrop-blur-[3px]",
        onMouseDown: (e)=>{
            if (e.target === e.currentTarget) onClose();
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "assign-pengawas-title",
            className: "w-full max-w-[680px] overflow-hidden rounded-2xl bg-white shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "flex items-center justify-between border-b border-[#e8edf1] px-6 py-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[10px] text-slate-500",
                                    children: "Alokasi Pengawas"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    id: "assign-pengawas-title",
                                    className: "mt-1 text-lg font-bold text-[#17344e]",
                                    children: "Pilih Pengawas untuk Proyek"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 131,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-0.5 text-xs text-slate-500 truncate max-w-[480px]",
                                    children: [
                                        project.design_name,
                                        " · ",
                                        project.customer_name,
                                        project.alamat_proyek ? ` · ${project.alamat_proyek}` : ""
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 137,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 129,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            "aria-label": "Tutup",
                            className: "grid h-9 w-9 place-items-center rounded-lg border border-slate-200 text-xl text-slate-500 hover:bg-slate-50",
                            children: "×"
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 142,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                    lineNumber: 128,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-5 mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                    lineNumber: 152,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-h-[55vh] space-y-2 overflow-y-auto p-5",
                    children: pengawasList.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-xl border border-dashed border-[#d9e1e8] p-9 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-[#365873]",
                                children: "Tidak ada pengawas aktif"
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                lineNumber: 160,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-xs text-slate-500",
                                children: "Tambahkan akun pengawas terlebih dahulu."
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                lineNumber: 163,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 159,
                        columnNumber: 13
                    }, this) : pengawasList.map((pengawas)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: !pengawas.available,
                            onClick: ()=>setSelected(pengawas.id),
                            className: `flex w-full items-center gap-4 rounded-xl border p-4 text-left transition-colors ${!pengawas.available ? "cursor-not-allowed border-[#e7ebef] bg-slate-50 opacity-60" : selected === pengawas.id ? "border-[#7395b1] bg-[#f0f5f8] ring-2 ring-[#7395b1]/15" : "border-[#e7ebef] hover:bg-slate-50"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "grid h-12 w-12 shrink-0 place-items-center rounded-full border border-[#d8e3eb] bg-[#eaf1f6] text-sm font-bold text-[#355973]",
                                    children: pengawas.full_name.slice(0, 2).toUpperCase()
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 180,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "min-w-0 flex-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                            className: "block truncate text-sm text-[#29465e]",
                                            children: pengawas.full_name
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                            lineNumber: 184,
                                            columnNumber: 19
                                        }, this),
                                        pengawas.spesialisasi && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mt-0.5 block text-[11px] text-slate-500",
                                            children: pengawas.spesialisasi
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                            lineNumber: 188,
                                            columnNumber: 21
                                        }, this),
                                        pengawas.phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "block text-[10px] text-slate-400",
                                            children: pengawas.phone
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                            lineNumber: 193,
                                            columnNumber: 21
                                        }, this),
                                        !pengawas.available && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mt-1 block text-[10px] font-semibold text-amber-700",
                                            children: "Sedang menangani proyek aktif"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                            lineNumber: 198,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 183,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `grid h-5 w-5 shrink-0 place-items-center rounded-full border ${selected === pengawas.id ? "border-[#477ba6] bg-[#477ba6] text-white" : "border-slate-300"}`,
                                    children: selected === pengawas.id ? "✓" : ""
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 203,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, pengawas.id, true, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 169,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                    lineNumber: 157,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                    className: "flex justify-end gap-2 border-t border-[#e8edf1] bg-[#fafbfc] px-5 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "h-10 rounded-lg border border-[#dfe6ed] px-4 text-xs font-semibold text-slate-600 hover:bg-white",
                            children: "Batal"
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 217,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleAssign,
                            disabled: !selected || submitting,
                            className: "h-10 rounded-lg bg-[#183b57] px-5 text-xs font-semibold text-white hover:bg-[#234f70] disabled:cursor-not-allowed disabled:opacity-40",
                            children: submitting ? "Mengalokasikan..." : "Alokasikan Pengawas"
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 223,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                    lineNumber: 216,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
            lineNumber: 122,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
        lineNumber: 116,
        columnNumber: 5
    }, this);
}
_s(AssignPengawasModal, "9g0noDOuNK5kjX2QU8CLBv+Kc0M=");
_c = AssignPengawasModal;
function SupervisorManagement() {
    _s1();
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [pengawasList, setPengawasList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [statusFilter, setStatusFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Semua status");
    const [allocationFilter, setAllocationFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Semua");
    const [selectedProject, setSelectedProject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [notice, setNotice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fetchData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SupervisorManagement.useCallback[fetchData]": async ()=>{
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            return Promise.all([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProjectsForAdmin"])(supabase),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActivePengawas"])(supabase)
            ]);
        }
    }["SupervisorManagement.useCallback[fetchData]"], []);
    const load = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SupervisorManagement.useCallback[load]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                const [projectsData, pengawasData] = await fetchData();
                setProjects(projectsData);
                setPengawasList(pengawasData);
            } catch (err) {
                if (err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]) {
                    setError(err.message);
                } else {
                    setError("Gagal memuat data. Silakan refresh halaman.");
                }
            } finally{
                setLoading(false);
            }
        }
    }["SupervisorManagement.useCallback[load]"], [
        fetchData
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SupervisorManagement.useEffect": ()=>{
            let active = true;
            fetchData().then({
                "SupervisorManagement.useEffect": ([projectsData, pengawasData])=>{
                    if (!active) return;
                    setProjects(projectsData);
                    setPengawasList(pengawasData);
                }
            }["SupervisorManagement.useEffect"]).catch({
                "SupervisorManagement.useEffect": (err)=>{
                    if (!active) return;
                    setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"] ? err.message : "Gagal memuat data. Silakan refresh halaman.");
                }
            }["SupervisorManagement.useEffect"]).finally({
                "SupervisorManagement.useEffect": ()=>{
                    if (active) setLoading(false);
                }
            }["SupervisorManagement.useEffect"]);
            return ({
                "SupervisorManagement.useEffect": ()=>{
                    active = false;
                }
            })["SupervisorManagement.useEffect"];
        }
    }["SupervisorManagement.useEffect"], [
        fetchData
    ]);
    const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SupervisorManagement.useMemo[filtered]": ()=>projects.filter({
                "SupervisorManagement.useMemo[filtered]": (p)=>{
                    const q = query.trim().toLowerCase();
                    const matchQuery = !q || `${p.id} ${p.design_name} ${p.customer_name} ${p.pengawas_name ?? ""} ${p.alamat_proyek ?? ""}`.toLowerCase().includes(q);
                    const matchStatus = statusFilter === "Semua status" || STATUS_LABEL[p.status] === statusFilter || p.status === statusFilter;
                    const matchAllocation = allocationFilter === "Semua" || allocationFilter === "Sudah dialokasikan" && p.pengawas_id !== null || allocationFilter === "Belum dialokasikan" && p.pengawas_id === null;
                    return matchQuery && matchStatus && matchAllocation;
                }
            }["SupervisorManagement.useMemo[filtered]"])
    }["SupervisorManagement.useMemo[filtered]"], [
        projects,
        query,
        statusFilter,
        allocationFilter
    ]);
    const totalAllocated = projects.filter((p)=>p.pengawas_id !== null).length;
    const totalUnallocated = projects.filter((p)=>p.pengawas_id === null).length;
    const handleAssigned = (projectId, _pengawasId, pengawasName, notificationWarning)=>{
        setProjects((curr)=>curr.map((p)=>p.id === projectId ? {
                    ...p,
                    pengawas_id: _pengawasId,
                    pengawas_name: pengawasName
                } : p));
        setNotice({
            message: notificationWarning ? `Pengawas "${pengawasName}" berhasil dialokasikan. ${notificationWarning}` : `Pengawas "${pengawasName}" berhasil dialokasikan ke proyek.`,
            warning: Boolean(notificationWarning)
        });
        window.setTimeout(()=>setNotice(null), 8000);
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1500px] space-y-6 p-5 md:p-8 xl:p-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-h-[300px] items-center justify-center rounded-2xl border border-[#e5eaf0] bg-white",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[#477ba6] border-t-transparent"
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 363,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-3 text-sm text-slate-500",
                            children: "Memuat data..."
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 364,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                    lineNumber: 362,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 361,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
            lineNumber: 360,
            columnNumber: 7
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1500px] space-y-6 p-5 md:p-8 xl:p-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-red-200 bg-red-50 p-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm font-semibold text-red-700",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 375,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: load,
                        className: "mt-3 rounded-lg bg-[#183b57] px-4 py-2 text-xs font-semibold text-white hover:bg-[#234f70]",
                        children: "Coba Lagi"
                    }, void 0, false, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 376,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 374,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
            lineNumber: 373,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto max-w-[1500px] space-y-6 p-5 md:p-8 xl:p-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex flex-col justify-between gap-4 md:flex-row md:items-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs font-semibold text-[#64809a]",
                            children: "Alokasi Tim"
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 392,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "mt-2 text-[26px] font-bold tracking-tight text-[#17344e] md:text-[32px]",
                            children: "Alokasi Pengawas"
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 393,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 max-w-2xl text-sm text-slate-500",
                            children: "Kelola penugasan pengawas lapangan ke proyek yang membutuhkan. Alokasi bersifat tetap setelah dikonfirmasi."
                        }, void 0, false, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 396,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                    lineNumber: 391,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 390,
                columnNumber: 7
            }, this),
            notice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: notice.warning ? "alert" : "status",
                className: `rounded-xl border px-4 py-3 text-xs font-medium ${notice.warning ? "border-amber-200 bg-amber-50 text-amber-800" : "border-[#cfe3d2] bg-[#edf7ee] text-[#477c50]"}`,
                children: [
                    notice.warning ? "!" : "✓",
                    " ",
                    notice.message
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 405,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "grid gap-3 sm:grid-cols-3",
                children: [
                    {
                        label: "Total proyek",
                        value: projects.length,
                        tone: "text-[#294c69] bg-[#eaf1f6]"
                    },
                    {
                        label: "Sudah dialokasikan",
                        value: totalAllocated,
                        tone: "text-[#477c50] bg-[#edf7ee]"
                    },
                    {
                        label: "Belum dialokasikan",
                        value: totalUnallocated,
                        tone: "text-[#9a671f] bg-[#fff5e3]"
                    }
                ].map((metric)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "flex items-center justify-between rounded-xl border border-[#e5eaf0] bg-white p-4 md:p-5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] font-medium text-slate-500",
                                    children: metric.label
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 441,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    className: "mt-2 block text-2xl text-[#17344e]",
                                    children: metric.value
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 444,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 440,
                            columnNumber: 13
                        }, this)
                    }, metric.label, false, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 436,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 418,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "overflow-hidden rounded-2xl border border-[#e5eaf0] bg-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-4 border-b border-[#edf0f4] p-5 md:flex-row md:items-center md:justify-between md:px-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-[15px] font-bold text-[#263d53]",
                                        children: "Daftar Proyek"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                        lineNumber: 456,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-xs text-slate-500",
                                        children: [
                                            "Menampilkan ",
                                            filtered.length,
                                            " dari ",
                                            projects.length,
                                            " proyek"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                        lineNumber: 459,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                lineNumber: 455,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-2 sm:flex-row",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sr-only",
                                                children: "Cari proyek"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 465,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "absolute left-3 top-2.5 text-slate-400",
                                                children: "⌕"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 466,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "search-project-admin",
                                                value: query,
                                                onChange: (e)=>setQuery(e.target.value),
                                                placeholder: "Cari proyek, pelanggan, pengawas...",
                                                className: "h-10 w-full rounded-lg border border-[#dfe6ed] bg-white pl-9 pr-3 text-xs outline-none placeholder:text-slate-400 focus:border-[#477ba6] focus:ring-2 focus:ring-[#477ba6]/15 sm:w-[240px]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 467,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                        lineNumber: 464,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sr-only",
                                                children: "Filter alokasi"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 476,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                id: "filter-alokasi-admin",
                                                value: allocationFilter,
                                                onChange: (e)=>setAllocationFilter(e.target.value),
                                                className: "h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-xs text-slate-600 outline-none focus:border-[#477ba6] sm:w-auto",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Semua"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 483,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Sudah dialokasikan"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 484,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Belum dialokasikan"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 485,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 477,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                        lineNumber: 475,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sr-only",
                                                children: "Filter status"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 489,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                id: "filter-status-admin",
                                                value: statusFilter,
                                                onChange: (e)=>setStatusFilter(e.target.value),
                                                className: "h-10 w-full rounded-lg border border-[#dfe6ed] bg-white px-3 text-xs text-slate-600 outline-none focus:border-[#477ba6] sm:w-auto",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Semua status"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 496,
                                                        columnNumber: 17
                                                    }, this),
                                                    Object.values(STATUS_LABEL).map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            children: l
                                                        }, l, false, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 498,
                                                            columnNumber: 19
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 490,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                        lineNumber: 488,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                lineNumber: 463,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 454,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: "w-full min-w-[860px] text-left text-xs",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "bg-[#f8fafc] text-[10px] font-semibold text-slate-500",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-6 py-3",
                                                children: "Proyek / Desain"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 509,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-4 py-3",
                                                children: "Pelanggan"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 510,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-4 py-3",
                                                children: "Status Proyek"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 511,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-4 py-3",
                                                children: "Pengawas"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 512,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-6 py-3 text-right",
                                                children: "Aksi"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 513,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                        lineNumber: 508,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 507,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    className: "divide-y divide-[#edf0f4]",
                                    children: [
                                        filtered.map((project)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "transition-colors hover:bg-[#fbfcfd]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-6 py-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "block font-semibold text-[#263d53]",
                                                                children: project.design_name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                                lineNumber: 523,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "mt-1 block text-[10px] text-slate-400",
                                                                children: [
                                                                    project.id.slice(0, 8),
                                                                    "…",
                                                                    project.alamat_proyek ? ` · ${project.alamat_proyek.slice(0, 35)}${project.alamat_proyek.length > 35 ? "…" : ""}` : ""
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                                lineNumber: 526,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 522,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-4 py-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "block text-slate-700",
                                                                children: project.customer_name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                                lineNumber: 534,
                                                                columnNumber: 21
                                                            }, this),
                                                            project.customer_phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "block text-[10px] text-slate-400",
                                                                children: project.customer_phone
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                                lineNumber: 538,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 533,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-4 py-4",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: `rounded-full px-2.5 py-1 text-[10px] font-semibold ${STATUS_CLASS[project.status] ?? "bg-slate-100 text-slate-600"}`,
                                                            children: STATUS_LABEL[project.status] ?? project.status
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 544,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 543,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-4 py-4",
                                                        children: project.pengawas_id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#eaf1f6] text-[10px] font-bold text-[#355973]",
                                                                    children: (project.pengawas_name ?? "PW").slice(0, 2).toUpperCase()
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                                    lineNumber: 553,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-slate-700",
                                                                    children: project.pengawas_name ?? "Pengawas Ditugaskan"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                                    lineNumber: 558,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 552,
                                                            columnNumber: 23
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "italic text-slate-400",
                                                            children: "Belum dialokasikan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 563,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 550,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-6 py-4 text-right",
                                                        children: project.pengawas_id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "inline-flex h-9 items-center rounded-lg border border-[#e5e9ed] px-3 text-[10px] font-semibold text-slate-400",
                                                            children: "✓ Sudah dialokasikan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 570,
                                                            columnNumber: 23
                                                        }, this) : !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$allocation$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canAllocateStaff"])(project.status) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "inline-flex h-9 items-center rounded-lg border border-[#e5e9ed] px-3 text-[10px] font-semibold text-slate-400",
                                                            children: "Menunggu verifikasi dokumen"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 574,
                                                            columnNumber: 23
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            id: `allocate-btn-${project.id}`,
                                                            onClick: ()=>setSelectedProject(project),
                                                            className: "h-9 rounded-lg bg-[#183b57] px-4 text-xs font-semibold text-white hover:bg-[#234f70] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#477ba6]",
                                                            children: "Alokasikan Pengawas"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                            lineNumber: 578,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 568,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, project.id, true, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 518,
                                                columnNumber: 17
                                            }, this)),
                                        filtered.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                colSpan: 5,
                                                className: "px-6 py-14 text-center text-slate-500",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "font-semibold",
                                                        children: "Tidak ada proyek ditemukan"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 595,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 text-xs",
                                                        children: "Coba ubah kata kunci atau filter."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                        lineNumber: 596,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                                lineNumber: 591,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                            lineNumber: 590,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                    lineNumber: 516,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                            lineNumber: 506,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 505,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1 border-t border-[#edf0f4] px-5 py-3 text-[10px] text-slate-400 sm:flex-row sm:justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "Menampilkan ",
                                    filtered.length,
                                    " dari ",
                                    projects.length,
                                    " proyek"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                lineNumber: 607,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Data diambil dari database aktual."
                            }, void 0, false, {
                                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                                lineNumber: 610,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                        lineNumber: 606,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 453,
                columnNumber: 7
            }, this),
            selectedProject && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AssignPengawasModal, {
                project: selectedProject,
                pengawasList: pengawasList,
                onClose: ()=>setSelectedProject(null),
                onAssigned: handleAssigned
            }, void 0, false, {
                fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
                lineNumber: 616,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/admin/SupervisorManagement.tsx",
        lineNumber: 388,
        columnNumber: 5
    }, this);
}
_s1(SupervisorManagement, "T8jqRY6BoPrXMPRyQXfk3dUEdQM=");
_c1 = SupervisorManagement;
var _c, _c1;
__turbopack_context__.k.register(_c, "AssignPengawasModal");
__turbopack_context__.k.register(_c1, "SupervisorManagement");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/access.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ServiceError",
    ()=>ServiceError,
    "assertProjectOwner",
    ()=>assertProjectOwner,
    "requireRole",
    ()=>requireRole,
    "requireUser",
    ()=>requireUser
]);
class ServiceError extends Error {
    status;
    data;
    constructor(message, status, data){
        super(message);
        this.name = "ServiceError";
        this.status = status;
        this.data = data;
    }
}
async function requireUser(supabase) {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) {
        throw new ServiceError("Anda harus login terlebih dahulu.", 401);
    }
    return user;
}
async function requireRole(supabase, expectedRole) {
    const user = await requireUser(supabase);
    const { data: profile, error } = await supabase.from("profiles").select("role").eq("id", user.id).single();
    if (error || !profile) {
        throw new ServiceError("Profil pengguna tidak ditemukan.", 403);
    }
    if (profile.role !== expectedRole) {
        throw new ServiceError(`Akses ditolak. Peran Anda (${profile.role}) tidak memiliki izin untuk tindakan ini.`, 403);
    }
    return {
        user,
        role: profile.role
    };
}
async function assertProjectOwner(supabase, projectId, userId) {
    const { data: project, error } = await supabase.from("projects").select("*").eq("id", projectId).single();
    if (error || !project) {
        throw new ServiceError("Proyek tidak ditemukan.", 404);
    }
    if (project.customer_id !== userId) {
        throw new ServiceError("Anda tidak memiliki hak akses ke proyek ini.", 403);
    }
    return project;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/allocation.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * allocation.service.ts
 *
 * Service untuk:
 * - Fitur 1: Admin mengalokasikan Pengawas ke proyek (update projects.pengawas_id)
 * - Fitur 2: Pengawas mengalokasikan Mandor ke proyek (insert into project_mandors)
 *
 * Semua validasi otoritas dilakukan di level database (RLS).
 * Tidak ada service-role key yang diekspos ke frontend.
 *
 * Pattern query mengikuti project.service.ts:
 *   data.map((row: Record<string, unknown>) => ...)
 */ __turbopack_context__.s([
    "assignMandorsToProject",
    ()=>assignMandorsToProject,
    "assignPengawasToProject",
    ()=>assignPengawasToProject,
    "canAllocateStaff",
    ()=>canAllocateStaff,
    "finalizeProjectStaffing",
    ()=>finalizeProjectStaffing,
    "getActivePengawas",
    ()=>getActivePengawas,
    "getProjectsForAdmin",
    ()=>getProjectsForAdmin,
    "getProjectsForPengawas",
    ()=>getProjectsForPengawas,
    "getVerifiedMandors",
    ()=>getVerifiedMandors,
    "removeMandorFromProject",
    ()=>removeMandorFromProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/access.service.ts [app-client] (ecmascript)");
;
function canAllocateStaff(status) {
    return status === "alokasi_mandor_pengawas";
}
async function finalizeProjectStaffing(supabase, projectId) {
    const { user } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { data: project, error: projectError } = await supabase.from("projects").select("pengawas_id, status").eq("id", projectId).single();
    if (projectError || !project) {
        console.error("[finalizeProjectStaffing] project lookup error:", projectError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek tidak ditemukan.", 404);
    }
    const projectRow = project;
    if (projectRow.pengawas_id !== user.id) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Anda tidak ditugaskan ke proyek ini.", 403);
    }
    if (projectRow.status !== "alokasi_mandor_pengawas") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek ini tidak sedang berada di tahap alokasi tim.", 409);
    }
    const { count, error: mandorError } = await supabase.from("project_mandors").select("mandor_id", {
        count: "exact",
        head: true
    }).eq("project_id", projectId);
    if (mandorError) {
        console.error("[finalizeProjectStaffing] mandor lookup error:", mandorError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa mandor yang sudah dialokasikan.", 500);
    }
    if (!count) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Alokasikan minimal satu mandor sebelum melanjutkan.", 409);
    }
    if (count > 3) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Satu proyek hanya dapat memiliki maksimal 3 mandor.", 409);
    }
    // Recheck status and roster immediately before changing the project stage.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data, error } = await supabase.from("projects").update({
        status: "finalisasi_kontrak"
    }).eq("id", projectId).eq("pengawas_id", user.id).eq("status", "alokasi_mandor_pengawas").select("id").maybeSingle();
    if (error) {
        console.error("[finalizeProjectStaffing] update error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"](error.code === "23514" ? error.message : "Gagal menyelesaikan alokasi tim.", error.code === "23514" ? 409 : 500);
    }
    if (!data) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Status proyek berubah. Muat ulang halaman lalu coba lagi.", 409);
    }
}
async function getProjectsForAdmin(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "admin");
    const { data, error } = await supabase.from("projects").select(`
      id,
      status,
      created_at,
      alamat_proyek,
      pengawas_id,
      designs ( nama ),
      profiles!projects_customer_id_fkey ( full_name, phone ),
      pengawas_profiles (
        profiles!pengawas_profiles_id_fkey ( full_name )
      )
    `).order("created_at", {
        ascending: false
    });
    if (error) {
        console.error("[getProjectsForAdmin] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat daftar proyek.", 500);
    }
    return (data ?? []).map((row)=>{
        const design = row.designs || {};
        const customer = row.profiles || {};
        const pengawasRow = row.pengawas_profiles || {};
        const pengawasProfile = pengawasRow.profiles || {};
        return {
            id: row.id ?? "",
            status: row.status ?? "draft",
            created_at: row.created_at ?? "",
            alamat_proyek: row.alamat_proyek ?? null,
            pengawas_id: row.pengawas_id ?? null,
            pengawas_name: pengawasProfile.full_name ?? null,
            customer_name: customer.full_name || "-",
            customer_phone: customer.phone ?? null,
            design_name: design.nama || "Desain Tidak Diketahui"
        };
    });
}
async function getActivePengawas(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "admin");
    const [{ data, error }, { data: assignedProjects, error: assignedError }] = await Promise.all([
        supabase.from("pengawas_profiles").select(`
      id,
      spesialisasi,
      aktif,
      profiles!pengawas_profiles_id_fkey ( full_name, phone )
    `).eq("aktif", true),
        supabase.from("projects").select("pengawas_id").not("status", "in", "(selesai,batal)").not("pengawas_id", "is", null)
    ]);
    if (error) {
        console.error("[getActivePengawas] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat daftar pengawas.", 500);
    }
    if (assignedError) {
        console.error("[getActivePengawas] assigned projects error:", assignedError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa ketersediaan pengawas.", 500);
    }
    const busyIds = new Set((assignedProjects ?? []).map((row)=>row.pengawas_id));
    return (data ?? []).map((row)=>{
        const profile = row.profiles || {};
        return {
            id: row.id ?? "",
            full_name: profile.full_name || "-",
            phone: profile.phone ?? null,
            spesialisasi: row.spesialisasi ?? null,
            aktif: row.aktif === true,
            available: !busyIds.has(row.id ?? "")
        };
    });
}
async function assignPengawasToProject(supabase, projectId, pengawasId) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "admin");
    const { data: existing, error: checkErr } = await supabase.from("projects").select("pengawas_id, status").eq("id", projectId).single();
    if (checkErr || !existing) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek tidak ditemukan.", 404);
    }
    const existingRow = existing;
    if (existingRow.pengawas_id !== null && existingRow.pengawas_id !== undefined) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek ini sudah memiliki pengawas dan tidak dapat dialokasikan ulang.", 409);
    }
    if (!canAllocateStaff(existingRow.status)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Pengawas hanya dapat dialokasikan setelah dokumen proyek berhasil diverifikasi.", 409);
    }
    const { data: busyProject, error: busyError } = await supabase.from("projects").select("id").eq("pengawas_id", pengawasId).not("status", "in", "(selesai,batal)").limit(1).maybeSingle();
    if (busyError) {
        console.error("[assignPengawasToProject] availability error:", busyError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa ketersediaan pengawas.", 500);
    }
    if (busyProject) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Pengawas tersebut masih menangani proyek aktif lain.", 409);
    }
    // Cast needed: SupabaseClient<Database> Update type resolves to never when relationships are incomplete
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await supabase.from("projects").update({
        pengawas_id: pengawasId
    }).eq("id", projectId).is("pengawas_id", null);
    if (error) {
        console.error("[assignPengawasToProject] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"](error.code === "23514" || error.code === "23505" ? error.message : "Gagal mengalokasikan pengawas.", error.code === "23514" || error.code === "23505" ? 409 : 500);
    }
}
async function getProjectsForPengawas(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Sesi tidak valid.", 401);
    const { data, error } = await supabase.from("projects").select(`
      id,
      status,
      created_at,
      alamat_proyek,
      designs ( nama ),
      profiles!projects_customer_id_fkey ( full_name ),
      contracts ( signed_pengawas_at ),
      project_mandors (
        mandor_id,
        assigned_at,
        mandor_profiles (
          keahlian,
          area_kerja,
          pengalaman_tahun,
          profiles!mandor_profiles_id_fkey ( full_name, phone )
        )
      )
    `).eq("pengawas_id", user.id).order("created_at", {
        ascending: false
    });
    if (error) {
        console.error("[getProjectsForPengawas] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat proyek Anda.", 500);
    }
    return (data ?? []).map((row)=>{
        const design = row.designs || {};
        const customer = row.profiles || {};
        const contract = Array.isArray(row.contracts) ? row.contracts[0] : row.contracts;
        const rawMandors = Array.isArray(row.project_mandors) ? row.project_mandors : [];
        const mandors = rawMandors.map((pm)=>{
            const mandorProfile = pm.mandor_profiles || {};
            const mandorUser = mandorProfile.profiles || {};
            return {
                mandor_id: pm.mandor_id ?? "",
                full_name: mandorUser.full_name || "-",
                phone: mandorUser.phone ?? null,
                keahlian: Array.isArray(mandorProfile.keahlian) ? mandorProfile.keahlian : [],
                area_kerja: mandorProfile.area_kerja ?? null,
                pengalaman_tahun: typeof mandorProfile.pengalaman_tahun === "number" ? mandorProfile.pengalaman_tahun : null,
                assigned_at: pm.assigned_at ?? ""
            };
        });
        return {
            id: row.id ?? "",
            status: row.status ?? "draft",
            created_at: row.created_at ?? "",
            alamat_proyek: row.alamat_proyek ?? null,
            design_name: design.nama || "-",
            customer_name: customer.full_name || "-",
            mandors,
            supervisorSignedAt: contract?.signed_pengawas_at ?? null
        };
    });
}
async function getVerifiedMandors(supabase) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { data: availableIds, error: availabilityError } = await supabase.rpc("get_available_mandor_ids").overrideTypes();
    if (availabilityError) {
        console.error("[getVerifiedMandors] availability error:", availabilityError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa ketersediaan mandor.", 500);
    }
    if (availableIds.length === 0) return [];
    const { data, error } = await supabase.from("mandor_profiles").select(`
      id,
      keahlian,
      area_kerja,
      pengalaman_tahun,
      profiles!mandor_profiles_id_fkey ( full_name, phone )
    `).eq("status", "approved").in("id", availableIds);
    if (error) {
        console.error("[getVerifiedMandors] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memuat daftar mandor.", 500);
    }
    return (data ?? []).map((row)=>{
        const profile = row.profiles || {};
        return {
            id: row.id ?? "",
            full_name: profile.full_name || "-",
            phone: profile.phone ?? null,
            keahlian: Array.isArray(row.keahlian) ? row.keahlian : [],
            area_kerja: row.area_kerja ?? null,
            pengalaman_tahun: typeof row.pengalaman_tahun === "number" ? row.pengalaman_tahun : null
        };
    });
}
async function assignMandorsToProject(supabase, projectId, mandorIds) {
    const { user } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    if (mandorIds.length === 0) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Pilih minimal satu mandor.", 400);
    }
    const { data: project, error: projectErr } = await supabase.from("projects").select("pengawas_id, status").eq("id", projectId).single();
    if (projectErr || !project) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Proyek tidak ditemukan.", 404);
    }
    const projectRow = project;
    if (projectRow.pengawas_id !== user.id) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Anda tidak ditugaskan ke proyek ini.", 403);
    }
    if (!canAllocateStaff(projectRow.status)) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Mandor hanya dapat dialokasikan setelah dokumen proyek berhasil diverifikasi.", 409);
    }
    const { data: existing, error: existingError } = await supabase.from("project_mandors").select("mandor_id").eq("project_id", projectId);
    if (existingError) {
        console.error("[assignMandorsToProject] existing mandors error:", existingError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa mandor yang sudah dialokasikan.", 500);
    }
    const existingIds = new Set((existing ?? []).map((r)=>r.mandor_id));
    const newMandorIds = [
        ...new Set(mandorIds)
    ].filter((id)=>!existingIds.has(id));
    const skipped = mandorIds.length - newMandorIds.length;
    if (newMandorIds.length === 0) {
        return {
            assigned: 0,
            skipped
        };
    }
    if (existingIds.size + newMandorIds.length > 3) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Satu proyek hanya dapat memiliki maksimal 3 mandor.", 409);
    }
    const { data: profiles, error: profilesError } = await supabase.from("mandor_profiles").select("id, keahlian").in("id", [
        ...existingIds,
        ...newMandorIds
    ]);
    if (profilesError) {
        console.error("[assignMandorsToProject] skills error:", profilesError);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal memeriksa keahlian mandor.", 500);
    }
    const skillSets = new Map((profiles ?? []).map((row)=>[
            row.id,
            Array.isArray(row.keahlian) ? row.keahlian : []
        ]));
    const assignedSkills = new Set();
    for (const mandorId of existingIds){
        for (const skill of skillSets.get(mandorId) ?? [])assignedSkills.add(skill);
    }
    for (const mandorId of newMandorIds){
        const skills = skillSets.get(mandorId) ?? [];
        if (skills.length === 0) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Mandor harus memiliki keahlian yang tercatat sebelum dialokasikan.", 409);
        }
        if (skills.some((skill)=>assignedSkills.has(skill))) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Setiap mandor dalam satu proyek harus memiliki keahlian yang berbeda.", 409);
        }
        for (const skill of skills)assignedSkills.add(skill);
    }
    const rows = newMandorIds.map((mandorId)=>({
            project_id: projectId,
            mandor_id: mandorId,
            assigned_by: user.id
        }));
    // Cast needed: project_mandors Insert type resolves to never when relationships are incomplete
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error: insertErr } = await supabase.from("project_mandors").insert(rows);
    if (insertErr) {
        console.error("[assignMandorsToProject] error:", insertErr);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"](insertErr.code === "23514" || insertErr.code === "23505" ? insertErr.message : `Gagal mengalokasikan mandor: ${insertErr.message}`, insertErr.code === "23514" || insertErr.code === "23505" ? 409 : 500);
    }
    return {
        assigned: newMandorIds.length,
        skipped
    };
}
async function removeMandorFromProject(supabase, projectId, mandorId) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["requireRole"])(supabase, "pengawas");
    const { error } = await supabase.from("project_mandors").delete().eq("project_id", projectId).eq("mandor_id", mandorId);
    if (error) {
        console.error("[removeMandorFromProject] error:", error);
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$access$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServiceError"]("Gagal menghapus mandor dari proyek.", 500);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_1ahyq53._.js.map